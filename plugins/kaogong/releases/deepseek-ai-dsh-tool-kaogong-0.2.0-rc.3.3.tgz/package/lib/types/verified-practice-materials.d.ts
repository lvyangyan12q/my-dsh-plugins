/** Read only manually verified, content-pinned supplements. Never edit the bank or score snapshots. */
export declare function loadVerifiedPracticeMaterials(root?: string): Promise<(id: string, stem: string) => string>;
declare const unchangedOptions: (_id: string, _stem: string, options: string[]) => string[];
/** Apply only individually source-verified footer exclusions; never alter stored options or grading keys. */
export declare function loadVerifiedPracticeOptions(root?: string): Promise<typeof unchangedOptions>;
export {};
