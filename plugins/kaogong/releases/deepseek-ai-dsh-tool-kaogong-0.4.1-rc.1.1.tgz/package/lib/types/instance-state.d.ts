import { Closeouts } from './closeouts.ts';
import { Recalls } from './recalls.ts';
import { ErrorReviews } from './error-reviews.ts';
import type { DomainFacility, KvTable, DomainGlobal } from '@deepseek-ai/dsh-storage-domain';
import { PracticeRounds } from './practice-rounds.ts';
import { Lessons } from './lessons.ts';
import { StudyPlan } from './study-plan.ts';
import type { Lesson } from './lesson-schema.ts';
type Binding = {
    phase: 'intent' | 'ready';
    sessionId: string;
    presetId: string;
};
export interface InstanceStateOptions {
    readBinding?(instanceId: string, key: Lesson['roleKey']): Promise<Binding | null>;
}
declare function openState(facility: Pick<DomainFacility, 'open'>, instanceId: string, options: InstanceStateOptions): Promise<{
    state: Readonly<{
        instanceId: string;
        questions: KvTable<string, {
            subject: string;
            knowledgePoint: string;
            questionType: string;
            stem: string;
            options: string[];
            correctAnswer: string;
            userAnswer: string;
            result: "correct" | "wrong" | "skipped";
            errorReason: string;
            notes: string;
            source: string;
            tags: string[];
            createdAt: string;
            updatedAt: string;
            practiceRoundId?: string | undefined;
            practiceSequence?: number | undefined;
            practiceRevision?: number | undefined;
        }>;
        planConfig: DomainGlobal<{
            examDate: string;
            dailyModules: number;
            subjects: {
                name: string;
                weight: number;
            }[];
        }>;
        days: KvTable<string, {
            date: string;
            phase: "foundation" | "reinforce" | "sprint";
            items: {
                subject: string;
                kind: "learn" | "review" | "practice" | "mock";
                title: string;
                done: boolean;
            }[];
        }>;
        bankQuestions: KvTable<string, {
            subject: string;
            knowledgePoint: string;
            questionType: string;
            stem: string;
            options: string[];
            correctAnswer: string;
            explanation: string;
            difficulty: "easy" | "medium" | "hard";
            source: string;
            origin: "web" | "local";
            reviewStatus: "pending" | "approved" | "rejected";
            reviewNotes: string;
            tags: string[];
            createdAt: string;
            reviewedAt: string;
        }>;
        knowledgeEntries: KvTable<string, {
            subject: string;
            knowledgePoint: string;
            title: string;
            content: string;
            kind: "讲义" | "笔记" | "时政" | "公式" | "技巧" | "真题解析" | "其他";
            source: string;
            tags: string[];
            createdAt: string;
            updatedAt: string;
        }>;
        rounds: KvTable<string, {
            version: 1;
            context: {
                subject: string;
                title: string;
                limit: 10;
                knowledgePointId?: string | undefined;
                knowledgePoint?: string | undefined;
                planIndex?: number | undefined;
                taskId?: string | undefined;
                planRevision?: number | undefined;
            };
            questions: {
                subject: string;
                knowledgePoint: string;
                questionType: string;
                stem: string;
                options: string[];
                correctAnswer: string;
                explanation: string;
                difficulty: "easy" | "medium" | "hard";
                source: string;
                origin: "web" | "local";
                reviewStatus: "pending" | "approved" | "rejected";
                reviewNotes: string;
                tags: string[];
                createdAt: string;
                reviewedAt: string;
                id: string;
            }[];
            seenIds: string[];
            reason: string;
            totalAvailable: number;
            cycled: boolean;
            createdAt: string;
            reflections: {
                id: string;
                errorReason: string;
                notes?: string | undefined;
                savedAt?: string | undefined;
                notesRevision?: number | undefined;
            }[];
            revision: number;
            projectedRevision: number;
            changedAt: string;
            review: "ready" | "sending" | "sent";
            score?: {
                answers: {
                    id: string;
                    answer: string;
                }[];
                sequence: number;
                submittedAt: string;
            } | undefined;
            reviewClaim?: {
                taskId: string;
                requestId: string;
            } | undefined;
        }>;
        materialPoints: KvTable<string, {
            materialId: string;
            sourceOwnerId: string;
            pointId: string;
        }>;
        lessonRecords: KvTable<string, {
            version: 1;
            instanceId: string;
            request: {
                lessonId: string;
                subject: string;
                objective: string;
                materialIds: string[];
                requireReflections: boolean;
                knowledgePointId?: string | undefined;
                knowledgePoint?: string | undefined;
                requirePractice?: boolean | undefined;
                taskId?: string | undefined;
                planRevision?: number | undefined;
                legacyNoteId?: string | undefined;
            };
            objectiveId: string;
            homeworkId: string;
            roleKey: {
                appId: "kaogong";
                instanceId: string;
                roleId: "teacher";
                subject: string;
            };
            binding: {
                sessionId: string;
                presetId: string;
            } | null;
            materials: {
                id: string;
                title: string;
                source: string;
                updatedAt: string;
            }[];
            roundIds: string[];
            notes: string;
            completion: {
                confirmedAt: string;
                proofs: {
                    roundId: string;
                    total: number;
                    correct: number;
                    questionIds: string[];
                    reflectedIds: string[];
                }[];
                summary?: string | undefined;
            } | null;
            createdAt: string;
            updatedAt: string;
            revision: number;
            legacyNote?: {
                id: string;
                updatedAt: string;
            } | undefined;
        }>;
        lessonSelection: DomainGlobal<{
            instanceId: string;
            activeLessonId: string | null;
        }>;
        practice: PracticeRounds;
        lessons: Lessons;
        plan: StudyPlan;
        errors: ErrorReviews;
        recalls: Recalls;
        closeouts: Closeouts;
    }>;
    close(): Promise<void>;
}>;
export type KaogongInstanceState = Awaited<ReturnType<typeof openState>>['state'] & {
    unavailableSources?: string[];
    materialOwners?: Map<string, string>;
    withMaterialMappingLease?<T>(operation: () => Promise<T>): Promise<T>;
};
export interface InstanceStateLease {
    readonly state: KaogongInstanceState;
    release(): Promise<void>;
}
/**
 * App-owned state module: a lease spans the whole business command/view, not one table access.
 * Last release drains and closes only this instance. close rejects new leases, waits for callers
 * to release existing leases, then releases all owned domains. It never imports or repairs legacy data.
 */
export declare class KaogongInstancePool {
    private facility;
    private options;
    private entries;
    private stopped;
    private stopping?;
    constructor(facility: Pick<DomainFacility, 'open'>, options?: InstanceStateOptions);
    private shutdown;
    acquire(instanceId: string): Promise<InstanceStateLease>;
    close(): Promise<void>;
}
export {};
