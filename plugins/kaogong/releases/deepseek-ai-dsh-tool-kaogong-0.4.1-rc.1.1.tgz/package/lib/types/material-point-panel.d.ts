export declare function MaterialPointPanel(): import("react/jsx-runtime").JSX.Element;
