import { z } from 'zod';
import type { KaogongInstanceState } from './instance-state.ts';
import type { KnowledgeEntryRecord } from './domain.ts';
import type { BusinessRegistry } from './business.ts';
export declare const materialPointRecord: z.ZodObject<{
    materialId: z.ZodString;
    sourceOwnerId: z.ZodString;
    pointId: z.ZodString;
}, z.core.$strip>;
export declare const materialPointKey: (materialId: string, pointId: string) => string;
export declare function matchesMaterialPoint(state: KaogongInstanceState, id: string, row: KnowledgeEntryRecord, point: {
    id: string;
    subject: string;
    knowledgePoint: string;
}): boolean;
export declare function registerMaterialPoints(registry: BusinessRegistry, state: KaogongInstanceState): () => void;
