import type { BankQuestionRecord } from './domain.ts';
import type { ProvenAssetPlan } from './adopted-assets.ts';
/** Presentation only. Every transformation belongs to the current authorized owner and an immutable applied plan. */
export declare function prepareBankPracticeDisplay(input: {
    instanceId: string;
    ownBank: {
        get(id: string): BankQuestionRecord | undefined;
    };
    rows: Iterable<[string, BankQuestionRecord]>;
    externalOwner?: string;
    plans: readonly ProvenAssetPlan[];
    revalidate(): Promise<void>;
}): Promise<{
    materialStem: (id: string, stem: string) => string;
    materialOptions: (id: string, stem: string, values: string[]) => string[];
}>;
