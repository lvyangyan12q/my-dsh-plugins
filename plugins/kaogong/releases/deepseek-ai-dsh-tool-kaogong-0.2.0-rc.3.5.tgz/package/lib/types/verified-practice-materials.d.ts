export interface VerifiedPracticeFiles {
    realpath(path: string): Promise<string>;
    stat(path: string): Promise<{
        size: number;
    }>;
    readFile(path: string): Promise<Buffer>;
}
/** Read only manually verified, content-pinned supplements. Never edit the bank or score snapshots. */
export declare function loadVerifiedPracticeMaterials(root?: string, io?: VerifiedPracticeFiles): Promise<(id: string, stem: string) => string>;
declare const unchangedOptions: (_id: string, _stem: string, options: string[]) => string[];
/** Apply only individually source-verified footer exclusions; never alter stored options or grading keys. */
export declare function loadVerifiedPracticeOptions(root?: string, io?: VerifiedPracticeFiles): Promise<typeof unchangedOptions>;
export {};
