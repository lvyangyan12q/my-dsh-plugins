export type LearningPreferences = {
    version: 1;
    studyOpen: boolean;
    page: 'classroom' | 'materials' | 'practice' | 'errors';
    pane: 'content' | 'conversation';
    role: {
        roleId: 'class-advisor' | 'teacher' | 'counselor';
        subject?: string;
    };
};
/** Display choices only. Native bindings, messages, drafts and business evidence stay with their owners. */
export declare function readLearningPreferences(instanceId?: string, viewId?: string): LearningPreferences | null;
export declare function writeLearningPreferences(value: LearningPreferences, instanceId?: string, viewId?: string): void;
