import type { KvTable, DomainGlobal } from '@deepseek-ai/dsh-storage-domain';
import type { Lesson, LessonCreate, LessonView } from './lesson-schema.ts';
import type { KnowledgeEntryRecord } from './schemas.ts';
import type { PracticeRounds } from './practice-rounds.ts';
type Binding = {
    phase: 'intent' | 'ready';
    sessionId: string;
    presetId: string;
};
/** One explicit lesson owner; accepted attempts are always resolved by the existing scorer. */
export declare class Lessons {
    private table;
    private knowledge;
    private practice;
    private binding;
    private selection;
    private tail;
    private closing;
    private readonly instanceId;
    constructor(table: KvTable<string, Lesson>, knowledge: KvTable<string, KnowledgeEntryRecord>, practice: PracticeRounds, binding: (key: Lesson['roleKey']) => Promise<Binding | null>, selection: DomainGlobal<{
        instanceId: string;
        activeLessonId: string | null;
    }>);
    private run;
    /** Stop accepting new commands and await every owned command before domain shutdown. */
    close(): Promise<void>;
    private get;
    private put;
    /** Learner-confirmed creation is idempotent by the supplied stable lesson ID. */
    create(input: LessonCreate): Promise<LessonView>;
    read(id: string): Promise<LessonView>;
    current(): Promise<LessonView | null>;
    select(id: string): Promise<LessonView>;
    list(): Promise<{
        id: string;
        subject: string;
        objective: string;
        completed: boolean;
        updatedAt: string;
    }[]>;
    /** Link only an actual fully submitted round; no supplied score is accepted. */
    link(id: string, roundId: string): Promise<LessonView>;
    saveSummary(id: string, notes: string): Promise<LessonView>;
    /** Only the learner HTTP gesture exposes this operation, never an Agent completion tool. */
    confirm(id: string, confirmed: true): Promise<LessonView>;
    /** Read/capture the same ready role identity without creating or sending a Session. */
    prepare(id: string): Promise<LessonView>;
    private evidence;
    private view;
}
export {};
