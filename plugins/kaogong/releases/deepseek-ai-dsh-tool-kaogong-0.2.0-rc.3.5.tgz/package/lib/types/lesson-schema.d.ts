import { z } from 'zod';
export declare const lessonSelection: z.ZodObject<{
    instanceId: z.ZodString;
    activeLessonId: z.ZodNullable<z.ZodString>;
}, z.core.$strip>;
export type LessonSelection = z.infer<typeof lessonSelection>;
export declare const lessonCreate: z.ZodObject<{
    lessonId: z.ZodString;
    subject: z.ZodString;
    objective: z.ZodString;
    knowledgePoint: z.ZodOptional<z.ZodString>;
    materialIds: z.ZodArray<z.ZodString>;
    requireReflections: z.ZodBoolean;
    legacyNoteId: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export declare const lessonCommand: z.ZodObject<{
    lessonId: z.ZodString;
}, z.core.$strict>;
export declare const lessonLink: z.ZodObject<{
    lessonId: z.ZodString;
    roundId: z.ZodString;
}, z.core.$strict>;
export declare const lessonSummaryInput: z.ZodObject<{
    lessonId: z.ZodString;
    notes: z.ZodString;
}, z.core.$strict>;
export declare const lessonConfirm: z.ZodObject<{
    lessonId: z.ZodString;
    confirmed: z.ZodLiteral<true>;
}, z.core.$strict>;
/** Additive aggregate; no original material/history or manual plan flags are copied. */
export declare const lessonRecord: z.ZodObject<{
    version: z.ZodLiteral<1>;
    instanceId: z.ZodString;
    request: z.ZodObject<{
        lessonId: z.ZodString;
        subject: z.ZodString;
        objective: z.ZodString;
        knowledgePoint: z.ZodOptional<z.ZodString>;
        materialIds: z.ZodArray<z.ZodString>;
        requireReflections: z.ZodBoolean;
        legacyNoteId: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>;
    objectiveId: z.ZodString;
    homeworkId: z.ZodString;
    roleKey: z.ZodObject<{
        appId: z.ZodLiteral<"kaogong">;
        instanceId: z.ZodString;
        roleId: z.ZodLiteral<"teacher">;
        subject: z.ZodString;
    }, z.core.$strip>;
    binding: z.ZodNullable<z.ZodObject<{
        sessionId: z.ZodString;
        presetId: z.ZodString;
    }, z.core.$strip>>;
    materials: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        title: z.ZodString;
        source: z.ZodString;
        updatedAt: z.ZodString;
    }, z.core.$strip>>;
    legacyNote: z.ZodOptional<z.ZodObject<{
        id: z.ZodString;
        updatedAt: z.ZodString;
    }, z.core.$strip>>;
    roundIds: z.ZodArray<z.ZodString>;
    notes: z.ZodString;
    completion: z.ZodNullable<z.ZodObject<{
        confirmedAt: z.ZodString;
        proofs: z.ZodArray<z.ZodObject<{
            roundId: z.ZodString;
            total: z.ZodNumber;
            correct: z.ZodNumber;
            questionIds: z.ZodArray<z.ZodString>;
            reflectedIds: z.ZodArray<z.ZodString>;
        }, z.core.$strip>>;
    }, z.core.$strip>>;
    createdAt: z.ZodString;
    updatedAt: z.ZodString;
    revision: z.ZodNumber;
}, z.core.$strip>;
export type Lesson = z.infer<typeof lessonRecord>;
export type LessonCreate = z.infer<typeof lessonCreate>;
export type LessonEvidence = {
    roundId: string;
    total: number;
    correct: number;
    questionIds: string[];
    reflectedIds: string[];
    answered: boolean;
    reflectionsComplete: boolean;
    projection: 'complete' | 'pending';
    review: 'ready' | 'sending' | 'sent';
};
export type LessonView = {
    lesson: Lesson;
    evidence: LessonEvidence[];
    canConfirm: boolean;
    summary: string;
};
