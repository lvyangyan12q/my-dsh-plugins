export type Entry = {
    id: string;
    title: string;
    subject: string;
    kind: string;
    source: string;
    content: string;
    tags?: string[];
};
/** Plain display projection has no registration side effects or old renderer dependency. */
export declare function knowledgeDisplayData(entries: Entry[]): {
    records: {
        id: string;
        title: string;
        subtitle: string;
        fields: {
            科目: string;
            类型: string;
            来源: string;
            正文: string;
            标签: string;
        };
    }[];
    filters: {
        field: string;
        label: string;
    }[];
    stats: {
        id: string;
        label: string;
        operation: string;
    }[];
};
export declare function KnowledgeLibrary(props: {
    active?: boolean;
}): import("react").JSX.Element;
