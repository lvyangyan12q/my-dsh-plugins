import type { Context } from '@deepseek-ai/cordis';
import type { createMaterialImportOwner } from './materials-owner.ts';
/** Browser chooses a registered owned view, never a source path, record value or Native identity. */
export declare function mountMaterialImportHttp(ctx: Context, owner: ReturnType<typeof createMaterialImportOwner>): () => void;
