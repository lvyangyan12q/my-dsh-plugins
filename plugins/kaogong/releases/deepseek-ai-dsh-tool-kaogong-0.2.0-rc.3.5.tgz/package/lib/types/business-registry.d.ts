import type { ToolDefinition } from '@deepseek-ai/dsh-tools';
import { type Config } from './business.ts';
import type { KaogongInstanceState } from './instance-state.ts';
import type { Mineru } from './mineru.ts';
export declare function businessRegistry(config: Config, state: KaogongInstanceState, mineru: Pick<Mineru, 'root' | 'start' | 'collect' | 'image'>): {
    routes: Map<string, import("@deepseek-ai/dsh-host-webserver").WebRoute | import("@deepseek-ai/dsh-host-webserver").WebResourceRoute>;
    tools: Map<string, ToolDefinition>;
};
