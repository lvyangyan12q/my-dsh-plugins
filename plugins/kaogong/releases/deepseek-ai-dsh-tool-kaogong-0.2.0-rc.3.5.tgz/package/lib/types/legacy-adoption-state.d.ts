import type { KvTable } from '@deepseek-ai/dsh-storage-domain';
import type { AdoptionJournal } from './legacy-adoption-workflow.ts';
import type { LegacyAdoptionPlan } from './legacy-adoption-plan.ts';
export type StoredAdoptionJournal = Omit<AdoptionJournal, 'plan'> & {
    planId: string;
    planFingerprint: string;
};
export type StoredAdoptionPlan = {
    id: string;
    fingerprint: string;
    plan: LegacyAdoptionPlan;
};
/** New metadata only; it contains no alias of a legacy domain. */
export declare const adoptionDomain: {
    name: string;
    version: number;
    tables: {
        journals: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, StoredAdoptionJournal>;
        private_knowledge: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, {
            instanceId: string;
            id: string;
            sourceRevision: string;
        }>;
    };
};
/** Large immutable plans are separate from frequent small checkpoint writes. */
export declare const adoptionPlansDomain: {
    name: string;
    version: number;
    tables: {
        plans: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, StoredAdoptionPlan>;
    };
};
export declare const privateKnowledgeKey: (instanceId: string, id: string) => string;
export declare function assertAdoptionReady(journals: Pick<KvTable<string, StoredAdoptionJournal>, 'entries'>, instanceId: string): void;
