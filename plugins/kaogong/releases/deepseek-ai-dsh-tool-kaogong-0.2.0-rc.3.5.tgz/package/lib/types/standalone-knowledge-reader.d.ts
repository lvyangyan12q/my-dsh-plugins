export declare function StandaloneKnowledgeLibrary({ active }: {
    active?: boolean;
}): import("react").JSX.Element;
