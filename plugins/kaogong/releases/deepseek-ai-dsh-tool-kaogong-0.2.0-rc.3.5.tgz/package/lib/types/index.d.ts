import type { Context } from '@deepseek-ai/cordis';
import { Config } from './business.ts';
export { Config };
export declare const name = "kaogong";
export declare const inject: string[];
export declare function apply(ctx: Context, config: Config): void;
