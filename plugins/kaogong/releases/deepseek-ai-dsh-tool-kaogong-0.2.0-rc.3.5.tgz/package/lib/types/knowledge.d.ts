/**
 * Pure knowledge-base retrieval. No runtime dependencies: it filters and
 * ranks structured study notes by subject, knowledge point, kind, and a
 * keyword over title/content/tags (no embeddings, per the design decision).
 * @module kaogong/knowledge
 */
import type { KnowledgeEntry, KnowledgeKind } from './types.ts';
export declare function knowledgeExcerpt(content: string, keyword?: string, limit?: number): string;
/** Retrieval query. */
export interface KnowledgeQuery {
    /** 科目（精确）. */
    subject?: string;
    /** 考点（子串匹配）. */
    knowledgePoint?: string;
    /** 类型（精确）. */
    kind?: KnowledgeKind;
    /** 关键词，按标题/标签/正文命中加权排序. */
    keyword?: string;
}
/**
 * Filter and rank knowledge entries.
 * @param entries - the full knowledge base.
 * @param query - retrieval controls.
 * @returns the matched entries, best first.
 */
export declare function searchKnowledge(entries: KnowledgeEntry[], query: KnowledgeQuery): KnowledgeEntry[];
