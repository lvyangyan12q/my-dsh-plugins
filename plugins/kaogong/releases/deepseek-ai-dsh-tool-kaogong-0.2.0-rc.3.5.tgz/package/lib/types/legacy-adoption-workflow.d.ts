import { type LegacyAdoptionPlan } from './legacy-adoption-plan.ts';
type RecordStep = LegacyAdoptionPlan['records'][number];
type GlobalStep = LegacyAdoptionPlan['globals'][number];
export interface AdoptionTarget {
    read(domain: RecordStep['domain'], key: string): unknown;
    write(domain: RecordStep['domain'], key: string, value: unknown): Promise<void>;
    global(domain: GlobalStep['domain']): unknown;
    initialGlobal(domain: GlobalStep['domain']): unknown;
    setGlobal(domain: GlobalStep['domain'], value: unknown): Promise<void>;
}
export interface AdoptionJournal {
    id: string;
    schema: 1;
    status: 'prepared' | 'applying' | 'unknown' | 'applied';
    plan: LegacyAdoptionPlan;
    globalIndex: number;
    recordIndex: number;
    roleIndex: number;
    grantIndex: number;
    targetIntents?: string[];
    active?: {
        kind: 'record' | 'global';
        index: number;
        beforeHash: string | null;
        afterHash: string;
    };
    notice?: string;
}
export interface AdoptionServices {
    store: {
        read(id: string): Promise<AdoptionJournal | null>;
        write(row: AdoptionJournal): Promise<void>;
    };
    source: {
        verify(plan: LegacyAdoptionPlan, phase?: 'initial' | 'final'): Promise<void>;
    };
    applications: {
        completeProvision?(instanceId: string, operationId: string): Promise<unknown>;
        ensureInstance(input: {
            id: string;
            appId: string;
            projectId: null;
            operationId: string;
        }): Promise<unknown>;
        ensureView(input: {
            id: string;
            instanceId: string;
            type: string;
            operationId: string;
        }): Promise<unknown>;
    };
    target: {
        run<T>(instanceId: string, operation: (target: AdoptionTarget) => Promise<T>): Promise<T>;
    };
    privacy: {
        markPrivate(instanceId: string, ids: string[], sourceRevision: string): Promise<void>;
    };
    roles: {
        apply(plan: LegacyAdoptionPlan, role: LegacyAdoptionPlan['roles'][number]): Promise<void>;
    };
    grants: {
        ensure(plan: LegacyAdoptionPlan, grant: LegacyAdoptionPlan['readOnlyGrants'][number]): Promise<void>;
    };
}
/** App-owned durable import intent. It never restores or writes the old profile. */
export declare class LegacyAdoptionWorkflow {
    private readonly services;
    private tail;
    private closing;
    constructor(services: AdoptionServices);
    private run;
    remember(plan: LegacyAdoptionPlan): Promise<AdoptionJournal>;
    inspect(id: string): Promise<AdoptionJournal>;
    apply(input: {
        id: string;
        fingerprint: string;
        confirmed: boolean;
    }): Promise<AdoptionJournal>;
    close(): Promise<void>;
}
export {};
