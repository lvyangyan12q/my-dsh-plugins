import { type LegacyInspectionSnapshot } from './legacy-adoption-plan.ts';
import type { LegacyMaterialEvidence } from './legacy-material-evidence.mjs';
import type { LegacyBankImageEvidence } from './legacy-bank-image-evidence.mjs';
import type { LegacyPrivateAssetEvidence } from './legacy-private-assets.mjs';
export type MaterialSnapshot = LegacyInspectionSnapshot & {
    format: 'kaogong-material-inspection';
};
export type MaterialImportPlan = {
    format: 'kaogong-material-import-plan';
    formatVersion: 1;
    private: true;
    id: string;
    fingerprint: string;
    source: {
        home: string;
        revision: string;
        files: {
            name: string;
            resolvedPath: string;
            sha256: string;
            version: number;
            bytes: number;
        }[];
    };
    target: {
        instanceId: string;
        viewId: string;
        appId: 'kaogong-library';
        projectId: string | null;
        revision?: number;
    };
    records: {
        domain: 'bank' | 'knowledge';
        key: string;
        value: unknown;
        hash: string;
    }[];
    privateKnowledgeIds: string[];
    retainedNoteIds: string[];
    counts: Record<string, number>;
    assetEvidence?: {
        materials?: LegacyMaterialEvidence;
        bank?: LegacyBankImageEvidence;
        private?: LegacyPrivateAssetEvidence;
    };
    policy: {
        sourceWrites: 0;
        nativeSessions: 'not-read-or-adopted';
        learningRecords: 'not-read-or-copied';
        sharing: 'explicit-readonly-only';
        files: 'original-paths-no-copy';
    };
};
export declare function prepareMaterialImport({ snapshot, assetEvidence, target }: {
    snapshot: MaterialSnapshot;
    assetEvidence?: MaterialImportPlan['assetEvidence'];
    target?: MaterialImportPlan['target'];
}): MaterialImportPlan;
export declare function validateMaterialPlan(plan: MaterialImportPlan): void;
