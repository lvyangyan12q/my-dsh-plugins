export type ImageRecordContext = {
    entryId: string;
    questionId?: never;
} | {
    questionId: string;
    entryId?: never;
};
export declare function DocumentMarkdown({ content, imageContext }: {
    content: string;
    imageContext?: ImageRecordContext;
}): import("react").JSX.Element;
