import type { Context } from '@deepseek-ai/cordis';
type ScopeRuntime = typeof import('@deepseek-ai/dsh-scope');
/** Public installation metadata plus actual Native preset admission, without a Session or persona registration. */
export declare function nativeRoleScope(ctx: Context): Promise<ScopeRuntime>;
export {};
