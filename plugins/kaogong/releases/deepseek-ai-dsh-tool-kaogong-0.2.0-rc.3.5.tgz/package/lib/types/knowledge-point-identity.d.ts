/** Canonical comparison only; imported classification and original bank records stay intact.
 * 原因解释类 was verified against the original question book and independent classification.
 * No substring, suffix removal or broad attribution/explanation aliases are inferred.
 */
export declare function canonicalKnowledgePoint(subject: string, knowledgePoint: string): string;
