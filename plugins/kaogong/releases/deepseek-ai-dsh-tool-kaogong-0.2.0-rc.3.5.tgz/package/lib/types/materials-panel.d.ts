export declare function MaterialImportPanel({ viewId, onApplied }: {
    viewId: string;
    onApplied(): void;
}): import("react").JSX.Element;
