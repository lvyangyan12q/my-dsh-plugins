import type { IncomingMessage, ServerResponse } from 'node:http';
import type { ApplicationDirectory, RoleDirectory } from 'dsh-worktable/sdk';
import type { KaogongInstancePool, KaogongInstanceState } from './instance-state';
import { CommandGate } from './command-gate';
type Registry = ReturnType<typeof import('./business-registry.ts').businessRegistry> & {
    dispose?(): Promise<void>;
};
export declare class KaogongHost {
    private readonly services;
    private readonly pending;
    private closing;
    readonly gate: CommandGate;
    constructor(services: {
        applications: Pick<ApplicationDirectory, 'resolveView'>;
        roles: Pick<RoleDirectory, 'resolveSession'>;
        pool: Pick<KaogongInstancePool, 'acquire' | 'close'>;
        connection: {
            admit(request: IncomingMessage): unknown;
        };
        registry(state: KaogongInstanceState, command?: string): Registry | Promise<Registry>;
        assertReady?(instanceId: string): void | Promise<void>;
    });
    private operation;
    /** App-internal source/receipt work may reenter its own lease, external tools may not. */
    state<T>(instanceId: string, operation: (state: KaogongInstanceState) => Promise<T>): Promise<T>;
    /** App-owned importer only; normal HTTP/tools/resources always use the readiness guard. */
    importState<T>(instanceId: string, operation: (state: KaogongInstanceState) => Promise<T>): Promise<T>;
    http(route: string, request: IncomingMessage, response: ServerResponse): Promise<void>;
    tool(name: string, args: unknown, execution: unknown): Promise<unknown>;
    active(name: string, context: {
        agent: {
            session: {
                id: string;
            };
        };
    }): Promise<boolean>;
    close(): Promise<void>;
}
export {};
