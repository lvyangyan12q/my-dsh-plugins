import type { ImgHTMLAttributes } from 'react';
import type { RoleFacade, TaskFacade } from 'dsh-worktable/sdk';
import { savePracticeDraft } from './practice-client.ts';
export declare const KaogongTransportContext: import("react").Context<Readonly<{
    url: (input: string) => string;
    fetch: (input: string, init?: RequestInit) => Promise<Response>;
    json: <T>(input: string, body: unknown) => Promise<T>;
    instanceId: string;
    viewId: string;
}> | null>;
export declare const KaogongServicesContext: import("react").Context<{
    roles?: RoleFacade;
    tasks?: TaskFacade;
} | null>;
export declare function useViewServices(): {
    roles?: RoleFacade;
    tasks?: TaskFacade;
} | null;
export declare function useLearningHttp(): Readonly<{
    url: (input: string) => string;
    fetch: (input: string, init?: RequestInit) => Promise<Response>;
    json: <T>(input: string, body: unknown) => Promise<T>;
    instanceId: string;
    viewId: string;
}> | {
    fetch: (input: string, init?: RequestInit) => Promise<Response>;
    url: (input: string) => string;
};
export declare function usePracticeClient(): {
    practiceRequest: <T>(action: string, body: unknown) => Promise<T>;
    readPracticeDraft: () => import("./practice-client.ts").PracticeDraft | null;
    savePracticeDraft: (draft: Parameters<typeof savePracticeDraft>[0]) => void;
    readAdmittedReviews: () => string[];
    markAdmittedReview: (id: string) => void;
};
/** Render-time scoping preserves original stored material references. */
export declare function ScopedMaterialImage(props: ImgHTMLAttributes<HTMLImageElement>): import("react").JSX.Element;
