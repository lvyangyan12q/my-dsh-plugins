/** Same-origin practice requests; cached drafts never supply scores or role identity. */
export declare function practiceRequest<T>(action: string, body: unknown): Promise<T>;
/** Delivery markers suppress repeat sends after native admission when the Host projection must be retried. */
export declare function readAdmittedReviews(instanceId?: string): string[];
export declare function markAdmittedReview(roundId: string, instanceId?: string): void;
export type PracticeDraft = {
    roundId: string;
    answers: Record<string, string>;
    errorReasons: Record<string, string>;
    notes: Record<string, string>;
};
/** Drafts contain learner input and a Host-issued pointer only. Storage failure is explicit. */
export declare function savePracticeDraft(draft: PracticeDraft, instanceId?: string): void;
export declare function readPracticeDraft(instanceId?: string): PracticeDraft | null;
