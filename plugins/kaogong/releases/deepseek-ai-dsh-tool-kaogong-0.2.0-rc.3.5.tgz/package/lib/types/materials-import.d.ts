import { type MaterialImportPlan } from './materials-plan.ts';
export type MaterialJournal = {
    id: string;
    schema: 1;
    status: 'prepared' | 'applying' | 'unknown' | 'applied';
    plan: MaterialImportPlan;
    index: number;
    active?: number;
    started: boolean;
    notice?: string;
};
export interface MaterialTarget {
    entries(domain: 'bank' | 'knowledge'): Iterable<[string, unknown]>;
    read(domain: 'bank' | 'knowledge', id: string): unknown;
    write(domain: 'bank' | 'knowledge', id: string, value: unknown): Promise<unknown>;
}
export interface MaterialImportServices {
    store: {
        read(id: string): Promise<MaterialJournal | null>;
        write(row: MaterialJournal): Promise<unknown>;
    };
    source: {
        verify(plan: MaterialImportPlan, full?: boolean): Promise<void>;
    };
    target: {
        run<T>(target: MaterialImportPlan['target'], operation: (target: MaterialTarget) => Promise<T>, planId: string): Promise<T>;
    };
    privacy: {
        mark(instanceId: string, ids: string[], sourceRevision: string): Promise<unknown>;
    };
}
/** Explicit material-only intent; no learning state, Native Session or source writes exist in this interface. */
export declare class MaterialImportWorkflow {
    private readonly services;
    private tail;
    private closed;
    constructor(services: MaterialImportServices);
    private run;
    remember(plan: MaterialImportPlan): Promise<MaterialJournal>;
    private validate;
    inspect(id: string): Promise<MaterialJournal>;
    apply(input: {
        id: string;
        fingerprint: string;
        confirmed: boolean;
    }): Promise<MaterialJournal>;
    close(): Promise<void>;
}
