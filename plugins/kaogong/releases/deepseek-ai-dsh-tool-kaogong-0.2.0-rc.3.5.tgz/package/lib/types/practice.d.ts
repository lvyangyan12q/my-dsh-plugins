/**
 * Pure targeted-practice selection. No runtime dependencies: it chooses bank
 * questions for one practice session, either by an explicit knowledge point,
 * by subject, or by the weakest knowledge points derived from the notebook
 * (错题巩固).
 * @module kaogong/practice
 */
import type { Question, BankQuestion, Difficulty } from './types.ts';
/** Options controlling one practice selection. */
export interface PracticeOptions {
    /** 限定科目. */
    subject?: string;
    /** 限定考点（专项训练）. */
    knowledgePoint?: string;
    /** 为 true 时按错题本的薄弱考点抽题（错题巩固）. */
    weak?: boolean;
    /** 难度过滤. */
    difficulty?: Difficulty;
    /** 本轮优先排除的题目，用于连续练习避免重复。 */
    excludeIds?: readonly string[];
    /** 题目数量上限. */
    limit: number;
}
/** One practice selection result. */
export interface PracticeSelection {
    /** 错题巩固模式下命中的目标考点. */
    targets: string[];
    /** 选出的题目. */
    selected: BankQuestion[];
    /** 当前筛选条件下的已审题目总量. */
    totalAvailable: number;
    /** 为什么这样抽题的人话说明. */
    reason: string;
}
/**
 * Select bank questions for a practice session.
 * @param bank - the full question bank.
 * @param notebook - the wrong-answer notebook (for weak-point targeting).
 * @param opts - selection controls.
 * @returns the selection.
 */
export declare function selectPractice(bank: BankQuestion[], notebook: Question[], opts: PracticeOptions): PracticeSelection;
