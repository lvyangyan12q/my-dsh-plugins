import type { Context } from '@deepseek-ai/cordis';
import type { Config } from './business.ts';
/** Public SDK registration only; legacy stores are not opened or adopted on activation. */
export declare function mountKaogong(ctx: Context, config: Config): Promise<() => Promise<void>>;
