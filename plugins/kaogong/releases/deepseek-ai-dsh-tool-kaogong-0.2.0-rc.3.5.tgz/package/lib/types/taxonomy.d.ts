/**
 * Curated knowledge-point taxonomy and error-reason vocabulary for the
 * 武汉市公务员考试 (行政职业能力测验 + 申论). No runtime dependencies.
 *
 * 归纳问题点 relies on canonical subject/knowledgePoint labels: recording a
 * question against these labels lets the analysis group errors by a stable
 * knowledge point instead of free-form text.
 * @module kaogong/taxonomy
 */
/** One knowledge-point node; `children` lists finer-grained sub-points. */
export interface TaxonomySection {
    /** 考点/知识点名. */
    name: string;
    /** 下级考点（可选）. */
    children?: TaxonomySection[];
}
/** One exam subject/module with its knowledge-point tree. */
export interface TaxonomySubject {
    /** 科目/模块名. */
    subject: string;
    /** 一级考点分类. */
    sections: TaxonomySection[];
}
/** 武汉公务员考试（行测 + 申论）考点大纲. */
export declare const TAXONOMY: TaxonomySubject[];
/** 错因分类（记录错题时选择，也是归纳问题点的一个维度）. */
export declare const ERROR_REASONS: readonly ["知识点不会", "概念混淆", "审题不清", "计算/分析失误", "粗心大意", "方法不当/技巧缺失", "时间不够", "记忆模糊", "其他"];
/** Flatten the taxonomy into "subject | knowledgePoint" lines for display. */
export declare function renderTaxonomy(subject?: string): string;
/** One flattened knowledge point (subject + canonical knowledge point). */
export interface KnowledgePointRef {
    subject: string;
    knowledgePoint: string;
}
/**
 * Flatten the taxonomy into subject → knowledge-point references. A section
 * with children yields one reference per child (named `section-child`, the
 * same spelling the notebook uses); a leaf section yields itself.
 * @returns the flattened list in taxonomy order.
 */
export declare function flattenTaxonomy(): KnowledgePointRef[];
