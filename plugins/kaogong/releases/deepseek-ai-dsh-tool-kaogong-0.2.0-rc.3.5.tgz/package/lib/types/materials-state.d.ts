import type { KvTable } from '@deepseek-ai/dsh-storage-domain';
import type { MaterialJournal } from './materials-import.ts';
import type { MaterialImportPlan } from './materials-plan.ts';
export type StoredMaterialJournal = Omit<MaterialJournal, 'plan'> & {
    planId: string;
    planFingerprint: string;
    instanceId: string;
};
export type StoredMaterialPlan = {
    id: string;
    fingerprint: string;
    plan: MaterialImportPlan;
};
export declare const materialImportDomain: {
    name: string;
    version: number;
    tables: {
        journals: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, StoredMaterialJournal>;
        private_knowledge: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, {
            instanceId: string;
            id: string;
            sourceRevision: string;
        }>;
    };
};
export declare const materialPlansDomain: {
    name: string;
    version: number;
    tables: {
        plans: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, StoredMaterialPlan>;
    };
};
export declare function assertMaterialImportReady(table: Pick<KvTable<string, StoredMaterialJournal>, 'entries'>, instanceId: string): void;
/** A started source intent owns this library even when no business row has been written. */
export declare function assertMaterialImportAdmission(table: Pick<KvTable<string, StoredMaterialJournal>, 'entries'>, instanceId: string, allowedPlanId?: string): void;
