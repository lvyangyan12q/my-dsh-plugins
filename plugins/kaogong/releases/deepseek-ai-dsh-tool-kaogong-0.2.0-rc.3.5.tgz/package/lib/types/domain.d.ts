/**
 * Durable domain specs for the kaogong plugin: the wrong-answer notebook, the
 * study plan/progress, and the question bank. The zod record schemas live in
 * `schemas.ts` (pure, testable); this module binds them to storageDomain.
 * @module kaogong/domain
 */
import type { DomainGlobalSpec } from '@deepseek-ai/dsh-storage-domain';
export { questionRecord, planConfig, dayItem, dayPlan, bankQuestion, knowledgeEntry } from './schemas.ts';
export type { QuestionRecord, PlanConfig, DayPlanRecord, BankQuestionRecord, KnowledgeEntryRecord } from './schemas.ts';
/** The wrong-answer notebook domain: one `questions` table keyed by id. */
export declare const notebookDomainSpec: {
    name: string;
    version: number;
    tables: {
        questions: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, {
            subject: string;
            knowledgePoint: string;
            questionType: string;
            stem: string;
            options: string[];
            correctAnswer: string;
            userAnswer: string;
            result: "correct" | "wrong" | "skipped";
            errorReason: string;
            notes: string;
            source: string;
            tags: string[];
            createdAt: string;
            updatedAt: string;
            practiceRoundId?: string | undefined;
            practiceSequence?: number | undefined;
            practiceRevision?: number | undefined;
        }>;
    };
};
/** Default subjects: every taxonomy module, equal weight. */
export declare function defaultSubjects(): {
    name: string;
    weight: number;
}[];
export declare const progressDomainSpec: {
    name: string;
    version: number;
    global: DomainGlobalSpec<{
        examDate: string;
        dailyModules: number;
        subjects: {
            name: string;
            weight: number;
        }[];
    }>;
    tables: {
        days: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, {
            date: string;
            phase: "foundation" | "reinforce" | "sprint";
            items: {
                subject: string;
                kind: "learn" | "review" | "practice" | "mock";
                title: string;
                done: boolean;
            }[];
        }>;
    };
};
/** The question-bank domain: one `questions` table keyed by id, for targeted practice. */
export declare const bankDomainSpec: {
    name: string;
    version: number;
    tables: {
        questions: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, {
            subject: string;
            knowledgePoint: string;
            questionType: string;
            stem: string;
            options: string[];
            correctAnswer: string;
            explanation: string;
            difficulty: "easy" | "medium" | "hard";
            source: string;
            origin: "web" | "local";
            reviewStatus: "pending" | "approved" | "rejected";
            reviewNotes: string;
            tags: string[];
            createdAt: string;
            reviewedAt: string;
        }>;
    };
};
/** The knowledge-base domain: one `entries` table keyed by id, for study-material retrieval. */
export declare const knowledgeDomainSpec: {
    name: string;
    version: number;
    tables: {
        entries: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, {
            subject: string;
            knowledgePoint: string;
            title: string;
            content: string;
            kind: "讲义" | "笔记" | "时政" | "公式" | "技巧" | "真题解析" | "其他";
            source: string;
            tags: string[];
            createdAt: string;
            updatedAt: string;
        }>;
    };
};
/** Additive default-instance practice history; existing domains keep their versions. */
export declare const practiceDomainSpec: {
    name: string;
    version: number;
    tables: {
        rounds: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, {
            version: 1;
            context: {
                subject: string;
                title: string;
                limit: 10;
                knowledgePoint?: string | undefined;
                planIndex?: number | undefined;
            };
            questions: {
                subject: string;
                knowledgePoint: string;
                questionType: string;
                stem: string;
                options: string[];
                correctAnswer: string;
                explanation: string;
                difficulty: "easy" | "medium" | "hard";
                source: string;
                origin: "web" | "local";
                reviewStatus: "pending" | "approved" | "rejected";
                reviewNotes: string;
                tags: string[];
                createdAt: string;
                reviewedAt: string;
                id: string;
            }[];
            seenIds: string[];
            reason: string;
            totalAvailable: number;
            cycled: boolean;
            createdAt: string;
            reflections: {
                id: string;
                errorReason: string;
                notes?: string | undefined;
                savedAt?: string | undefined;
                notesRevision?: number | undefined;
            }[];
            revision: number;
            projectedRevision: number;
            changedAt: string;
            review: "ready" | "sending" | "sent";
            score?: {
                answers: {
                    id: string;
                    answer: string;
                }[];
                sequence: number;
                submittedAt: string;
            } | undefined;
            reviewClaim?: {
                taskId: string;
                requestId: string;
            } | undefined;
        }>;
    };
};
export declare const lessonDomainSpec: {
    name: string;
    version: number;
    global: DomainGlobalSpec<{
        instanceId: string;
        activeLessonId: string | null;
    }>;
    tables: {
        lessons: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, {
            version: 1;
            instanceId: string;
            request: {
                lessonId: string;
                subject: string;
                objective: string;
                materialIds: string[];
                requireReflections: boolean;
                knowledgePoint?: string | undefined;
                legacyNoteId?: string | undefined;
            };
            objectiveId: string;
            homeworkId: string;
            roleKey: {
                appId: "kaogong";
                instanceId: string;
                roleId: "teacher";
                subject: string;
            };
            binding: {
                sessionId: string;
                presetId: string;
            } | null;
            materials: {
                id: string;
                title: string;
                source: string;
                updatedAt: string;
            }[];
            roundIds: string[];
            notes: string;
            completion: {
                confirmedAt: string;
                proofs: {
                    roundId: string;
                    total: number;
                    correct: number;
                    questionIds: string[];
                    reflectedIds: string[];
                }[];
            } | null;
            createdAt: string;
            updatedAt: string;
            revision: number;
            legacyNote?: {
                id: string;
                updatedAt: string;
            } | undefined;
        }>;
    };
};
/** Legacy names are metadata for explicit adoption; opening them is not a read-only inspection. */
export declare const legacyDomainSpecs: Readonly<{
    notebook: {
        name: string;
        version: number;
        tables: {
            questions: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, {
                subject: string;
                knowledgePoint: string;
                questionType: string;
                stem: string;
                options: string[];
                correctAnswer: string;
                userAnswer: string;
                result: "correct" | "wrong" | "skipped";
                errorReason: string;
                notes: string;
                source: string;
                tags: string[];
                createdAt: string;
                updatedAt: string;
                practiceRoundId?: string | undefined;
                practiceSequence?: number | undefined;
                practiceRevision?: number | undefined;
            }>;
        };
    };
    progress: {
        name: string;
        version: number;
        global: DomainGlobalSpec<{
            examDate: string;
            dailyModules: number;
            subjects: {
                name: string;
                weight: number;
            }[];
        }>;
        tables: {
            days: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, {
                date: string;
                phase: "foundation" | "reinforce" | "sprint";
                items: {
                    subject: string;
                    kind: "learn" | "review" | "practice" | "mock";
                    title: string;
                    done: boolean;
                }[];
            }>;
        };
    };
    bank: {
        name: string;
        version: number;
        tables: {
            questions: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, {
                subject: string;
                knowledgePoint: string;
                questionType: string;
                stem: string;
                options: string[];
                correctAnswer: string;
                explanation: string;
                difficulty: "easy" | "medium" | "hard";
                source: string;
                origin: "web" | "local";
                reviewStatus: "pending" | "approved" | "rejected";
                reviewNotes: string;
                tags: string[];
                createdAt: string;
                reviewedAt: string;
            }>;
        };
    };
    knowledge: {
        name: string;
        version: number;
        tables: {
            entries: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, {
                subject: string;
                knowledgePoint: string;
                title: string;
                content: string;
                kind: "讲义" | "笔记" | "时政" | "公式" | "技巧" | "真题解析" | "其他";
                source: string;
                tags: string[];
                createdAt: string;
                updatedAt: string;
            }>;
        };
    };
    practice: {
        name: string;
        version: number;
        tables: {
            rounds: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, {
                version: 1;
                context: {
                    subject: string;
                    title: string;
                    limit: 10;
                    knowledgePoint?: string | undefined;
                    planIndex?: number | undefined;
                };
                questions: {
                    subject: string;
                    knowledgePoint: string;
                    questionType: string;
                    stem: string;
                    options: string[];
                    correctAnswer: string;
                    explanation: string;
                    difficulty: "easy" | "medium" | "hard";
                    source: string;
                    origin: "web" | "local";
                    reviewStatus: "pending" | "approved" | "rejected";
                    reviewNotes: string;
                    tags: string[];
                    createdAt: string;
                    reviewedAt: string;
                    id: string;
                }[];
                seenIds: string[];
                reason: string;
                totalAvailable: number;
                cycled: boolean;
                createdAt: string;
                reflections: {
                    id: string;
                    errorReason: string;
                    notes?: string | undefined;
                    savedAt?: string | undefined;
                    notesRevision?: number | undefined;
                }[];
                revision: number;
                projectedRevision: number;
                changedAt: string;
                review: "ready" | "sending" | "sent";
                score?: {
                    answers: {
                        id: string;
                        answer: string;
                    }[];
                    sequence: number;
                    submittedAt: string;
                } | undefined;
                reviewClaim?: {
                    taskId: string;
                    requestId: string;
                } | undefined;
            }>;
        };
    };
    lessons: {
        name: string;
        version: number;
        global: DomainGlobalSpec<{
            instanceId: string;
            activeLessonId: string | null;
        }>;
        tables: {
            lessons: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, {
                version: 1;
                instanceId: string;
                request: {
                    lessonId: string;
                    subject: string;
                    objective: string;
                    materialIds: string[];
                    requireReflections: boolean;
                    knowledgePoint?: string | undefined;
                    legacyNoteId?: string | undefined;
                };
                objectiveId: string;
                homeworkId: string;
                roleKey: {
                    appId: "kaogong";
                    instanceId: string;
                    roleId: "teacher";
                    subject: string;
                };
                binding: {
                    sessionId: string;
                    presetId: string;
                } | null;
                materials: {
                    id: string;
                    title: string;
                    source: string;
                    updatedAt: string;
                }[];
                roundIds: string[];
                notes: string;
                completion: {
                    confirmedAt: string;
                    proofs: {
                        roundId: string;
                        total: number;
                        correct: number;
                        questionIds: string[];
                        reflectedIds: string[];
                    }[];
                } | null;
                createdAt: string;
                updatedAt: string;
                revision: number;
                legacyNote?: {
                    id: string;
                    updatedAt: string;
                } | undefined;
            }>;
        };
    };
}>;
/** Only explicit platform instance identities enter the new namespace; never alias legacy default. */
export declare function instanceDomainSpecs(instanceId: string): {
    notebook: {
        name: string;
        version: number;
        tables: {
            questions: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, {
                subject: string;
                knowledgePoint: string;
                questionType: string;
                stem: string;
                options: string[];
                correctAnswer: string;
                userAnswer: string;
                result: "correct" | "wrong" | "skipped";
                errorReason: string;
                notes: string;
                source: string;
                tags: string[];
                createdAt: string;
                updatedAt: string;
                practiceRoundId?: string | undefined;
                practiceSequence?: number | undefined;
                practiceRevision?: number | undefined;
            }>;
        };
    };
    progress: {
        name: string;
        version: number;
        global: DomainGlobalSpec<{
            examDate: string;
            dailyModules: number;
            subjects: {
                name: string;
                weight: number;
            }[];
        }>;
        tables: {
            days: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, {
                date: string;
                phase: "foundation" | "reinforce" | "sprint";
                items: {
                    subject: string;
                    kind: "learn" | "review" | "practice" | "mock";
                    title: string;
                    done: boolean;
                }[];
            }>;
        };
    };
    bank: {
        name: string;
        version: number;
        tables: {
            questions: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, {
                subject: string;
                knowledgePoint: string;
                questionType: string;
                stem: string;
                options: string[];
                correctAnswer: string;
                explanation: string;
                difficulty: "easy" | "medium" | "hard";
                source: string;
                origin: "web" | "local";
                reviewStatus: "pending" | "approved" | "rejected";
                reviewNotes: string;
                tags: string[];
                createdAt: string;
                reviewedAt: string;
            }>;
        };
    };
    knowledge: {
        name: string;
        version: number;
        tables: {
            entries: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, {
                subject: string;
                knowledgePoint: string;
                title: string;
                content: string;
                kind: "讲义" | "笔记" | "时政" | "公式" | "技巧" | "真题解析" | "其他";
                source: string;
                tags: string[];
                createdAt: string;
                updatedAt: string;
            }>;
        };
    };
    practice: {
        name: string;
        version: number;
        tables: {
            rounds: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, {
                version: 1;
                context: {
                    subject: string;
                    title: string;
                    limit: 10;
                    knowledgePoint?: string | undefined;
                    planIndex?: number | undefined;
                };
                questions: {
                    subject: string;
                    knowledgePoint: string;
                    questionType: string;
                    stem: string;
                    options: string[];
                    correctAnswer: string;
                    explanation: string;
                    difficulty: "easy" | "medium" | "hard";
                    source: string;
                    origin: "web" | "local";
                    reviewStatus: "pending" | "approved" | "rejected";
                    reviewNotes: string;
                    tags: string[];
                    createdAt: string;
                    reviewedAt: string;
                    id: string;
                }[];
                seenIds: string[];
                reason: string;
                totalAvailable: number;
                cycled: boolean;
                createdAt: string;
                reflections: {
                    id: string;
                    errorReason: string;
                    notes?: string | undefined;
                    savedAt?: string | undefined;
                    notesRevision?: number | undefined;
                }[];
                revision: number;
                projectedRevision: number;
                changedAt: string;
                review: "ready" | "sending" | "sent";
                score?: {
                    answers: {
                        id: string;
                        answer: string;
                    }[];
                    sequence: number;
                    submittedAt: string;
                } | undefined;
                reviewClaim?: {
                    taskId: string;
                    requestId: string;
                } | undefined;
            }>;
        };
    };
    lessons: {
        name: string;
        global: {
            schema: import("zod").ZodObject<{
                instanceId: import("zod").ZodString;
                activeLessonId: import("zod").ZodNullable<import("zod").ZodString>;
            }, import("zod/v4/core").$strip>;
            initial: {
                instanceId: string;
                activeLessonId: null;
            };
        };
        tables: {
            lessons: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, {
                version: 1;
                instanceId: string;
                request: {
                    lessonId: string;
                    subject: string;
                    objective: string;
                    materialIds: string[];
                    requireReflections: boolean;
                    knowledgePoint?: string | undefined;
                    legacyNoteId?: string | undefined;
                };
                objectiveId: string;
                homeworkId: string;
                roleKey: {
                    appId: "kaogong";
                    instanceId: string;
                    roleId: "teacher";
                    subject: string;
                };
                binding: {
                    sessionId: string;
                    presetId: string;
                } | null;
                materials: {
                    id: string;
                    title: string;
                    source: string;
                    updatedAt: string;
                }[];
                roundIds: string[];
                notes: string;
                completion: {
                    confirmedAt: string;
                    proofs: {
                        roundId: string;
                        total: number;
                        correct: number;
                        questionIds: string[];
                        reflectedIds: string[];
                    }[];
                } | null;
                createdAt: string;
                updatedAt: string;
                revision: number;
                legacyNote?: {
                    id: string;
                    updatedAt: string;
                } | undefined;
            }>;
        };
        version: number;
    };
};
