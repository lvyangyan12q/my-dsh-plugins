/** One app-owned lease; external native calls cannot inherit a source's internal reentrant authority. */
export declare class CommandGate {
    private tail;
    private scope;
    run<T>(operation: () => Promise<T>): Promise<T>;
    external<T>(operation: () => Promise<T>): Promise<T>;
}
