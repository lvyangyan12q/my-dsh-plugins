import type { IncomingMessage, ServerResponse } from 'node:http';
import type { ResourceDirectory } from 'dsh-worktable/sdk';
import type { KaogongInstanceState } from './instance-state.ts';
import { type ProvenAssetPlan } from './adopted-assets.ts';
export declare const legacyAssetPaths: readonly ["/api/kaogong/legacy-image", "/api/kaogong/legacy-question-image"];
/** Mounted behind KaogongHost's authenticated owned-view boundary and command lifetime. */
export declare function legacyAssetRoutes(input: {
    instanceId: string;
    viewId: string;
    state: KaogongInstanceState;
    resources: Pick<ResourceDirectory, 'call'>;
    plans(): ProvenAssetPlan[];
    newImage?(id: string, reference: string): Promise<Buffer | undefined>;
}): {
    kind: "exact";
    path: "/api/kaogong/legacy-image" | "/api/kaogong/legacy-question-image";
    handler: (req: IncomingMessage, res: ServerResponse) => Promise<void>;
}[];
