import type { Context } from '@deepseek-ai/cordis';
import type { RoleSessionScopeOwner } from 'dsh-worktable/sdk';
import type { kaogongRolePresets } from './role-definitions.ts';
/** Trusted packaged role code only. The platform supplies a verified Native Agent context. */
export declare function kaogongRoleScopeOwner(ctx: Context, templates: Awaited<ReturnType<typeof kaogongRolePresets>>): RoleSessionScopeOwner;
