import type { Context } from '@deepseek-ai/cordis';
import type { Domain } from '@deepseek-ai/dsh-storage-domain';
import { type MaterialImportPlan } from './materials-plan.ts';
import { materialImportDomain, materialPlansDomain } from './materials-state.ts';
import type { Config } from './business.ts';
import type { KaogongHost } from './instance-host.ts';
export declare function materialPreview(plan: MaterialImportPlan, status?: string): {
    id: string;
    fingerprint: string;
    status: string;
    sourceRevision: string;
    sourceFiles: {
        name: string;
        sha256: string;
        bytes: number;
    }[];
    target: {
        instanceId: string;
        viewId: string;
        appId: "kaogong-library";
        projectId: string | null;
        revision?: number;
    };
    counts: Record<string, number>;
    notice: string;
};
/** Authenticated material-only owner. Mounting/listing does not open any old source. */
export declare function createMaterialImportOwner(ctx: Context, host: KaogongHost, state: Domain<typeof materialImportDomain>, plansDomain: Domain<typeof materialPlansDomain>, config: Config, assertPriorTargetReady: (instanceId: string) => void): {
    prepare: (viewId: string) => Promise<{
        id: string;
        fingerprint: string;
        status: string;
        sourceRevision: string;
        sourceFiles: {
            name: string;
            sha256: string;
            bytes: number;
        }[];
        target: {
            instanceId: string;
            viewId: string;
            appId: "kaogong-library";
            projectId: string | null;
            revision?: number;
        };
        counts: Record<string, number>;
        notice: string;
    }>;
    list: (viewId: string) => Promise<{
        id: string;
        fingerprint: string;
        status: string;
        sourceRevision: string;
        sourceFiles: {
            name: string;
            sha256: string;
            bytes: number;
        }[];
        target: {
            instanceId: string;
            viewId: string;
            appId: "kaogong-library";
            projectId: string | null;
            revision?: number;
        };
        counts: Record<string, number>;
        notice: string;
    }[]>;
    inspect: (viewId: string, id: string) => Promise<{
        id: string;
        fingerprint: string;
        status: string;
        sourceRevision: string;
        sourceFiles: {
            name: string;
            sha256: string;
            bytes: number;
        }[];
        target: {
            instanceId: string;
            viewId: string;
            appId: "kaogong-library";
            projectId: string | null;
            revision?: number;
        };
        counts: Record<string, number>;
        notice: string;
    }>;
    exportPlan: (viewId: string, id: string) => Promise<MaterialImportPlan>;
    apply: (viewId: string, input: {
        id: string;
        fingerprint: string;
        confirmed: boolean;
    }) => Promise<{
        id: string;
        fingerprint: string;
        status: string;
        sourceRevision: string;
        sourceFiles: {
            name: string;
            sha256: string;
            bytes: number;
        }[];
        target: {
            instanceId: string;
            viewId: string;
            appId: "kaogong-library";
            projectId: string | null;
            revision?: number;
        };
        counts: Record<string, number>;
        notice: string;
    }>;
    close(): Promise<void>;
};
