import type { Context } from '@deepseek-ai/cordis';
import type { ApplicationViewProps } from 'dsh-worktable/sdk';
import { KaogongStateContext, KaogongPresentationContext, KaogongViewState, KaogongViewStatePool } from './view-state.tsx';
export { KaogongView } from './kaogong-view.tsx';
export type { KaogongViewProps, KaogongTeachingRequest, PracticeContext, PracticeResult } from './kaogong-view.tsx';
export { KaogongStateContext, KaogongPresentationContext, KaogongViewState, KaogongViewStatePool };
export declare const inject: string[];
type ViewProps = ApplicationViewProps & {
    state?: KaogongViewState;
    presentation?: KaogongViewState;
};
export declare function KaogongApplicationView(props: ViewProps): import("react").JSX.Element;
export declare function KaogongLibraryView(props: ViewProps): import("react").JSX.Element;
/** No sidebar replacement, native renderer factory, Session context or old workbench runtime. */
export declare function apply(ctx: Context): void;
/** Frozen source-era launchers do not issue unscoped reads/writes from the new installed bundle. */
export declare function KaogongDashboard(): import("react").JSX.Element;
export declare const KaogongWorkbenchContent: typeof KaogongDashboard;
