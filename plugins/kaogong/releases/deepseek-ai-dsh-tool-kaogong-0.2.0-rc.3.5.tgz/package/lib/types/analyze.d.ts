/**
 * Pure analysis and summarization for the kaogong notebook. No runtime
 * dependencies: these functions turn an array of {@link Question} into
 * problem-point groupings (归纳问题点) and a study summary (总结问题).
 * @module kaogong/analyze
 */
import type { Question } from './types.ts';
/** One (reason, count) pair in a knowledge point's error breakdown. */
export interface ErrorReasonCount {
    reason: string;
    count: number;
}
/** Aggregated errors for one knowledge point. */
export interface KnowledgePointStat {
    knowledgePoint: string;
    subject: string;
    wrongCount: number;
    totalCount: number;
    errorRate: number;
    /** 错因分布，按次数降序. */
    errorReasons: ErrorReasonCount[];
    sampleIds: string[];
}
/** Aggregated errors for one subject/module. */
export interface SubjectStat {
    subject: string;
    wrongCount: number;
    totalCount: number;
    errorRate: number;
}
/** Aggregated counts for one error reason. */
export interface ErrorReasonStat {
    reason: string;
    count: number;
    knowledgePoints: string[];
}
/** Structured problem-point analysis (归纳问题点). */
export interface AnalysisResult {
    totalQuestions: number;
    totalCorrect: number;
    totalWrong: number;
    totalSkipped: number;
    accuracyRate: number;
    bySubject: SubjectStat[];
    byKnowledgePoint: KnowledgePointStat[];
    byErrorReason: ErrorReasonStat[];
}
/** One ranked weak point with a concrete suggestion. */
export interface WeakPoint {
    knowledgePoint: string;
    subject: string;
    wrongCount: number;
    totalCount: number;
    errorRate: number;
    topReasons: string[];
    suggestion: string;
}
/** The full study summary (总结问题). */
export interface SummaryResult {
    totalQuestions: number;
    totalCorrect: number;
    totalWrong: number;
    totalSkipped: number;
    accuracyRate: number;
    weakPoints: WeakPoint[];
    errorReasonBreakdown: ErrorReasonStat[];
    suggestions: string[];
    narrative: string;
}
/**
 * Group wrong answers by subject, knowledge point, and error reason.
 * Accuracy excludes skipped questions.
 * @param questions - the full notebook question list.
 * @returns the structured analysis.
 */
export declare function analyzeQuestions(questions: Question[]): AnalysisResult;
/**
 * Produce a ranked study summary from the full question list.
 * @param questions - the full notebook question list.
 * @param opts - `topN` limits the weak-point list.
 * @returns the structured summary with a narrative text.
 */
export declare function summarizeQuestions(questions: Question[], opts: {
    topN: number;
}): SummaryResult;
