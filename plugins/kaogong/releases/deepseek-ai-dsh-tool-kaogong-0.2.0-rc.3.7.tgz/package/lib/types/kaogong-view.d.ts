export type DashboardData = {
    today: string;
    examDate: string;
    daysToExam: number;
    totalDays: number;
    pastDays: number;
    pastDone: number;
    pastDonePct: number;
    totalQuestions: number;
    totalCorrect: number;
    totalWrong: number;
    accuracyRate: number;
    bankTotal: number;
    knowledgeTotal: number;
    todayPlan: {
        phase: string;
        items: {
            subject: string;
            kind: string;
            title: string;
            done: boolean;
        }[];
    };
    modules: {
        subject: string;
        availableCount: number;
        practicedCount: number;
        wrongCount: number;
        accuracyRate: number;
    }[];
    weakPoints: {
        subject: string;
        knowledgePoint: string;
        wrongCount: number;
        errorRate: number;
    }[];
    recentKnowledge: {
        id: string;
        title: string;
        subject: string;
        knowledgePoint: string;
        kind: string;
        content: string;
        updatedAt: string;
    }[];
};
export type KaogongViewProps = {
    /** Hide without unmounting to retain the current practice and reader state. */
    embedded?: boolean;
    /** Focused classrooms exclude dashboard statistics; the explicit plan page keeps its metrics. */
    focusedStudy?: boolean;
    active?: boolean;
    pageId?: string;
    onSelectPage?: (pageId: string) => void;
    onClose?: () => void;
    /** Explicit user teaching action. Structured evidence is not a Session binding or system instruction. */
    onOpenTeacher: (prompt: string, request: KaogongTeachingRequest, options?: TeachingTaskOptions) => void | Promise<void>;
};
export type TeachingTaskOptions = {
    beforeSend?: () => void | Promise<void>;
    afterSend?: () => void | Promise<void>;
};
type PracticeQuestion = {
    id: string;
    subject: string;
    knowledgePoint: string;
    stem: string;
    options: string[];
    difficulty: string;
    source: string;
};
export type PracticeData = {
    roundId: string;
    context: PracticeContext;
    reason: string;
    totalAvailable: number;
    returned: number;
    cycled: boolean;
    questions: PracticeQuestion[];
    result: PracticeResult | null;
    reflections: {
        id: string;
        errorReason: string;
        notes?: string;
    }[];
};
export type PracticeResult = {
    roundId: string;
    projection: 'complete' | 'pending';
    review: 'ready' | 'sending' | 'sent';
    totalCount: number;
    correctCount: number;
    accuracyRate: number;
    results: {
        id: string;
        subject: string;
        knowledgePoint: string;
        stem: string;
        options: string[];
        source: string;
        userAnswer: string;
        correct: boolean;
        correctAnswer: string;
        explanation: string;
    }[];
};
export type PracticeContext = {
    subject: string;
    title: string;
    knowledgePoint?: string;
    limit: number;
    planIndex?: number;
};
/** Ticket 06 can resolve a role binding from this evidence without parsing the legacy prompt. */
export type KaogongTeachingRequest = {
    kind: 'lesson';
    context: Readonly<PracticeContext>;
    lessonEvidence?: {
        id: string;
        title: string;
        source: string;
        content: string;
    };
} | {
    kind: 'review';
    context: Readonly<PracticeContext>;
    result: Readonly<PracticeResult>;
};
export type ModuleSummary = {
    totalQuestions: number;
    totalCorrect: number;
    totalWrong: number;
    accuracyRate: number;
    weakPoints: {
        knowledgePoint: string;
        wrongCount: number;
        totalCount: number;
        errorRate: number;
        topReasons: string[];
        suggestion: string;
    }[];
    suggestions: string[];
};
export declare function KaogongView({ embedded, focusedStudy, active, pageId, onSelectPage, onClose, onOpenTeacher }: KaogongViewProps): import("react").JSX.Element;
export {};
