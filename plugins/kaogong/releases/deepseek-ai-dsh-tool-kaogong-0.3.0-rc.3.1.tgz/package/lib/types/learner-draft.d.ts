export type LearnerDraft = {
    version: 1;
    form: boolean;
    lessonId: string | null;
    notes: string;
    notesDirty: boolean;
    goal?: {
        id: string;
        subject: string;
        objective: string;
        knowledgePoint: string;
        reflections: boolean;
        practice?: boolean;
        material: boolean;
        legacyNoteId: string;
    };
};
export declare function readLearnerDraft(id: string): LearnerDraft | null;
export declare function writeLearnerDraft(id: string, value: LearnerDraft): void;
export declare function readLessonNotesDraft(id: string, lessonId: string): LearnerDraft | null;
