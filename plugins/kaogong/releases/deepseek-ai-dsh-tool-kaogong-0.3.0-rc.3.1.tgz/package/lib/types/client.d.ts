import type { Context } from '@deepseek-ai/cordis';
import type { MainPanelId } from '@deepseek-ai/dsh-client-ui-layout/client';
import type { PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import { KaogongStateContext, KaogongPresentationContext, KaogongViewState, KaogongViewStatePool } from './view-state.tsx';
import type { StudySessionNavigation } from './study-native-navigation.ts';
import type { StudyViewProps } from './study-client-contracts.ts';
export { KaogongView } from './kaogong-view.tsx';
export type { KaogongViewProps, KaogongTeachingRequest, PracticeContext, PracticeResult } from './kaogong-view.tsx';
export { KaogongStateContext, KaogongPresentationContext, KaogongViewState, KaogongViewStatePool };
export declare const inject: string[];
export declare const panelId: MainPanelId;
export declare const learningTabId = "kaogong.learning-panel";
declare module '@deepseek-ai/dsh-client-ui-sidebar-right/client' {
    interface SidebarRightTabParamsMap {
        'kaogong-learning': StudySessionNavigation;
    }
}
type NativeStudyUI = {
    open(target: StudySessionNavigation): Promise<void>;
    returnOverview(): void;
};
type SurfaceProps = {
    native?: NativeStudyUI;
    pool?: KaogongViewStatePool;
};
export declare function ScopedStudyView(props: StudyViewProps & SurfaceProps & {
    sessionId?: string;
}): import("react/jsx-runtime").JSX.Element;
/** Opening the panel reads existing profiles; profile creation is an explicit confirmation. */
export declare function StudyDashboard({ native, pool }: SurfaceProps): import("react/jsx-runtime").JSX.Element;
type LearningTabProps = PropsRuntime<'sidebar.right.pane.tab'> & SurfaceProps;
export declare function StudyLearningTab(props: LearningTabProps): import("react/jsx-runtime").JSX.Element;
/** Register only public Native seats. The existing Native Conversation remains untouched. */
export declare function apply(ctx: Context): void;
export declare const KaogongDashboard: typeof StudyDashboard;
export declare const KaogongApplicationView: typeof ScopedStudyView;
export declare const KaogongLibraryView: typeof ScopedStudyView;
export declare const KaogongWorkbenchContent: typeof StudyDashboard;
