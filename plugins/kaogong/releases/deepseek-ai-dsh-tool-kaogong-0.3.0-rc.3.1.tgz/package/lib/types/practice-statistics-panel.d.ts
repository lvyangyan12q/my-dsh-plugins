import type { PracticeCounts } from './practice-statistics.ts';
type Statistics = PracticeCounts & {
    errorReasons?: {
        reason: string;
        count: number;
    }[];
};
/** Counts reflect scored question slots, independently from task completion or self-reported exams. */
export declare function PracticeStatisticsPanel({ statistics, detailed }: {
    statistics?: Statistics;
    detailed?: boolean;
}): import("react/jsx-runtime").JSX.Element;
export {};
