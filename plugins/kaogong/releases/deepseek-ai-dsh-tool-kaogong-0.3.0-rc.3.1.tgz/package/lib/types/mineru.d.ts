export interface MineruConfig {
    token?: string;
    model?: 'vlm' | 'pipeline';
    outputDir?: string;
}
interface Job {
    id: string;
    batchId: string;
    source: string;
    subject: string;
    title: string;
    pages: string;
}
export declare function safeAsset(path: string): string;
export declare function rewriteImages(markdown: string, id: string, directory: string, files: Set<string>): string;
export declare class Mineru {
    private config;
    private defaultRoot?;
    private fetcher;
    constructor(config: () => MineruConfig, defaultRoot?: string, fetcher?: typeof fetch);
    root(): string;
    jobDir(id: string): string;
    api(path: string, body?: unknown): Promise<any>;
    start(source: string, subject: string, pages?: string): Promise<{
        id: `${string}-${string}-${string}-${string}-${string}`;
        state: string;
        pages: string;
    }>;
    collect(id: string): Promise<{
        state: string;
        job: Job;
        content?: string;
    }>;
    image(id: string, asset: string): Promise<Buffer<ArrayBufferLike>>;
}
export {};
