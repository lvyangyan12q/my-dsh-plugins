import type { Context } from '@deepseek-ai/cordis';
import type { StudyWorkspace } from './study-workspace.ts';
import type { StudyRoles } from './study-roles.ts';
import type { StudySources } from './study-sources.ts';
import type { TeachingOwner, TeachingTask } from './study-contracts.ts';
type Reference = {
    resourceId: string;
    selection?: unknown;
};
type CapturedContext = {
    id: string;
    title: string;
    text: string;
    reference: Reference;
    fingerprint: string;
};
type Draft = Omit<TeachingTask, 'preparation'> & {
    revision: number;
    text: string;
    contexts: CapturedContext[];
    bindingRevision: number;
    source: {
        viewId: string;
    };
    instanceRevision: number;
    preparation?: TeachingTask['preparation'];
    notice?: string;
    [key: string]: unknown;
};
/** Preparation, Native admission and business finalization are distinct durable
 * facts. No model loop is awaited here and unknown admission never resends. */
export declare class StudyTeaching {
    private ctx;
    private workspace;
    private roles;
    private sources;
    private owners;
    private pending;
    private stopped;
    constructor(ctx: Context, workspace: StudyWorkspace, roles: StudyRoles, sources: StudySources);
    register(kind: 'lesson' | 'review', owner: TeachingOwner): () => void;
    private serial;
    private table;
    private row;
    private put;
    private present;
    private owner;
    list(viewId: string): Promise<Draft[]>;
    private create;
    prepare(viewId: string, input: {
        roleId: string;
        text: unknown;
        contexts?: Reference[];
    }): Promise<Draft>;
    prepareOwned(viewId: string, input: {
        roleId: string;
        kind: 'lesson' | 'review';
        payload: unknown;
    }): Promise<Draft>;
    private owned;
    edit(viewId: string, id: string, revision: number, text: unknown, contexts: {
        id: string;
        text: string;
    }[]): Promise<Draft>;
    discard(viewId: string, id: string, revision: number): Promise<Draft>;
    private validate;
    private finalize;
    submit(viewId: string, id: string, revision: number): Promise<Draft>;
    recover(viewId: string, id: string): Promise<Draft>;
    close(): Promise<void>;
}
export {};
