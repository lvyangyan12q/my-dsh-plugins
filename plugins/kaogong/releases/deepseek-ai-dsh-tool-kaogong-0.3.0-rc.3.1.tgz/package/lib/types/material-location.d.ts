import * as fs from 'node:fs/promises';
import type { LegacyMaterialEvidence } from './legacy-material-evidence.mjs';
import { type MaterialLocationMap } from './material-location-map.mjs';
/** Private plan-owned receipt. Original evidence is retained verbatim, never rebased. */
export type MaterialLocation = {
    map: MaterialLocationMap;
    originalEvidence: LegacyMaterialEvidence;
};
/** Called only by an explicit new preview. Later reads use the receipt, not mutable configuration files. */
export declare function captureMaterialLocation(input: {
    mapFile?: string;
    evidenceFile?: string;
    materialRoot?: string;
}): Promise<MaterialLocation | undefined>;
export declare function materialLocationIO(location?: MaterialLocation): Promise<typeof fs>;
/** Coverage and byte receipts must agree; path and root identities remain separately recorded. */
export declare function assertRelocatedEvidence(location: MaterialLocation | undefined, evidence?: LegacyMaterialEvidence): void;
