import type { StudyRoleDefinition as RoleDefinition, StudyCapability as PrivateCapability } from './study-contracts.ts';
export declare const legacyTeacherPresetId = "personal-workbench.kaogong-teacher.v1";
export declare const teachingSkillProvider = "kaogong-packaged-teaching";
export declare const roleSubjects: string[];
export declare const subjectRoleIds: string[];
/** Application-owned personas and trusted installation Skill root; never loads roles/cordis.yml. */
export declare function kaogongRolePresets(): Promise<{
    id: string;
    roleId: string;
    name: string;
    description: string;
    plugins: ({
        name: "@deepseek-ai/dsh-persona";
        config: {
            prefix: string;
            complete: boolean;
            includeRuntimeContext: boolean;
            providerName?: undefined;
            includeDefaultRoots?: undefined;
            customSkillDirs?: undefined;
            bundledSkillDir?: undefined;
            watch?: undefined;
        };
    } | {
        name: "@deepseek-ai/dsh-skill-filesystem";
        config: {
            providerName: string;
            includeDefaultRoots: boolean;
            customSkillDirs: never[];
            bundledSkillDir: string;
            watch: boolean;
            prefix?: undefined;
            complete?: undefined;
            includeRuntimeContext?: undefined;
        };
    } | {
        name: "@deepseek-ai/dsh-tool-skill";
        config: {
            prefix?: undefined;
            complete?: undefined;
            includeRuntimeContext?: undefined;
            providerName?: undefined;
            includeDefaultRoots?: undefined;
            customSkillDirs?: undefined;
            bundledSkillDir?: undefined;
            watch?: undefined;
        };
    } | {
        name: "@deepseek-ai/dsh-tool-ask-user";
        config: {
            prefix?: undefined;
            complete?: undefined;
            includeRuntimeContext?: undefined;
            providerName?: undefined;
            includeDefaultRoots?: undefined;
            customSkillDirs?: undefined;
            bundledSkillDir?: undefined;
            watch?: undefined;
        };
    })[];
}[]>;
/** Explicit deployment location is captured by each durable intent, not inferred from process cwd. */
export declare function kaogongPrivateCapabilities(): PrivateCapability[];
export declare function kaogongRoleDefinitions(cwd?: string): RoleDefinition[];
