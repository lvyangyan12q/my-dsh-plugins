import type { PracticeRound } from './schemas.ts';
import type { Question } from './types.ts';
export interface PracticeCounts {
    submittedRoundCount: number;
    submittedCount: number;
    answeredCount: number;
    unansweredCount: number;
    uniqueQuestionCount: number;
    correctCount: number;
    incorrectCount: number;
    accuracyRate: number;
}
/** The immutable scored-round ledger is the only source of system grades.
 * Notebook projections, unsubmitted rounds and external self-reports are excluded. */
type ScoredAttempt = Question & {
    practiceRoundId: string;
};
export declare function scoredAttempts(rounds: Iterable<readonly [string, PracticeRound]>, subject?: string): ScoredAttempt[];
export declare function practiceStatistics(rounds: Iterable<readonly [string, PracticeRound]>, subject?: string): {
    denominator: "submitted-question-slots";
    bySubject: {
        submittedRoundCount: number;
        submittedCount: number;
        answeredCount: number;
        unansweredCount: number;
        uniqueQuestionCount: number;
        correctCount: number;
        incorrectCount: number;
        accuracyRate: number;
        subject: string;
    }[];
    byKnowledgePoint: import("./analyze.ts").KnowledgePointStat[];
    errorReasons: import("./analyze.ts").ErrorReasonStat[];
    submittedRoundCount: number;
    submittedCount: number;
    answeredCount: number;
    unansweredCount: number;
    uniqueQuestionCount: number;
    correctCount: number;
    incorrectCount: number;
    accuracyRate: number;
};
export declare function practiceSummary(rounds: Iterable<readonly [string, PracticeRound]>, subject: string, topN: number): {
    accuracyRate: number;
    narrative: string;
    submittedRoundCount: number;
    submittedCount: number;
    answeredCount: number;
    unansweredCount: number;
    uniqueQuestionCount: number;
    correctCount: number;
    incorrectCount: number;
    totalQuestions: number;
    totalCorrect: number;
    totalWrong: number;
    totalSkipped: number;
    weakPoints: import("./analyze.ts").WeakPoint[];
    errorReasonBreakdown: import("./analyze.ts").ErrorReasonStat[];
    suggestions: string[];
};
export {};
