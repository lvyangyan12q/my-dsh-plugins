import type { Context } from '@deepseek-ai/cordis';
import type { StudyWorkspace } from './study-workspace.ts';
/** Explicit current-study metadata transfer inside one Native home. Original
 * business domains, Native Sessions and immutable source receipts stay in place. */
export declare class CurrentStudyHandoff {
    private ctx;
    private workspace;
    private sourceProfile?;
    private pending;
    constructor(ctx: Context, workspace: StudyWorkspace, sourceProfile?: string | undefined);
    private table;
    private present;
    private serial;
    private capture;
    private validateNative;
    preview(): Promise<{
        id: string;
        digest: string;
        status: "unknown" | "applying" | "prepared" | "applied";
        sourceProfile: string;
        runtimeProfile: string;
        home: string;
        profiles: {
            [x: string]: unknown;
            id: string;
            kind: "learner" | "library";
            title: string;
            revision: number;
            projectId?: string | null | undefined;
        }[];
        views: {
            [x: string]: unknown;
            id: string;
            profileId: string;
        }[];
        bindings: {
            instanceId: any;
            roleId: any;
            sessionId: any;
            presetId: any;
            phase: any;
            revision: any;
            creation: any;
        }[];
        grants: {
            id: any;
            ownerInstanceId: any;
            consumerInstanceId: any;
            resourceId: any;
            status: any;
            revision: any;
        }[];
        teaching: {
            id: any;
            instanceId: any;
            status: any;
            requestId: any;
            ownerFinalization: any;
        }[];
        files: {
            path: string;
            sha256: string;
            bytes: number;
        }[];
        conflicts: string[];
        notice: string;
    }>;
    confirm(input: {
        id: string;
        digest: string;
        confirmed: boolean;
        continueProfileId?: string;
    }): Promise<{
        id: string;
        digest: string;
        status: "unknown" | "applying" | "prepared" | "applied";
        sourceProfile: string;
        runtimeProfile: string;
        home: string;
        profiles: {
            [x: string]: unknown;
            id: string;
            kind: "learner" | "library";
            title: string;
            revision: number;
            projectId?: string | null | undefined;
        }[];
        views: {
            [x: string]: unknown;
            id: string;
            profileId: string;
        }[];
        bindings: {
            instanceId: any;
            roleId: any;
            sessionId: any;
            presetId: any;
            phase: any;
            revision: any;
            creation: any;
        }[];
        grants: {
            id: any;
            ownerInstanceId: any;
            consumerInstanceId: any;
            resourceId: any;
            status: any;
            revision: any;
        }[];
        teaching: {
            id: any;
            instanceId: any;
            status: any;
            requestId: any;
            ownerFinalization: any;
        }[];
        files: {
            path: string;
            sha256: string;
            bytes: number;
        }[];
        conflicts: string[];
        notice: string;
    }>;
    close(): Promise<void>;
}
