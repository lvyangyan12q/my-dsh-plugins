import type { StudyTeaching as ApplicationTaskOwners } from './study-teaching.ts';
import type { StudySources as ResourceDirectory } from './study-sources.ts';
import type { KvTable } from '@deepseek-ai/dsh-storage-domain';
import type { KaogongHost } from './instance-host.ts';
export type TaskReceipt = {
    instanceId: string;
    businessId: string;
    kind: 'review' | 'lesson';
    requestId: string;
    status: 'claimed' | 'done' | 'releasing' | 'rejected';
};
/** Claims precede native admission; only a known persisted native receipt finalizes business state. */
export declare function registerTaskOwners(host: KaogongHost, owners: ApplicationTaskOwners, receipts: KvTable<string, TaskReceipt>, resources: ResourceDirectory): () => Promise<void>;
