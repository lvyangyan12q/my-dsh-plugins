import type { BusinessRegistry } from './business.ts';
import type { KaogongInstanceState } from './instance-state.ts';
/** Adds descriptors only to the private business registry. production-host wraps
 * every descriptor in KaogongHost.http: admit -> owned view -> readiness -> lease.
 * This function never registers directly against the actual Host webServer. */
export declare function registerStudyPlanRoutes(registry: BusinessRegistry, state: KaogongInstanceState): () => void;
