import type { Dispatch, SetStateAction } from 'react';
import type { RoleFacade, TaskFacade } from './study-client-contracts.ts';
import type { LearningRoleKey } from './client-runtime.ts';
import type { DashboardData, PracticeData, PracticeContext, PracticeResult, ModuleSummary } from './kaogong-view.tsx';
import type { Entry } from './knowledge-reader.tsx';
import type { LessonView } from './lesson-schema.ts';
/** Fixed types and namespaces for the default instance's transient values. */
type ViewValues = {
    dashboard: DashboardData | null;
    loading: boolean;
    error: string | null;
    notice: string | null;
    practice: PracticeData | null;
    practiceItem: PracticeContext | null;
    answers: Record<string, string>;
    result: PracticeResult | null;
    seenQuestionIds: string[];
    errorReasons: Record<string, string>;
    moduleSummary: ModuleSummary | null;
    submitting: boolean;
    practiceRestored: boolean;
    practiceBusy: boolean;
    practicePreparing: boolean;
    practicePreparationError: string | null;
    reflectionNotes: Record<string, string>;
    practiceHistory: {
        roundId: string;
        context: PracticeContext;
        createdAt: string;
        submitted: boolean;
    }[];
    'reader.store': {
        dispose(): void;
    } | null;
    'review.admitted': string[];
    'reader.query': string;
    'reader.entries': Entry[];
    'reader.selected': string;
    'reader.entry': Entry | null;
    'reader.error': string;
    'reader.loading': boolean;
    'reader.refresh': number;
    integration: {
        service: unknown;
    } | null;
    open: boolean;
    teacherHandoff: {
        prompt: string;
        copied: boolean;
    } | null;
    roles: RoleFacade | null;
    tasks: TaskFacade | null;
    'study.open': boolean;
    'study.page': string | null;
    'study.pane': 'content' | 'conversation';
    'roles.teacherSubject': string;
    'roles.selected': LearningRoleKey;
    'roles.opened': LearningRoleKey[];
    'lesson.view': LessonView | null;
    'lesson.resumeId': string | null;
    'lesson.list': {
        id: string;
        subject: string;
        objective: string;
        completed: boolean;
        updatedAt: string;
    }[];
    'lesson.draft': {
        id: string;
        subject: string;
        objective: string;
        knowledgePoint: string;
        reflections: boolean;
        practice?: boolean;
        material: boolean;
        legacyNoteId: string;
    };
    'lesson.form': boolean;
    'lesson.notes': string;
    'lesson.notesDirty': boolean;
    'lesson.error': string;
    'lesson.busy': boolean;
    'lesson.confirmed': boolean;
};
type Cell<T> = {
    value: T;
    listeners: Set<() => void>;
    set: Dispatch<SetStateAction<T>>;
};
/** Plugin-owned transient learning state, retained across optional view disposal. */
export declare class KaogongViewState {
    readonly instanceId: string;
    readonly viewId?: string | undefined;
    private cells;
    private requests;
    private practiceCommand;
    private changingLesson;
    constructor(instanceId?: string, viewId?: string | undefined);
    private saveLearnerDraft;
    resumeLesson(view: LessonView, notes: string, dirty: boolean): void;
    private saveDisplayChoices;
    /** Acquire the shared practice command owner synchronously before React rerenders. */
    beginPracticeCommand(): (() => void) | null;
    /** Supersede earlier reads while allowing a pending practice command to survive view transfer. */
    request(key: 'dashboard' | 'practice' | 'lesson'): () => boolean;
    /** Get one typed cell; each application-owned key has one fixed value type. */
    cell<K extends keyof ViewValues>(key: K, initial: ViewValues[K]): Cell<ViewValues[K]>;
}
/** Client plugin lifetime, not view lifetime, owns shared business state. */
export declare class KaogongViewStatePool {
    private states;
    private views;
    forInstance(instanceId: string): KaogongViewState;
    forView(instanceId: string, viewId: string): KaogongViewState;
    dispose(): void;
}
export declare const KaogongStateContext: import("react").Context<KaogongViewState | null>;
export declare const KaogongPresentationContext: import("react").Context<KaogongViewState | null>;
/** Retain a business value in the plugin owner, or locally for standalone consumers. */
export declare function useBusinessState<K extends keyof ViewValues>(key: K, initial: ViewValues[K]): [ViewValues[K], Dispatch<SetStateAction<ViewValues[K]>>];
/** Resolve the same request owner for both standalone and workbench views. */
export declare function useRequestOwner(): KaogongViewState;
export {};
