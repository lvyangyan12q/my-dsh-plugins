export declare function modelToolAccess(name: string): 'read' | 'write' | undefined;
export declare function requireModelToolAccess(name: string): 'read' | 'write';
