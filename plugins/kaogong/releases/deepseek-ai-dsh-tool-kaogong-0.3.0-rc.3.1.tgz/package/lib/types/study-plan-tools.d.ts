import type { BusinessRegistry } from './business.ts';
import type { StudyPlan } from './study-plan.ts';
export declare function registerStudyPlanTools(registry: BusinessRegistry, plan: StudyPlan): void;
