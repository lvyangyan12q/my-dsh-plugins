import type { StudySources as ResourceDirectory } from './study-sources.ts';
import { type LegacyAdoptionPlan } from './legacy-adoption-plan.ts';
import { readLegacyMaterialAsset } from './legacy-material-evidence.mjs';
import { readLegacyBankImageAsset } from './legacy-bank-image-evidence.mjs';
import { readLegacyPrivateAsset } from './legacy-private-assets.mjs';
import type { MaterialImportPlan } from './materials-plan.ts';
export type ProvenAssetPlan = LegacyAdoptionPlan | MaterialImportPlan;
export type AdoptedAssetReaders = {
    material: typeof readLegacyMaterialAsset;
    bank: typeof readLegacyBankImageAsset;
    private: typeof readLegacyPrivateAsset;
};
/** All paths, source IDs and binding keys come from immutable trusted plans, never request fields. */
export declare function readAdoptedAsset(input: {
    kind: 'knowledge' | 'bank';
    id: string;
    reference: string;
    instanceId: string;
    viewId: string;
    ownRecord: unknown;
    plans: readonly ProvenAssetPlan[];
    resources: Pick<ResourceDirectory, 'call'>;
    readers?: AdoptedAssetReaders;
}): Promise<Buffer<ArrayBufferLike>>;
