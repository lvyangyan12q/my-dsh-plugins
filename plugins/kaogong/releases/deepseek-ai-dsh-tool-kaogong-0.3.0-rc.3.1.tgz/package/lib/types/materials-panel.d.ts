export declare function MaterialImportPanel({ viewId, onApplied }: {
    viewId: string;
    onApplied(): void;
}): import("react/jsx-runtime").JSX.Element;
