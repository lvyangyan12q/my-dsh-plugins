import type { Domain, DomainFacility } from '@deepseek-ai/dsh-storage-domain';
import { z } from 'zod';
declare const profile: z.ZodObject<{
    id: z.ZodString;
    kind: z.ZodEnum<{
        learner: "learner";
        library: "library";
    }>;
    title: z.ZodString;
    revision: z.ZodNumber;
    projectId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
}, z.core.$loose>;
declare const view: z.ZodObject<{
    id: z.ZodString;
    profileId: z.ZodString;
}, z.core.$loose>;
export declare const studyWorkspaceDomain: {
    name: string;
    version: number;
    global: {
        schema: z.ZodObject<{
            profiles: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                kind: z.ZodEnum<{
                    learner: "learner";
                    library: "library";
                }>;
                title: z.ZodString;
                revision: z.ZodNumber;
                projectId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$loose>>;
            views: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                profileId: z.ZodString;
            }, z.core.$loose>>;
            lastProfileId: z.ZodNullable<z.ZodString>;
        }, z.core.$strip>;
        initial: {
            profiles: never[];
            views: never[];
            lastProfileId: null;
        };
    };
    tables: {
        bindings: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, {
            [x: string]: unknown;
            instanceId: string;
            roleId: string;
            sessionId: string;
            presetId: string;
            phase: "ready" | "intent";
            revision: number;
            creation: {
                cwd: string;
            };
            previousSessionIds: string[];
        }>;
        grants: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, {
            [x: string]: unknown;
            id: string;
            ownerInstanceId: string;
            consumerInstanceId: string;
            resourceId: "materials" | "question-bank";
            status: "active" | "revoked";
            revision: number;
        }>;
        teaching: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, {
            [x: string]: unknown;
            id: string;
            instanceId: string;
            roleId: string;
            sessionId: string;
            status: string;
            revision: number;
        }>;
        handoffs: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, unknown>;
    };
};
export type StudyProfile = z.infer<typeof profile>;
export type StudyView = z.infer<typeof view>;
export type StudyWorkspaceDomain = Domain<typeof studyWorkspaceDomain>;
/** Only study profiles and their registered browser contexts live here. It does
 * not discover applications, run migrations, or open an old global domain. */
export declare class StudyWorkspace {
    readonly domain: StudyWorkspaceDomain;
    private pending;
    private stopped;
    constructor(domain: StudyWorkspaceDomain);
    static open(facility: Pick<DomainFacility, 'open'>): Promise<StudyWorkspace>;
    change<T>(operation: (state: ReturnType<StudyWorkspaceDomain['global']['get']>) => T): Promise<T>;
    list(): Promise<{
        profiles: {
            [x: string]: unknown;
            id: string;
            kind: "learner" | "library";
            title: string;
            revision: number;
            projectId?: string | null | undefined;
        }[];
        views: {
            [x: string]: unknown;
            id: string;
            profileId: string;
        }[];
        lastProfileId: string | null;
    }>;
    create(title: unknown, kind: unknown, confirmed: unknown): Promise<{
        profile: {
            [x: string]: unknown;
            id: string;
            kind: "learner" | "library";
            title: string;
            revision: number;
            projectId?: string | null | undefined;
        };
        view: {
            [x: string]: unknown;
            id: string;
            profileId: string;
        };
    }>;
    open(id: unknown): Promise<{
        profile: {
            [x: string]: unknown;
            id: string;
            kind: "learner" | "library";
            title: string;
            revision: number;
            projectId?: string | null | undefined;
        };
        view: {
            [x: string]: unknown;
            id: string;
            profileId: string;
        };
    }>;
    assertProfile(id: string): Promise<{
        [x: string]: unknown;
        id: string;
        kind: "learner" | "library";
        title: string;
        revision: number;
        projectId?: string | null | undefined;
    }>;
    resolveView(id: string): Promise<{
        profile: {
            [x: string]: unknown;
            id: string;
            kind: "learner" | "library";
            title: string;
            revision: number;
            projectId?: string | null | undefined;
        };
        application: {
            id: string;
            title: string;
            kind: "deep";
            enabled: boolean;
        };
        instance: {
            appId: string;
            projectId: string | null;
            id: string;
            kind: "learner" | "library";
            title: string;
            revision: number;
        };
        view: {
            instanceId: string;
            type: string;
            id: string;
            profileId: string;
        };
    }>;
    snapshot(): Promise<{
        applications: {
            id: string;
            title: string;
            kind: "deep";
            enabled: boolean;
        }[];
        instances: {
            appId: string;
            projectId: string | null;
            id: string;
            kind: "learner" | "library";
            title: string;
            revision: number;
        }[];
        views: {
            instanceId: string;
            type: string;
            id: string;
            profileId: string;
        }[];
    }>;
    close(): Promise<void>;
}
export {};
