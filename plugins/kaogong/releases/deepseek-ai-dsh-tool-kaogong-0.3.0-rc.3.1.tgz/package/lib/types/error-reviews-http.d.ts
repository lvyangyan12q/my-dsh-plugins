import type { BusinessRegistry } from './business.ts';
import type { KaogongInstanceState } from './instance-state.ts';
export declare function registerErrorReviews(ctx: BusinessRegistry, state: KaogongInstanceState): void;
