import type { RoleFacade, TaskFacade } from './study-client-contracts.ts';
export declare function studyRequest<T>(body?: Record<string, unknown>, signal?: AbortSignal): Promise<T>;
export declare function createStudyServices(viewId: string, open: (sessionId: string) => Promise<void>): {
    roles: RoleFacade;
    tasks: TaskFacade;
};
