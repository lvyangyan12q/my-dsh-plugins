import type { Context } from '@deepseek-ai/cordis';
import type { Domain } from '@deepseek-ai/dsh-storage-domain';
import { type MaterialImportPlan } from './materials-plan.ts';
import { materialImportDomain, materialPlansDomain } from './materials-state.ts';
import type { Config } from './business.ts';
import type { KaogongHost } from './instance-host.ts';
import type { StudyWorkspace } from './study-workspace.ts';
export declare function materialPreview(plan: MaterialImportPlan, status?: string): {
    notice: string;
    location?: {
        materialRoot: string | undefined;
        originalMaterialRoot: string;
        sourceEvidenceHash: string;
        aliases: number;
        mapFingerprint: string;
    } | undefined;
    id: string;
    fingerprint: string;
    status: string;
    sourceRevision: string;
    sourceFiles: {
        name: string;
        sha256: string;
        bytes: number;
    }[];
    target: {
        instanceId: string;
        viewId: string;
        appId: "kaogong-library";
        projectId: string | null;
        revision?: number;
    };
    counts: Record<string, number>;
};
/** Authenticated material-only owner. Mounting/listing does not open any old source. */
export declare function createMaterialImportOwner(ctx: Context, host: KaogongHost, state: Domain<typeof materialImportDomain>, plansDomain: Domain<typeof materialPlansDomain>, config: Config, assertPriorTargetReady: (instanceId: string) => void, workspace: StudyWorkspace): {
    prepare: (viewId: string) => Promise<{
        notice: string;
        location?: {
            materialRoot: string | undefined;
            originalMaterialRoot: string;
            sourceEvidenceHash: string;
            aliases: number;
            mapFingerprint: string;
        } | undefined;
        id: string;
        fingerprint: string;
        status: string;
        sourceRevision: string;
        sourceFiles: {
            name: string;
            sha256: string;
            bytes: number;
        }[];
        target: {
            instanceId: string;
            viewId: string;
            appId: "kaogong-library";
            projectId: string | null;
            revision?: number;
        };
        counts: Record<string, number>;
    }>;
    list: (viewId: string) => Promise<{
        notice: string;
        location?: {
            materialRoot: string | undefined;
            originalMaterialRoot: string;
            sourceEvidenceHash: string;
            aliases: number;
            mapFingerprint: string;
        } | undefined;
        id: string;
        fingerprint: string;
        status: string;
        sourceRevision: string;
        sourceFiles: {
            name: string;
            sha256: string;
            bytes: number;
        }[];
        target: {
            instanceId: string;
            viewId: string;
            appId: "kaogong-library";
            projectId: string | null;
            revision?: number;
        };
        counts: Record<string, number>;
    }[]>;
    inspect: (viewId: string, id: string) => Promise<{
        notice: string;
        location?: {
            materialRoot: string | undefined;
            originalMaterialRoot: string;
            sourceEvidenceHash: string;
            aliases: number;
            mapFingerprint: string;
        } | undefined;
        id: string;
        fingerprint: string;
        status: string;
        sourceRevision: string;
        sourceFiles: {
            name: string;
            sha256: string;
            bytes: number;
        }[];
        target: {
            instanceId: string;
            viewId: string;
            appId: "kaogong-library";
            projectId: string | null;
            revision?: number;
        };
        counts: Record<string, number>;
    }>;
    exportPlan: (viewId: string, id: string) => Promise<MaterialImportPlan>;
    apply: (viewId: string, input: {
        id: string;
        fingerprint: string;
        confirmed: boolean;
    }) => Promise<{
        notice: string;
        location?: {
            materialRoot: string | undefined;
            originalMaterialRoot: string;
            sourceEvidenceHash: string;
            aliases: number;
            mapFingerprint: string;
        } | undefined;
        id: string;
        fingerprint: string;
        status: string;
        sourceRevision: string;
        sourceFiles: {
            name: string;
            sha256: string;
            bytes: number;
        }[];
        target: {
            instanceId: string;
            viewId: string;
            appId: "kaogong-library";
            projectId: string | null;
            revision?: number;
        };
        counts: Record<string, number>;
    }>;
    close(): Promise<void>;
};
