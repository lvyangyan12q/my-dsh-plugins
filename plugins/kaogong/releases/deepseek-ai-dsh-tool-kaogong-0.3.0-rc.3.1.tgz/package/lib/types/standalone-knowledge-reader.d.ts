export declare function StandaloneKnowledgeLibrary({ active }: {
    active?: boolean;
}): import("react/jsx-runtime").JSX.Element;
