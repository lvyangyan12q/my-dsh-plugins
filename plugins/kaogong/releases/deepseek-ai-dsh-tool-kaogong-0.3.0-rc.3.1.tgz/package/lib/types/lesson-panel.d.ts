import type { KaogongViewProps, PracticeContext } from './kaogong-view.tsx';
/** Only Host responses supply lesson state; browser draft fields never supply scores. */
export declare function lessonRequest<T>(action: string, body: unknown, send?: (input: string, init?: RequestInit) => Promise<Response>): Promise<T>;
/** Shared instance-owned lesson UI; practice starts through the existing request/draft owner. */
export declare function LessonPanel({ active, onPractice, onOpenTeacher }: {
    active: boolean;
    onPractice: (context: PracticeContext) => Promise<void>;
    onOpenTeacher: KaogongViewProps['onOpenTeacher'];
}): import("react/jsx-runtime").JSX.Element;
