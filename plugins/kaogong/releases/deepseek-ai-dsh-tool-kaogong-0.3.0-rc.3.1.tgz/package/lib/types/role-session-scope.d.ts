import type { Context } from '@deepseek-ai/cordis';
import type { StudyRoleScopeOwner as RoleSessionScopeOwner } from './study-contracts.ts';
import type { kaogongRolePresets } from './role-definitions.ts';
/** Trusted packaged role code only. The platform supplies a verified Native Agent context. */
export declare function kaogongRoleScopeOwner(ctx: Context, templates: Awaited<ReturnType<typeof kaogongRolePresets>>): RoleSessionScopeOwner;
