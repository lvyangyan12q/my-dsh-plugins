import type { TaskFacade } from './study-client-contracts.ts';
export declare function TeachingTasks({ tasks, sessionId }: {
    tasks: TaskFacade;
    sessionId: string;
}): import("react/jsx-runtime").JSX.Element;
