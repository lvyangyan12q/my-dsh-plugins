export declare function ErrorReviewPanel({ onPlan }?: {
    onPlan?: () => void;
}): import("react/jsx-runtime").JSX.Element;
export declare function ReviewQueue({ onOpen }: {
    onOpen(): void;
}): import("react/jsx-runtime").JSX.Element;
