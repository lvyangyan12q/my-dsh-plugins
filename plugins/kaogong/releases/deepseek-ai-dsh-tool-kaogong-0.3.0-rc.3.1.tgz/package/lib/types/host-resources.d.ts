import type { StudyWorkspace as ApplicationDirectory } from './study-workspace.ts';
import type { StudySources as ResourceDirectory } from './study-sources.ts';
import type { KvTable } from '@deepseek-ai/dsh-storage-domain';
import type { KaogongHost } from './instance-host.ts';
export type Rows<T> = {
    revision: string;
    rows: [string, T][];
    ownerInstanceId?: string;
};
export declare function instanceView(applications: ApplicationDirectory, instanceId: string): Promise<string>;
/** Readonly external rows are overlaid without importing or rewriting their owner. */
export declare function overlay<T>(own: KvTable<string, T>, external: [string, T][]): KvTable<string, T>;
export declare function readonlyRows<T>(values: [string, T][]): KvTable<string, T>;
export declare function sourceRows<T>(resources: ResourceDirectory, viewId: string, resourceId: string): Promise<[string, T][]>;
/** Private teaching contexts cannot be catalogued or granted to another instance. */
export declare function registerResources(host: KaogongHost, applications: ApplicationDirectory, resources: ResourceDirectory, privateKnowledge?: (instanceId: string, id: string) => boolean): () => Promise<void>;
