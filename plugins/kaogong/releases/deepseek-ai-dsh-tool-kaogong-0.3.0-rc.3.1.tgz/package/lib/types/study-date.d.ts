/** Study schedules use the user's local calendar date, never the UTC date prefix. */
export declare function studyDate(value?: Date): string;
