import type { Context } from '@deepseek-ai/cordis';
import type { StudyWorkspace } from './study-workspace.ts';
import type { StudySources } from './study-sources.ts';
import type { StudyRoles } from './study-roles.ts';
import type { StudyTeaching } from './study-teaching.ts';
import type { CurrentStudyHandoff } from './current-study-handoff.ts';
/** A small authenticated study command boundary, separate from business routes
 * which always require a Host-registered viewId. */
export declare function mountStudyHttp(ctx: Context, workspace: StudyWorkspace, sources: StudySources, roles: StudyRoles, teaching: StudyTeaching, handoff?: CurrentStudyHandoff): () => void;
