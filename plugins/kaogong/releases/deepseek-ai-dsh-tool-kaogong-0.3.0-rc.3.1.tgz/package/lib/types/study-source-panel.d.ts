export declare function SourceConnections({ viewId }: {
    viewId: string;
}): import("react/jsx-runtime").JSX.Element;
