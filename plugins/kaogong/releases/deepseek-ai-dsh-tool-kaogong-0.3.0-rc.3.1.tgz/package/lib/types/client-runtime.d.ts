import type { RoleFacade } from './study-client-contracts.ts';
export type LearningRoleKey = {
    appId: 'kaogong';
    instanceId: string;
    roleId: string;
    subject?: string;
};
export type ViewIdentity = {
    instanceId: string;
    viewId: string;
};
/** Each render receives a fixed view transport; shared business state never changes its identity. */
export declare function createViewTransport(context: ViewIdentity, send?: typeof fetch): Readonly<{
    url: (input: string) => string;
    fetch: (input: string, init?: RequestInit) => Promise<Response>;
    json: <T>(input: string, body: unknown) => Promise<T>;
    instanceId: string;
    viewId: string;
}>;
export type ViewTransport = ReturnType<typeof createViewTransport>;
/** Stable subject ids correspond to the existing native preset identities, never translated display positions. */
export declare function roleIdForKey(key: Pick<LearningRoleKey, 'roleId' | 'subject'>): string;
export declare function createRoleNavigator(instanceId: string, roles: Pick<RoleFacade, 'ensure' | 'open'>, isCurrent?: () => boolean): (key: LearningRoleKey) => Promise<{
    sessionId?: unknown;
    revision?: unknown;
    phase?: unknown;
}>;
