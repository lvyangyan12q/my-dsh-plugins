export declare function CurrentStudyPanel({ onApplied }: {
    onApplied(): Promise<void>;
}): import("react/jsx-runtime").JSX.Element;
