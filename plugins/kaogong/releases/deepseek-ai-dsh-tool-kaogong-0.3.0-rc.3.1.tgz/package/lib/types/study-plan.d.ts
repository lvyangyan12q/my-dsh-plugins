import type { DomainGlobal } from '@deepseek-ai/dsh-storage-domain';
import { z } from 'zod';
export declare const studyGoal: z.ZodObject<{
    examDate: z.ZodNullable<z.ZodString>;
    dailyModules: z.ZodNumber;
    subjects: z.ZodArray<z.ZodObject<{
        name: z.ZodString;
        weight: z.ZodNumber;
    }, z.core.$strip>>;
}, z.core.$strict>;
export declare const reviewOccurrence: z.ZodObject<{
    roundId: z.ZodString;
    questionId: z.ZodString;
}, z.core.$strict>;
declare const task: z.ZodObject<{
    id: z.ZodString;
    revision: z.ZodNumber;
    subject: z.ZodString;
    title: z.ZodString;
    kind: z.ZodEnum<{
        learn: "learn";
        review: "review";
        practice: "practice";
    }>;
    phase: z.ZodEnum<{
        foundation: "foundation";
        reinforce: "reinforce";
        sprint: "sprint";
    }>;
    date: z.ZodNullable<z.ZodString>;
    status: z.ZodEnum<{
        pending: "pending";
        "in-progress": "in-progress";
        completed: "completed";
    }>;
    requirePractice: z.ZodBoolean;
    requireReflections: z.ZodBoolean;
    summary: z.ZodString;
    evidence: z.ZodNullable<z.ZodUnknown>;
    startedFromRevision: z.ZodOptional<z.ZodNumber>;
    lessonId: z.ZodOptional<z.ZodString>;
    reviewOccurrence: z.ZodOptional<z.ZodObject<{
        roundId: z.ZodString;
        questionId: z.ZodString;
    }, z.core.$strict>>;
    reviewHistoryCount: z.ZodOptional<z.ZodNumber>;
}, z.core.$strip>;
export declare const planState: z.ZodObject<{
    revision: z.ZodNumber;
    goal: z.ZodNullable<z.ZodObject<{
        examDate: z.ZodNullable<z.ZodString>;
        dailyModules: z.ZodNumber;
        subjects: z.ZodArray<z.ZodObject<{
            name: z.ZodString;
            weight: z.ZodNumber;
        }, z.core.$strip>>;
    }, z.core.$strict>>;
    tasks: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        revision: z.ZodNumber;
        subject: z.ZodString;
        title: z.ZodString;
        kind: z.ZodEnum<{
            learn: "learn";
            review: "review";
            practice: "practice";
        }>;
        phase: z.ZodEnum<{
            foundation: "foundation";
            reinforce: "reinforce";
            sprint: "sprint";
        }>;
        date: z.ZodNullable<z.ZodString>;
        status: z.ZodEnum<{
            pending: "pending";
            "in-progress": "in-progress";
            completed: "completed";
        }>;
        requirePractice: z.ZodBoolean;
        requireReflections: z.ZodBoolean;
        summary: z.ZodString;
        evidence: z.ZodNullable<z.ZodUnknown>;
        startedFromRevision: z.ZodOptional<z.ZodNumber>;
        lessonId: z.ZodOptional<z.ZodString>;
        reviewOccurrence: z.ZodOptional<z.ZodObject<{
            roundId: z.ZodString;
            questionId: z.ZodString;
        }, z.core.$strict>>;
        reviewHistoryCount: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strip>>;
    drafts: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        baseRevision: z.ZodNumber;
        action: z.ZodString;
        goal: z.ZodNullable<z.ZodObject<{
            examDate: z.ZodNullable<z.ZodString>;
            dailyModules: z.ZodNumber;
            subjects: z.ZodArray<z.ZodObject<{
                name: z.ZodString;
                weight: z.ZodNumber;
            }, z.core.$strip>>;
        }, z.core.$strict>>;
        tasks: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            revision: z.ZodNumber;
            subject: z.ZodString;
            title: z.ZodString;
            kind: z.ZodEnum<{
                learn: "learn";
                review: "review";
                practice: "practice";
            }>;
            phase: z.ZodEnum<{
                foundation: "foundation";
                reinforce: "reinforce";
                sprint: "sprint";
            }>;
            date: z.ZodNullable<z.ZodString>;
            status: z.ZodEnum<{
                pending: "pending";
                "in-progress": "in-progress";
                completed: "completed";
            }>;
            requirePractice: z.ZodBoolean;
            requireReflections: z.ZodBoolean;
            summary: z.ZodString;
            evidence: z.ZodNullable<z.ZodUnknown>;
            startedFromRevision: z.ZodOptional<z.ZodNumber>;
            lessonId: z.ZodOptional<z.ZodString>;
            reviewOccurrence: z.ZodOptional<z.ZodObject<{
                roundId: z.ZodString;
                questionId: z.ZodString;
            }, z.core.$strict>>;
            reviewHistoryCount: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strip>>;
        overflow: z.ZodArray<z.ZodString>;
        diff: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            before: z.ZodNullable<z.ZodObject<{
                id: z.ZodString;
                revision: z.ZodNumber;
                subject: z.ZodString;
                title: z.ZodString;
                kind: z.ZodEnum<{
                    learn: "learn";
                    review: "review";
                    practice: "practice";
                }>;
                phase: z.ZodEnum<{
                    foundation: "foundation";
                    reinforce: "reinforce";
                    sprint: "sprint";
                }>;
                date: z.ZodNullable<z.ZodString>;
                status: z.ZodEnum<{
                    pending: "pending";
                    "in-progress": "in-progress";
                    completed: "completed";
                }>;
                requirePractice: z.ZodBoolean;
                requireReflections: z.ZodBoolean;
                summary: z.ZodString;
                evidence: z.ZodNullable<z.ZodUnknown>;
                startedFromRevision: z.ZodOptional<z.ZodNumber>;
                lessonId: z.ZodOptional<z.ZodString>;
                reviewOccurrence: z.ZodOptional<z.ZodObject<{
                    roundId: z.ZodString;
                    questionId: z.ZodString;
                }, z.core.$strict>>;
                reviewHistoryCount: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strip>>;
            after: z.ZodNullable<z.ZodObject<{
                id: z.ZodString;
                revision: z.ZodNumber;
                subject: z.ZodString;
                title: z.ZodString;
                kind: z.ZodEnum<{
                    learn: "learn";
                    review: "review";
                    practice: "practice";
                }>;
                phase: z.ZodEnum<{
                    foundation: "foundation";
                    reinforce: "reinforce";
                    sprint: "sprint";
                }>;
                date: z.ZodNullable<z.ZodString>;
                status: z.ZodEnum<{
                    pending: "pending";
                    "in-progress": "in-progress";
                    completed: "completed";
                }>;
                requirePractice: z.ZodBoolean;
                requireReflections: z.ZodBoolean;
                summary: z.ZodString;
                evidence: z.ZodNullable<z.ZodUnknown>;
                startedFromRevision: z.ZodOptional<z.ZodNumber>;
                lessonId: z.ZodOptional<z.ZodString>;
                reviewOccurrence: z.ZodOptional<z.ZodObject<{
                    roundId: z.ZodString;
                    questionId: z.ZodString;
                }, z.core.$strict>>;
                reviewHistoryCount: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strip>>;
        }, z.core.$strip>>;
        createdAt: z.ZodString;
    }, z.core.$strip>>;
    completionProposals: z.ZodDefault<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        taskId: z.ZodString;
        baseRevision: z.ZodNumber;
        taskRevision: z.ZodNumber;
        roundId: z.ZodOptional<z.ZodString>;
        createdAt: z.ZodString;
    }, z.core.$strip>>>;
    history: z.ZodArray<z.ZodObject<{
        revision: z.ZodNumber;
        confirmedAt: z.ZodString;
        draftId: z.ZodString;
        action: z.ZodString;
        diff: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            before: z.ZodNullable<z.ZodObject<{
                id: z.ZodString;
                revision: z.ZodNumber;
                subject: z.ZodString;
                title: z.ZodString;
                kind: z.ZodEnum<{
                    learn: "learn";
                    review: "review";
                    practice: "practice";
                }>;
                phase: z.ZodEnum<{
                    foundation: "foundation";
                    reinforce: "reinforce";
                    sprint: "sprint";
                }>;
                date: z.ZodNullable<z.ZodString>;
                status: z.ZodEnum<{
                    pending: "pending";
                    "in-progress": "in-progress";
                    completed: "completed";
                }>;
                requirePractice: z.ZodBoolean;
                requireReflections: z.ZodBoolean;
                summary: z.ZodString;
                evidence: z.ZodNullable<z.ZodUnknown>;
                startedFromRevision: z.ZodOptional<z.ZodNumber>;
                lessonId: z.ZodOptional<z.ZodString>;
                reviewOccurrence: z.ZodOptional<z.ZodObject<{
                    roundId: z.ZodString;
                    questionId: z.ZodString;
                }, z.core.$strict>>;
                reviewHistoryCount: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strip>>;
            after: z.ZodNullable<z.ZodObject<{
                id: z.ZodString;
                revision: z.ZodNumber;
                subject: z.ZodString;
                title: z.ZodString;
                kind: z.ZodEnum<{
                    learn: "learn";
                    review: "review";
                    practice: "practice";
                }>;
                phase: z.ZodEnum<{
                    foundation: "foundation";
                    reinforce: "reinforce";
                    sprint: "sprint";
                }>;
                date: z.ZodNullable<z.ZodString>;
                status: z.ZodEnum<{
                    pending: "pending";
                    "in-progress": "in-progress";
                    completed: "completed";
                }>;
                requirePractice: z.ZodBoolean;
                requireReflections: z.ZodBoolean;
                summary: z.ZodString;
                evidence: z.ZodNullable<z.ZodUnknown>;
                startedFromRevision: z.ZodOptional<z.ZodNumber>;
                lessonId: z.ZodOptional<z.ZodString>;
                reviewOccurrence: z.ZodOptional<z.ZodObject<{
                    roundId: z.ZodString;
                    questionId: z.ZodString;
                }, z.core.$strict>>;
                reviewHistoryCount: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strip>>;
        }, z.core.$strip>>;
    }, z.core.$strip>>;
    externalMocks: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        date: z.ZodString;
        title: z.ZodString;
        score: z.ZodNumber;
        maximum: z.ZodNumber;
        source: z.ZodLiteral<"learner-self-report">;
    }, z.core.$strip>>;
}, z.core.$strip>;
export type StudyTask = z.infer<typeof task>;
export type StudyPlanState = z.infer<typeof planState>;
export declare const studyPlanDomain: {
    name: string;
    version: number;
    tables: {};
    global: {
        schema: z.ZodObject<{
            revision: z.ZodNumber;
            goal: z.ZodNullable<z.ZodObject<{
                examDate: z.ZodNullable<z.ZodString>;
                dailyModules: z.ZodNumber;
                subjects: z.ZodArray<z.ZodObject<{
                    name: z.ZodString;
                    weight: z.ZodNumber;
                }, z.core.$strip>>;
            }, z.core.$strict>>;
            tasks: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                revision: z.ZodNumber;
                subject: z.ZodString;
                title: z.ZodString;
                kind: z.ZodEnum<{
                    learn: "learn";
                    review: "review";
                    practice: "practice";
                }>;
                phase: z.ZodEnum<{
                    foundation: "foundation";
                    reinforce: "reinforce";
                    sprint: "sprint";
                }>;
                date: z.ZodNullable<z.ZodString>;
                status: z.ZodEnum<{
                    pending: "pending";
                    "in-progress": "in-progress";
                    completed: "completed";
                }>;
                requirePractice: z.ZodBoolean;
                requireReflections: z.ZodBoolean;
                summary: z.ZodString;
                evidence: z.ZodNullable<z.ZodUnknown>;
                startedFromRevision: z.ZodOptional<z.ZodNumber>;
                lessonId: z.ZodOptional<z.ZodString>;
                reviewOccurrence: z.ZodOptional<z.ZodObject<{
                    roundId: z.ZodString;
                    questionId: z.ZodString;
                }, z.core.$strict>>;
                reviewHistoryCount: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strip>>;
            drafts: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                baseRevision: z.ZodNumber;
                action: z.ZodString;
                goal: z.ZodNullable<z.ZodObject<{
                    examDate: z.ZodNullable<z.ZodString>;
                    dailyModules: z.ZodNumber;
                    subjects: z.ZodArray<z.ZodObject<{
                        name: z.ZodString;
                        weight: z.ZodNumber;
                    }, z.core.$strip>>;
                }, z.core.$strict>>;
                tasks: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    revision: z.ZodNumber;
                    subject: z.ZodString;
                    title: z.ZodString;
                    kind: z.ZodEnum<{
                        learn: "learn";
                        review: "review";
                        practice: "practice";
                    }>;
                    phase: z.ZodEnum<{
                        foundation: "foundation";
                        reinforce: "reinforce";
                        sprint: "sprint";
                    }>;
                    date: z.ZodNullable<z.ZodString>;
                    status: z.ZodEnum<{
                        pending: "pending";
                        "in-progress": "in-progress";
                        completed: "completed";
                    }>;
                    requirePractice: z.ZodBoolean;
                    requireReflections: z.ZodBoolean;
                    summary: z.ZodString;
                    evidence: z.ZodNullable<z.ZodUnknown>;
                    startedFromRevision: z.ZodOptional<z.ZodNumber>;
                    lessonId: z.ZodOptional<z.ZodString>;
                    reviewOccurrence: z.ZodOptional<z.ZodObject<{
                        roundId: z.ZodString;
                        questionId: z.ZodString;
                    }, z.core.$strict>>;
                    reviewHistoryCount: z.ZodOptional<z.ZodNumber>;
                }, z.core.$strip>>;
                overflow: z.ZodArray<z.ZodString>;
                diff: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    before: z.ZodNullable<z.ZodObject<{
                        id: z.ZodString;
                        revision: z.ZodNumber;
                        subject: z.ZodString;
                        title: z.ZodString;
                        kind: z.ZodEnum<{
                            learn: "learn";
                            review: "review";
                            practice: "practice";
                        }>;
                        phase: z.ZodEnum<{
                            foundation: "foundation";
                            reinforce: "reinforce";
                            sprint: "sprint";
                        }>;
                        date: z.ZodNullable<z.ZodString>;
                        status: z.ZodEnum<{
                            pending: "pending";
                            "in-progress": "in-progress";
                            completed: "completed";
                        }>;
                        requirePractice: z.ZodBoolean;
                        requireReflections: z.ZodBoolean;
                        summary: z.ZodString;
                        evidence: z.ZodNullable<z.ZodUnknown>;
                        startedFromRevision: z.ZodOptional<z.ZodNumber>;
                        lessonId: z.ZodOptional<z.ZodString>;
                        reviewOccurrence: z.ZodOptional<z.ZodObject<{
                            roundId: z.ZodString;
                            questionId: z.ZodString;
                        }, z.core.$strict>>;
                        reviewHistoryCount: z.ZodOptional<z.ZodNumber>;
                    }, z.core.$strip>>;
                    after: z.ZodNullable<z.ZodObject<{
                        id: z.ZodString;
                        revision: z.ZodNumber;
                        subject: z.ZodString;
                        title: z.ZodString;
                        kind: z.ZodEnum<{
                            learn: "learn";
                            review: "review";
                            practice: "practice";
                        }>;
                        phase: z.ZodEnum<{
                            foundation: "foundation";
                            reinforce: "reinforce";
                            sprint: "sprint";
                        }>;
                        date: z.ZodNullable<z.ZodString>;
                        status: z.ZodEnum<{
                            pending: "pending";
                            "in-progress": "in-progress";
                            completed: "completed";
                        }>;
                        requirePractice: z.ZodBoolean;
                        requireReflections: z.ZodBoolean;
                        summary: z.ZodString;
                        evidence: z.ZodNullable<z.ZodUnknown>;
                        startedFromRevision: z.ZodOptional<z.ZodNumber>;
                        lessonId: z.ZodOptional<z.ZodString>;
                        reviewOccurrence: z.ZodOptional<z.ZodObject<{
                            roundId: z.ZodString;
                            questionId: z.ZodString;
                        }, z.core.$strict>>;
                        reviewHistoryCount: z.ZodOptional<z.ZodNumber>;
                    }, z.core.$strip>>;
                }, z.core.$strip>>;
                createdAt: z.ZodString;
            }, z.core.$strip>>;
            completionProposals: z.ZodDefault<z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                taskId: z.ZodString;
                baseRevision: z.ZodNumber;
                taskRevision: z.ZodNumber;
                roundId: z.ZodOptional<z.ZodString>;
                createdAt: z.ZodString;
            }, z.core.$strip>>>;
            history: z.ZodArray<z.ZodObject<{
                revision: z.ZodNumber;
                confirmedAt: z.ZodString;
                draftId: z.ZodString;
                action: z.ZodString;
                diff: z.ZodArray<z.ZodObject<{
                    id: z.ZodString;
                    before: z.ZodNullable<z.ZodObject<{
                        id: z.ZodString;
                        revision: z.ZodNumber;
                        subject: z.ZodString;
                        title: z.ZodString;
                        kind: z.ZodEnum<{
                            learn: "learn";
                            review: "review";
                            practice: "practice";
                        }>;
                        phase: z.ZodEnum<{
                            foundation: "foundation";
                            reinforce: "reinforce";
                            sprint: "sprint";
                        }>;
                        date: z.ZodNullable<z.ZodString>;
                        status: z.ZodEnum<{
                            pending: "pending";
                            "in-progress": "in-progress";
                            completed: "completed";
                        }>;
                        requirePractice: z.ZodBoolean;
                        requireReflections: z.ZodBoolean;
                        summary: z.ZodString;
                        evidence: z.ZodNullable<z.ZodUnknown>;
                        startedFromRevision: z.ZodOptional<z.ZodNumber>;
                        lessonId: z.ZodOptional<z.ZodString>;
                        reviewOccurrence: z.ZodOptional<z.ZodObject<{
                            roundId: z.ZodString;
                            questionId: z.ZodString;
                        }, z.core.$strict>>;
                        reviewHistoryCount: z.ZodOptional<z.ZodNumber>;
                    }, z.core.$strip>>;
                    after: z.ZodNullable<z.ZodObject<{
                        id: z.ZodString;
                        revision: z.ZodNumber;
                        subject: z.ZodString;
                        title: z.ZodString;
                        kind: z.ZodEnum<{
                            learn: "learn";
                            review: "review";
                            practice: "practice";
                        }>;
                        phase: z.ZodEnum<{
                            foundation: "foundation";
                            reinforce: "reinforce";
                            sprint: "sprint";
                        }>;
                        date: z.ZodNullable<z.ZodString>;
                        status: z.ZodEnum<{
                            pending: "pending";
                            "in-progress": "in-progress";
                            completed: "completed";
                        }>;
                        requirePractice: z.ZodBoolean;
                        requireReflections: z.ZodBoolean;
                        summary: z.ZodString;
                        evidence: z.ZodNullable<z.ZodUnknown>;
                        startedFromRevision: z.ZodOptional<z.ZodNumber>;
                        lessonId: z.ZodOptional<z.ZodString>;
                        reviewOccurrence: z.ZodOptional<z.ZodObject<{
                            roundId: z.ZodString;
                            questionId: z.ZodString;
                        }, z.core.$strict>>;
                        reviewHistoryCount: z.ZodOptional<z.ZodNumber>;
                    }, z.core.$strip>>;
                }, z.core.$strip>>;
            }, z.core.$strip>>;
            externalMocks: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                date: z.ZodString;
                title: z.ZodString;
                score: z.ZodNumber;
                maximum: z.ZodNumber;
                source: z.ZodLiteral<"learner-self-report">;
            }, z.core.$strip>>;
        }, z.core.$strip>;
        initial: {
            revision: number;
            goal: null;
            tasks: never[];
            drafts: never[];
            completionProposals: never[];
            history: never[];
            externalMocks: never[];
        };
    };
};
export type PlanPreview = {
    baseRevision: number;
    action: 'generate' | 'adjust' | 'defer' | 'append';
    today: string;
    goal?: z.infer<typeof studyGoal>;
    taskId?: string;
    date?: string;
    task?: {
        subject: string;
        title: string;
        kind: StudyTask['kind'];
        requirePractice?: boolean;
        requireReflections?: boolean;
        reviewOccurrence?: z.infer<typeof reviewOccurrence>;
    };
};
/** One atomic aggregate owns plan revisions, stable tasks and explicit proposals.
 * Existing progress/round/lesson domains are neither inferred nor rewritten. */
export declare class StudyPlan {
    private global;
    private verify;
    private prepareReview;
    private pending;
    constructor(global: DomainGlobal<StudyPlanState>, verify?: (task: StudyTask, input: {
        roundId?: string;
        lessonId?: string;
    }) => Promise<unknown>, prepareReview?: (task: StudyTask) => Promise<number>);
    private run;
    read(): {
        completionProposals: {
            id: string;
            taskId: string;
            baseRevision: number;
            taskRevision: number;
            createdAt: string;
            roundId?: string | undefined;
        }[];
        revision: number;
        goal: {
            examDate: string | null;
            dailyModules: number;
            subjects: {
                name: string;
                weight: number;
            }[];
        } | null;
        tasks: {
            id: string;
            revision: number;
            subject: string;
            title: string;
            kind: "learn" | "review" | "practice";
            phase: "foundation" | "reinforce" | "sprint";
            date: string | null;
            status: "pending" | "in-progress" | "completed";
            requirePractice: boolean;
            requireReflections: boolean;
            summary: string;
            evidence: unknown;
            startedFromRevision?: number | undefined;
            lessonId?: string | undefined;
            reviewOccurrence?: {
                roundId: string;
                questionId: string;
            } | undefined;
            reviewHistoryCount?: number | undefined;
        }[];
        drafts: {
            id: string;
            baseRevision: number;
            action: string;
            goal: {
                examDate: string | null;
                dailyModules: number;
                subjects: {
                    name: string;
                    weight: number;
                }[];
            } | null;
            tasks: {
                id: string;
                revision: number;
                subject: string;
                title: string;
                kind: "learn" | "review" | "practice";
                phase: "foundation" | "reinforce" | "sprint";
                date: string | null;
                status: "pending" | "in-progress" | "completed";
                requirePractice: boolean;
                requireReflections: boolean;
                summary: string;
                evidence: unknown;
                startedFromRevision?: number | undefined;
                lessonId?: string | undefined;
                reviewOccurrence?: {
                    roundId: string;
                    questionId: string;
                } | undefined;
                reviewHistoryCount?: number | undefined;
            }[];
            overflow: string[];
            diff: {
                id: string;
                before: {
                    id: string;
                    revision: number;
                    subject: string;
                    title: string;
                    kind: "learn" | "review" | "practice";
                    phase: "foundation" | "reinforce" | "sprint";
                    date: string | null;
                    status: "pending" | "in-progress" | "completed";
                    requirePractice: boolean;
                    requireReflections: boolean;
                    summary: string;
                    evidence: unknown;
                    startedFromRevision?: number | undefined;
                    lessonId?: string | undefined;
                    reviewOccurrence?: {
                        roundId: string;
                        questionId: string;
                    } | undefined;
                    reviewHistoryCount?: number | undefined;
                } | null;
                after: {
                    id: string;
                    revision: number;
                    subject: string;
                    title: string;
                    kind: "learn" | "review" | "practice";
                    phase: "foundation" | "reinforce" | "sprint";
                    date: string | null;
                    status: "pending" | "in-progress" | "completed";
                    requirePractice: boolean;
                    requireReflections: boolean;
                    summary: string;
                    evidence: unknown;
                    startedFromRevision?: number | undefined;
                    lessonId?: string | undefined;
                    reviewOccurrence?: {
                        roundId: string;
                        questionId: string;
                    } | undefined;
                    reviewHistoryCount?: number | undefined;
                } | null;
            }[];
            createdAt: string;
        }[];
        history: {
            revision: number;
            confirmedAt: string;
            draftId: string;
            action: string;
            diff: {
                id: string;
                before: {
                    id: string;
                    revision: number;
                    subject: string;
                    title: string;
                    kind: "learn" | "review" | "practice";
                    phase: "foundation" | "reinforce" | "sprint";
                    date: string | null;
                    status: "pending" | "in-progress" | "completed";
                    requirePractice: boolean;
                    requireReflections: boolean;
                    summary: string;
                    evidence: unknown;
                    startedFromRevision?: number | undefined;
                    lessonId?: string | undefined;
                    reviewOccurrence?: {
                        roundId: string;
                        questionId: string;
                    } | undefined;
                    reviewHistoryCount?: number | undefined;
                } | null;
                after: {
                    id: string;
                    revision: number;
                    subject: string;
                    title: string;
                    kind: "learn" | "review" | "practice";
                    phase: "foundation" | "reinforce" | "sprint";
                    date: string | null;
                    status: "pending" | "in-progress" | "completed";
                    requirePractice: boolean;
                    requireReflections: boolean;
                    summary: string;
                    evidence: unknown;
                    startedFromRevision?: number | undefined;
                    lessonId?: string | undefined;
                    reviewOccurrence?: {
                        roundId: string;
                        questionId: string;
                    } | undefined;
                    reviewHistoryCount?: number | undefined;
                } | null;
            }[];
        }[];
        externalMocks: {
            id: string;
            date: string;
            title: string;
            score: number;
            maximum: number;
            source: "learner-self-report";
        }[];
    };
    preview(input: PlanPreview): Promise<{
        id: `${string}-${string}-${string}-${string}-${string}`;
        baseRevision: number;
        action: "generate" | "adjust" | "defer" | "append";
        goal: {
            examDate: string | null;
            dailyModules: number;
            subjects: {
                name: string;
                weight: number;
            }[];
        } | null;
        tasks: {
            id: string;
            revision: number;
            subject: string;
            title: string;
            kind: "learn" | "review" | "practice";
            phase: "foundation" | "reinforce" | "sprint";
            date: string | null;
            status: "pending" | "in-progress" | "completed";
            requirePractice: boolean;
            requireReflections: boolean;
            summary: string;
            evidence: unknown;
            startedFromRevision?: number | undefined;
            lessonId?: string | undefined;
            reviewOccurrence?: {
                roundId: string;
                questionId: string;
            } | undefined;
            reviewHistoryCount?: number | undefined;
        }[];
        overflow: string[];
        diff: {
            id: string;
            before: {
                id: string;
                revision: number;
                subject: string;
                title: string;
                kind: "learn" | "review" | "practice";
                phase: "foundation" | "reinforce" | "sprint";
                date: string | null;
                status: "pending" | "in-progress" | "completed";
                requirePractice: boolean;
                requireReflections: boolean;
                summary: string;
                evidence: unknown;
                startedFromRevision?: number | undefined;
                lessonId?: string | undefined;
                reviewOccurrence?: {
                    roundId: string;
                    questionId: string;
                } | undefined;
                reviewHistoryCount?: number | undefined;
            } | null;
            after: {
                id: string;
                revision: number;
                subject: string;
                title: string;
                kind: "learn" | "review" | "practice";
                phase: "foundation" | "reinforce" | "sprint";
                date: string | null;
                status: "pending" | "in-progress" | "completed";
                requirePractice: boolean;
                requireReflections: boolean;
                summary: string;
                evidence: unknown;
                startedFromRevision?: number | undefined;
                lessonId?: string | undefined;
                reviewOccurrence?: {
                    roundId: string;
                    questionId: string;
                } | undefined;
                reviewHistoryCount?: number | undefined;
            };
        }[];
        createdAt: string;
    }>;
    confirm(id: string, revision: number, confirmed: boolean): Promise<{
        revision: number;
        goal: {
            examDate: string | null;
            dailyModules: number;
            subjects: {
                name: string;
                weight: number;
            }[];
        } | null;
        tasks: {
            id: string;
            revision: number;
            subject: string;
            title: string;
            kind: "learn" | "review" | "practice";
            phase: "foundation" | "reinforce" | "sprint";
            date: string | null;
            status: "pending" | "in-progress" | "completed";
            requirePractice: boolean;
            requireReflections: boolean;
            summary: string;
            evidence: unknown;
            startedFromRevision?: number | undefined;
            lessonId?: string | undefined;
            reviewOccurrence?: {
                roundId: string;
                questionId: string;
            } | undefined;
            reviewHistoryCount?: number | undefined;
        }[];
        drafts: {
            id: string;
            baseRevision: number;
            action: string;
            goal: {
                examDate: string | null;
                dailyModules: number;
                subjects: {
                    name: string;
                    weight: number;
                }[];
            } | null;
            tasks: {
                id: string;
                revision: number;
                subject: string;
                title: string;
                kind: "learn" | "review" | "practice";
                phase: "foundation" | "reinforce" | "sprint";
                date: string | null;
                status: "pending" | "in-progress" | "completed";
                requirePractice: boolean;
                requireReflections: boolean;
                summary: string;
                evidence: unknown;
                startedFromRevision?: number | undefined;
                lessonId?: string | undefined;
                reviewOccurrence?: {
                    roundId: string;
                    questionId: string;
                } | undefined;
                reviewHistoryCount?: number | undefined;
            }[];
            overflow: string[];
            diff: {
                id: string;
                before: {
                    id: string;
                    revision: number;
                    subject: string;
                    title: string;
                    kind: "learn" | "review" | "practice";
                    phase: "foundation" | "reinforce" | "sprint";
                    date: string | null;
                    status: "pending" | "in-progress" | "completed";
                    requirePractice: boolean;
                    requireReflections: boolean;
                    summary: string;
                    evidence: unknown;
                    startedFromRevision?: number | undefined;
                    lessonId?: string | undefined;
                    reviewOccurrence?: {
                        roundId: string;
                        questionId: string;
                    } | undefined;
                    reviewHistoryCount?: number | undefined;
                } | null;
                after: {
                    id: string;
                    revision: number;
                    subject: string;
                    title: string;
                    kind: "learn" | "review" | "practice";
                    phase: "foundation" | "reinforce" | "sprint";
                    date: string | null;
                    status: "pending" | "in-progress" | "completed";
                    requirePractice: boolean;
                    requireReflections: boolean;
                    summary: string;
                    evidence: unknown;
                    startedFromRevision?: number | undefined;
                    lessonId?: string | undefined;
                    reviewOccurrence?: {
                        roundId: string;
                        questionId: string;
                    } | undefined;
                    reviewHistoryCount?: number | undefined;
                } | null;
            }[];
            createdAt: string;
        }[];
        history: {
            revision: number;
            confirmedAt: string;
            draftId: string;
            action: string;
            diff: {
                id: string;
                before: {
                    id: string;
                    revision: number;
                    subject: string;
                    title: string;
                    kind: "learn" | "review" | "practice";
                    phase: "foundation" | "reinforce" | "sprint";
                    date: string | null;
                    status: "pending" | "in-progress" | "completed";
                    requirePractice: boolean;
                    requireReflections: boolean;
                    summary: string;
                    evidence: unknown;
                    startedFromRevision?: number | undefined;
                    lessonId?: string | undefined;
                    reviewOccurrence?: {
                        roundId: string;
                        questionId: string;
                    } | undefined;
                    reviewHistoryCount?: number | undefined;
                } | null;
                after: {
                    id: string;
                    revision: number;
                    subject: string;
                    title: string;
                    kind: "learn" | "review" | "practice";
                    phase: "foundation" | "reinforce" | "sprint";
                    date: string | null;
                    status: "pending" | "in-progress" | "completed";
                    requirePractice: boolean;
                    requireReflections: boolean;
                    summary: string;
                    evidence: unknown;
                    startedFromRevision?: number | undefined;
                    lessonId?: string | undefined;
                    reviewOccurrence?: {
                        roundId: string;
                        questionId: string;
                    } | undefined;
                    reviewHistoryCount?: number | undefined;
                } | null;
            }[];
        }[];
        completionProposals: {
            id: string;
            taskId: string;
            baseRevision: number;
            taskRevision: number;
            createdAt: string;
            roundId?: string | undefined;
        }[];
        externalMocks: {
            id: string;
            date: string;
            title: string;
            score: number;
            maximum: number;
            source: "learner-self-report";
        }[];
    }>;
    start(id: string, revision: number): Promise<{
        completionProposals: {
            id: string;
            taskId: string;
            baseRevision: number;
            taskRevision: number;
            createdAt: string;
            roundId?: string | undefined;
        }[];
        revision: number;
        goal: {
            examDate: string | null;
            dailyModules: number;
            subjects: {
                name: string;
                weight: number;
            }[];
        } | null;
        tasks: {
            id: string;
            revision: number;
            subject: string;
            title: string;
            kind: "learn" | "review" | "practice";
            phase: "foundation" | "reinforce" | "sprint";
            date: string | null;
            status: "pending" | "in-progress" | "completed";
            requirePractice: boolean;
            requireReflections: boolean;
            summary: string;
            evidence: unknown;
            startedFromRevision?: number | undefined;
            lessonId?: string | undefined;
            reviewOccurrence?: {
                roundId: string;
                questionId: string;
            } | undefined;
            reviewHistoryCount?: number | undefined;
        }[];
        drafts: {
            id: string;
            baseRevision: number;
            action: string;
            goal: {
                examDate: string | null;
                dailyModules: number;
                subjects: {
                    name: string;
                    weight: number;
                }[];
            } | null;
            tasks: {
                id: string;
                revision: number;
                subject: string;
                title: string;
                kind: "learn" | "review" | "practice";
                phase: "foundation" | "reinforce" | "sprint";
                date: string | null;
                status: "pending" | "in-progress" | "completed";
                requirePractice: boolean;
                requireReflections: boolean;
                summary: string;
                evidence: unknown;
                startedFromRevision?: number | undefined;
                lessonId?: string | undefined;
                reviewOccurrence?: {
                    roundId: string;
                    questionId: string;
                } | undefined;
                reviewHistoryCount?: number | undefined;
            }[];
            overflow: string[];
            diff: {
                id: string;
                before: {
                    id: string;
                    revision: number;
                    subject: string;
                    title: string;
                    kind: "learn" | "review" | "practice";
                    phase: "foundation" | "reinforce" | "sprint";
                    date: string | null;
                    status: "pending" | "in-progress" | "completed";
                    requirePractice: boolean;
                    requireReflections: boolean;
                    summary: string;
                    evidence: unknown;
                    startedFromRevision?: number | undefined;
                    lessonId?: string | undefined;
                    reviewOccurrence?: {
                        roundId: string;
                        questionId: string;
                    } | undefined;
                    reviewHistoryCount?: number | undefined;
                } | null;
                after: {
                    id: string;
                    revision: number;
                    subject: string;
                    title: string;
                    kind: "learn" | "review" | "practice";
                    phase: "foundation" | "reinforce" | "sprint";
                    date: string | null;
                    status: "pending" | "in-progress" | "completed";
                    requirePractice: boolean;
                    requireReflections: boolean;
                    summary: string;
                    evidence: unknown;
                    startedFromRevision?: number | undefined;
                    lessonId?: string | undefined;
                    reviewOccurrence?: {
                        roundId: string;
                        questionId: string;
                    } | undefined;
                    reviewHistoryCount?: number | undefined;
                } | null;
            }[];
            createdAt: string;
        }[];
        history: {
            revision: number;
            confirmedAt: string;
            draftId: string;
            action: string;
            diff: {
                id: string;
                before: {
                    id: string;
                    revision: number;
                    subject: string;
                    title: string;
                    kind: "learn" | "review" | "practice";
                    phase: "foundation" | "reinforce" | "sprint";
                    date: string | null;
                    status: "pending" | "in-progress" | "completed";
                    requirePractice: boolean;
                    requireReflections: boolean;
                    summary: string;
                    evidence: unknown;
                    startedFromRevision?: number | undefined;
                    lessonId?: string | undefined;
                    reviewOccurrence?: {
                        roundId: string;
                        questionId: string;
                    } | undefined;
                    reviewHistoryCount?: number | undefined;
                } | null;
                after: {
                    id: string;
                    revision: number;
                    subject: string;
                    title: string;
                    kind: "learn" | "review" | "practice";
                    phase: "foundation" | "reinforce" | "sprint";
                    date: string | null;
                    status: "pending" | "in-progress" | "completed";
                    requirePractice: boolean;
                    requireReflections: boolean;
                    summary: string;
                    evidence: unknown;
                    startedFromRevision?: number | undefined;
                    lessonId?: string | undefined;
                    reviewOccurrence?: {
                        roundId: string;
                        questionId: string;
                    } | undefined;
                    reviewHistoryCount?: number | undefined;
                } | null;
            }[];
        }[];
        externalMocks: {
            id: string;
            date: string;
            title: string;
            score: number;
            maximum: number;
            source: "learner-self-report";
        }[];
    }>;
    saveSummary(id: string, revision: number, summary: string): Promise<{
        completionProposals: {
            id: string;
            taskId: string;
            baseRevision: number;
            taskRevision: number;
            createdAt: string;
            roundId?: string | undefined;
        }[];
        revision: number;
        goal: {
            examDate: string | null;
            dailyModules: number;
            subjects: {
                name: string;
                weight: number;
            }[];
        } | null;
        tasks: {
            id: string;
            revision: number;
            subject: string;
            title: string;
            kind: "learn" | "review" | "practice";
            phase: "foundation" | "reinforce" | "sprint";
            date: string | null;
            status: "pending" | "in-progress" | "completed";
            requirePractice: boolean;
            requireReflections: boolean;
            summary: string;
            evidence: unknown;
            startedFromRevision?: number | undefined;
            lessonId?: string | undefined;
            reviewOccurrence?: {
                roundId: string;
                questionId: string;
            } | undefined;
            reviewHistoryCount?: number | undefined;
        }[];
        drafts: {
            id: string;
            baseRevision: number;
            action: string;
            goal: {
                examDate: string | null;
                dailyModules: number;
                subjects: {
                    name: string;
                    weight: number;
                }[];
            } | null;
            tasks: {
                id: string;
                revision: number;
                subject: string;
                title: string;
                kind: "learn" | "review" | "practice";
                phase: "foundation" | "reinforce" | "sprint";
                date: string | null;
                status: "pending" | "in-progress" | "completed";
                requirePractice: boolean;
                requireReflections: boolean;
                summary: string;
                evidence: unknown;
                startedFromRevision?: number | undefined;
                lessonId?: string | undefined;
                reviewOccurrence?: {
                    roundId: string;
                    questionId: string;
                } | undefined;
                reviewHistoryCount?: number | undefined;
            }[];
            overflow: string[];
            diff: {
                id: string;
                before: {
                    id: string;
                    revision: number;
                    subject: string;
                    title: string;
                    kind: "learn" | "review" | "practice";
                    phase: "foundation" | "reinforce" | "sprint";
                    date: string | null;
                    status: "pending" | "in-progress" | "completed";
                    requirePractice: boolean;
                    requireReflections: boolean;
                    summary: string;
                    evidence: unknown;
                    startedFromRevision?: number | undefined;
                    lessonId?: string | undefined;
                    reviewOccurrence?: {
                        roundId: string;
                        questionId: string;
                    } | undefined;
                    reviewHistoryCount?: number | undefined;
                } | null;
                after: {
                    id: string;
                    revision: number;
                    subject: string;
                    title: string;
                    kind: "learn" | "review" | "practice";
                    phase: "foundation" | "reinforce" | "sprint";
                    date: string | null;
                    status: "pending" | "in-progress" | "completed";
                    requirePractice: boolean;
                    requireReflections: boolean;
                    summary: string;
                    evidence: unknown;
                    startedFromRevision?: number | undefined;
                    lessonId?: string | undefined;
                    reviewOccurrence?: {
                        roundId: string;
                        questionId: string;
                    } | undefined;
                    reviewHistoryCount?: number | undefined;
                } | null;
            }[];
            createdAt: string;
        }[];
        history: {
            revision: number;
            confirmedAt: string;
            draftId: string;
            action: string;
            diff: {
                id: string;
                before: {
                    id: string;
                    revision: number;
                    subject: string;
                    title: string;
                    kind: "learn" | "review" | "practice";
                    phase: "foundation" | "reinforce" | "sprint";
                    date: string | null;
                    status: "pending" | "in-progress" | "completed";
                    requirePractice: boolean;
                    requireReflections: boolean;
                    summary: string;
                    evidence: unknown;
                    startedFromRevision?: number | undefined;
                    lessonId?: string | undefined;
                    reviewOccurrence?: {
                        roundId: string;
                        questionId: string;
                    } | undefined;
                    reviewHistoryCount?: number | undefined;
                } | null;
                after: {
                    id: string;
                    revision: number;
                    subject: string;
                    title: string;
                    kind: "learn" | "review" | "practice";
                    phase: "foundation" | "reinforce" | "sprint";
                    date: string | null;
                    status: "pending" | "in-progress" | "completed";
                    requirePractice: boolean;
                    requireReflections: boolean;
                    summary: string;
                    evidence: unknown;
                    startedFromRevision?: number | undefined;
                    lessonId?: string | undefined;
                    reviewOccurrence?: {
                        roundId: string;
                        questionId: string;
                    } | undefined;
                    reviewHistoryCount?: number | undefined;
                } | null;
            }[];
        }[];
        externalMocks: {
            id: string;
            date: string;
            title: string;
            score: number;
            maximum: number;
            source: "learner-self-report";
        }[];
    }>;
    complete(id: string, revision: number, confirmed: boolean, input: {
        roundId?: string;
        lessonId?: string;
    }, proposalId?: string): Promise<{
        completionProposals: {
            id: string;
            taskId: string;
            baseRevision: number;
            taskRevision: number;
            createdAt: string;
            roundId?: string | undefined;
        }[];
        revision: number;
        goal: {
            examDate: string | null;
            dailyModules: number;
            subjects: {
                name: string;
                weight: number;
            }[];
        } | null;
        tasks: {
            id: string;
            revision: number;
            subject: string;
            title: string;
            kind: "learn" | "review" | "practice";
            phase: "foundation" | "reinforce" | "sprint";
            date: string | null;
            status: "pending" | "in-progress" | "completed";
            requirePractice: boolean;
            requireReflections: boolean;
            summary: string;
            evidence: unknown;
            startedFromRevision?: number | undefined;
            lessonId?: string | undefined;
            reviewOccurrence?: {
                roundId: string;
                questionId: string;
            } | undefined;
            reviewHistoryCount?: number | undefined;
        }[];
        drafts: {
            id: string;
            baseRevision: number;
            action: string;
            goal: {
                examDate: string | null;
                dailyModules: number;
                subjects: {
                    name: string;
                    weight: number;
                }[];
            } | null;
            tasks: {
                id: string;
                revision: number;
                subject: string;
                title: string;
                kind: "learn" | "review" | "practice";
                phase: "foundation" | "reinforce" | "sprint";
                date: string | null;
                status: "pending" | "in-progress" | "completed";
                requirePractice: boolean;
                requireReflections: boolean;
                summary: string;
                evidence: unknown;
                startedFromRevision?: number | undefined;
                lessonId?: string | undefined;
                reviewOccurrence?: {
                    roundId: string;
                    questionId: string;
                } | undefined;
                reviewHistoryCount?: number | undefined;
            }[];
            overflow: string[];
            diff: {
                id: string;
                before: {
                    id: string;
                    revision: number;
                    subject: string;
                    title: string;
                    kind: "learn" | "review" | "practice";
                    phase: "foundation" | "reinforce" | "sprint";
                    date: string | null;
                    status: "pending" | "in-progress" | "completed";
                    requirePractice: boolean;
                    requireReflections: boolean;
                    summary: string;
                    evidence: unknown;
                    startedFromRevision?: number | undefined;
                    lessonId?: string | undefined;
                    reviewOccurrence?: {
                        roundId: string;
                        questionId: string;
                    } | undefined;
                    reviewHistoryCount?: number | undefined;
                } | null;
                after: {
                    id: string;
                    revision: number;
                    subject: string;
                    title: string;
                    kind: "learn" | "review" | "practice";
                    phase: "foundation" | "reinforce" | "sprint";
                    date: string | null;
                    status: "pending" | "in-progress" | "completed";
                    requirePractice: boolean;
                    requireReflections: boolean;
                    summary: string;
                    evidence: unknown;
                    startedFromRevision?: number | undefined;
                    lessonId?: string | undefined;
                    reviewOccurrence?: {
                        roundId: string;
                        questionId: string;
                    } | undefined;
                    reviewHistoryCount?: number | undefined;
                } | null;
            }[];
            createdAt: string;
        }[];
        history: {
            revision: number;
            confirmedAt: string;
            draftId: string;
            action: string;
            diff: {
                id: string;
                before: {
                    id: string;
                    revision: number;
                    subject: string;
                    title: string;
                    kind: "learn" | "review" | "practice";
                    phase: "foundation" | "reinforce" | "sprint";
                    date: string | null;
                    status: "pending" | "in-progress" | "completed";
                    requirePractice: boolean;
                    requireReflections: boolean;
                    summary: string;
                    evidence: unknown;
                    startedFromRevision?: number | undefined;
                    lessonId?: string | undefined;
                    reviewOccurrence?: {
                        roundId: string;
                        questionId: string;
                    } | undefined;
                    reviewHistoryCount?: number | undefined;
                } | null;
                after: {
                    id: string;
                    revision: number;
                    subject: string;
                    title: string;
                    kind: "learn" | "review" | "practice";
                    phase: "foundation" | "reinforce" | "sprint";
                    date: string | null;
                    status: "pending" | "in-progress" | "completed";
                    requirePractice: boolean;
                    requireReflections: boolean;
                    summary: string;
                    evidence: unknown;
                    startedFromRevision?: number | undefined;
                    lessonId?: string | undefined;
                    reviewOccurrence?: {
                        roundId: string;
                        questionId: string;
                    } | undefined;
                    reviewHistoryCount?: number | undefined;
                } | null;
            }[];
        }[];
        externalMocks: {
            id: string;
            date: string;
            title: string;
            score: number;
            maximum: number;
            source: "learner-self-report";
        }[];
    }>;
    recordExternalMock(input: {
        date: string;
        title: string;
        score: number;
        maximum: number;
    }, revision: number, confirmed: boolean): Promise<{
        completionProposals: {
            id: string;
            taskId: string;
            baseRevision: number;
            taskRevision: number;
            createdAt: string;
            roundId?: string | undefined;
        }[];
        revision: number;
        goal: {
            examDate: string | null;
            dailyModules: number;
            subjects: {
                name: string;
                weight: number;
            }[];
        } | null;
        tasks: {
            id: string;
            revision: number;
            subject: string;
            title: string;
            kind: "learn" | "review" | "practice";
            phase: "foundation" | "reinforce" | "sprint";
            date: string | null;
            status: "pending" | "in-progress" | "completed";
            requirePractice: boolean;
            requireReflections: boolean;
            summary: string;
            evidence: unknown;
            startedFromRevision?: number | undefined;
            lessonId?: string | undefined;
            reviewOccurrence?: {
                roundId: string;
                questionId: string;
            } | undefined;
            reviewHistoryCount?: number | undefined;
        }[];
        drafts: {
            id: string;
            baseRevision: number;
            action: string;
            goal: {
                examDate: string | null;
                dailyModules: number;
                subjects: {
                    name: string;
                    weight: number;
                }[];
            } | null;
            tasks: {
                id: string;
                revision: number;
                subject: string;
                title: string;
                kind: "learn" | "review" | "practice";
                phase: "foundation" | "reinforce" | "sprint";
                date: string | null;
                status: "pending" | "in-progress" | "completed";
                requirePractice: boolean;
                requireReflections: boolean;
                summary: string;
                evidence: unknown;
                startedFromRevision?: number | undefined;
                lessonId?: string | undefined;
                reviewOccurrence?: {
                    roundId: string;
                    questionId: string;
                } | undefined;
                reviewHistoryCount?: number | undefined;
            }[];
            overflow: string[];
            diff: {
                id: string;
                before: {
                    id: string;
                    revision: number;
                    subject: string;
                    title: string;
                    kind: "learn" | "review" | "practice";
                    phase: "foundation" | "reinforce" | "sprint";
                    date: string | null;
                    status: "pending" | "in-progress" | "completed";
                    requirePractice: boolean;
                    requireReflections: boolean;
                    summary: string;
                    evidence: unknown;
                    startedFromRevision?: number | undefined;
                    lessonId?: string | undefined;
                    reviewOccurrence?: {
                        roundId: string;
                        questionId: string;
                    } | undefined;
                    reviewHistoryCount?: number | undefined;
                } | null;
                after: {
                    id: string;
                    revision: number;
                    subject: string;
                    title: string;
                    kind: "learn" | "review" | "practice";
                    phase: "foundation" | "reinforce" | "sprint";
                    date: string | null;
                    status: "pending" | "in-progress" | "completed";
                    requirePractice: boolean;
                    requireReflections: boolean;
                    summary: string;
                    evidence: unknown;
                    startedFromRevision?: number | undefined;
                    lessonId?: string | undefined;
                    reviewOccurrence?: {
                        roundId: string;
                        questionId: string;
                    } | undefined;
                    reviewHistoryCount?: number | undefined;
                } | null;
            }[];
            createdAt: string;
        }[];
        history: {
            revision: number;
            confirmedAt: string;
            draftId: string;
            action: string;
            diff: {
                id: string;
                before: {
                    id: string;
                    revision: number;
                    subject: string;
                    title: string;
                    kind: "learn" | "review" | "practice";
                    phase: "foundation" | "reinforce" | "sprint";
                    date: string | null;
                    status: "pending" | "in-progress" | "completed";
                    requirePractice: boolean;
                    requireReflections: boolean;
                    summary: string;
                    evidence: unknown;
                    startedFromRevision?: number | undefined;
                    lessonId?: string | undefined;
                    reviewOccurrence?: {
                        roundId: string;
                        questionId: string;
                    } | undefined;
                    reviewHistoryCount?: number | undefined;
                } | null;
                after: {
                    id: string;
                    revision: number;
                    subject: string;
                    title: string;
                    kind: "learn" | "review" | "practice";
                    phase: "foundation" | "reinforce" | "sprint";
                    date: string | null;
                    status: "pending" | "in-progress" | "completed";
                    requirePractice: boolean;
                    requireReflections: boolean;
                    summary: string;
                    evidence: unknown;
                    startedFromRevision?: number | undefined;
                    lessonId?: string | undefined;
                    reviewOccurrence?: {
                        roundId: string;
                        questionId: string;
                    } | undefined;
                    reviewHistoryCount?: number | undefined;
                } | null;
            }[];
        }[];
        externalMocks: {
            id: string;
            date: string;
            title: string;
            score: number;
            maximum: number;
            source: "learner-self-report";
        }[];
    }>;
    private completionEvidence;
    proposeCompletion(taskId: string, revision: number, roundId?: string): Promise<{
        id: string;
        taskId: string;
        baseRevision: number;
        taskRevision: number;
        createdAt: string;
        roundId?: string | undefined;
    }>;
    previewCompletion(id: string, revision: number): Promise<{
        proposal: {
            id: string;
            taskId: string;
            baseRevision: number;
            taskRevision: number;
            createdAt: string;
            roundId?: string | undefined;
        };
        task: {
            id: string;
            revision: number;
            subject: string;
            title: string;
            kind: "learn" | "review" | "practice";
            phase: "foundation" | "reinforce" | "sprint";
            date: string | null;
            status: "pending" | "in-progress" | "completed";
            requirePractice: boolean;
            requireReflections: boolean;
            summary: string;
            evidence: unknown;
            startedFromRevision?: number | undefined;
            lessonId?: string | undefined;
            reviewOccurrence?: {
                roundId: string;
                questionId: string;
            } | undefined;
            reviewHistoryCount?: number | undefined;
        };
        ready: boolean;
        evidence: {
            summary: string;
            proof: unknown;
        };
        missing: null;
    } | {
        proposal: {
            id: string;
            taskId: string;
            baseRevision: number;
            taskRevision: number;
            createdAt: string;
            roundId?: string | undefined;
        };
        task: {
            id: string;
            revision: number;
            subject: string;
            title: string;
            kind: "learn" | "review" | "practice";
            phase: "foundation" | "reinforce" | "sprint";
            date: string | null;
            status: "pending" | "in-progress" | "completed";
            requirePractice: boolean;
            requireReflections: boolean;
            summary: string;
            evidence: unknown;
            startedFromRevision?: number | undefined;
            lessonId?: string | undefined;
            reviewOccurrence?: {
                roundId: string;
                questionId: string;
            } | undefined;
            reviewHistoryCount?: number | undefined;
        };
        ready: boolean;
        evidence: {
            summary: string;
            proof: null;
        };
        missing: string;
    }>;
    close(): Promise<void>;
}
export {};
