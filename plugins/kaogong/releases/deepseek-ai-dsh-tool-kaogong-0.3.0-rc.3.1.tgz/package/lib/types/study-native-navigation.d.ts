export type StudySessionNavigation = {
    sessionId: string;
    profileId: string;
    viewId: string;
};
type NativeNavigation = {
    uiWorkspace: {
        openSession(id: string): void;
    };
    sidebarRight: {
        mounted: {
            getSnapshot(): string | undefined;
            subscribe(listener: () => void): () => void;
        };
        openTab(kind: string, options: {
            params: StudySessionNavigation;
        }): void;
    };
};
/** Native owns the Conversation. This operation only reveals the exact bound
 * Session and waits for its surface before opening the learning tab. */
export declare function openNativeStudySession(native: NativeNavigation, target: StudySessionNavigation, signal: AbortSignal): Promise<void>;
export {};
