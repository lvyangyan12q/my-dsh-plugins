import type { KaogongViewProps } from './kaogong-view.tsx';
export declare function StudyPlanPanel({ onPage, onOpenTeacher }: {
    onPage: (page: string) => void;
    onOpenTeacher: KaogongViewProps['onOpenTeacher'];
}): import("react/jsx-runtime").JSX.Element;
