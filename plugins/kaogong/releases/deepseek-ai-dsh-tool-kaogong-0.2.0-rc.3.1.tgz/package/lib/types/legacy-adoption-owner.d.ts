import type { Context } from '@deepseek-ai/cordis';
import type { Domain } from '@deepseek-ai/dsh-storage-domain';
import type { LegacyRoleSnapshot } from 'dsh-worktable/sdk';
import { type LegacyInspectionSnapshot, type LegacyAdoptionPlan } from './legacy-adoption-plan.ts';
import { adoptionDomain, adoptionPlansDomain } from './legacy-adoption-state.ts';
import type { KaogongHost } from './instance-host.ts';
import type { Config } from './business.ts';
export declare function legacyRoleSource(snapshot: LegacyInspectionSnapshot, sourceKey: string, roleId: string): LegacyRoleSnapshot | null;
/** Authenticated Host-owned preparation/import service. Merely mounting it never reads the legacy home. */
export declare function createAdoptionOwner(ctx: Context, host: KaogongHost, metadata: Domain<typeof adoptionDomain>, planMetadata: Domain<typeof adoptionPlansDomain>, config: Config): {
    prepare: () => Promise<{
        id: string;
        fingerprint: string;
        status: string;
        counts: Record<string, number>;
        privateKnowledge: number;
        roles: {
            roleId: string;
            status: "ready" | "blocked" | "applied";
            phase: unknown;
            native: ("current" | "missing")[] | undefined;
            blockers: {
                code: string;
                reason: string;
            }[];
        }[];
        blockers: {
            code: string;
            roleId?: string;
        }[];
        markdown: string;
    }>;
    inspect: (id: string) => Promise<{
        id: string;
        fingerprint: string;
        status: string;
        counts: Record<string, number>;
        privateKnowledge: number;
        roles: {
            roleId: string;
            status: "ready" | "blocked" | "applied";
            phase: unknown;
            native: ("current" | "missing")[] | undefined;
            blockers: {
                code: string;
                reason: string;
            }[];
        }[];
        blockers: {
            code: string;
            roleId?: string;
        }[];
        markdown: string;
    }>;
    apply: (input: {
        id: string;
        fingerprint: string;
        confirmed: boolean;
    }) => Promise<{
        id: string;
        fingerprint: string;
        status: string;
        counts: Record<string, number>;
        privateKnowledge: number;
        roles: {
            roleId: string;
            status: "ready" | "blocked" | "applied";
            phase: unknown;
            native: ("current" | "missing")[] | undefined;
            blockers: {
                code: string;
                reason: string;
            }[];
        }[];
        blockers: {
            code: string;
            roleId?: string;
        }[];
        markdown: string;
    }>;
    exportPlan: (id: string) => Promise<LegacyAdoptionPlan>;
    close(): Promise<void>;
};
