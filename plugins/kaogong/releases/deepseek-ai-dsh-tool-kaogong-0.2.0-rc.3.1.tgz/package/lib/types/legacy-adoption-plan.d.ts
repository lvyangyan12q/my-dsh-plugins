import type { RoleAdoptionPreview } from 'dsh-worktable/sdk';
import type { LegacyMaterialEvidence } from './legacy-material-evidence.mjs';
import type { LegacyBankImageEvidence } from './legacy-bank-image-evidence.mjs';
import type { LegacyPrivateAssetEvidence } from './legacy-private-assets.mjs';
export declare function canonical(value: unknown): string;
export declare const fingerprint: (value: unknown) => string;
declare const specs: {
    readonly kaogong_bank: readonly ["bank", 2, "questions", import("zod").ZodObject<{
        subject: import("zod").ZodString;
        knowledgePoint: import("zod").ZodString;
        questionType: import("zod").ZodString;
        stem: import("zod").ZodString;
        options: import("zod").ZodArray<import("zod").ZodString>;
        correctAnswer: import("zod").ZodString;
        explanation: import("zod").ZodString;
        difficulty: import("zod").ZodEnum<{
            easy: "easy";
            medium: "medium";
            hard: "hard";
        }>;
        source: import("zod").ZodString;
        origin: import("zod").ZodEnum<{
            web: "web";
            local: "local";
        }>;
        reviewStatus: import("zod").ZodEnum<{
            pending: "pending";
            approved: "approved";
            rejected: "rejected";
        }>;
        reviewNotes: import("zod").ZodString;
        tags: import("zod").ZodArray<import("zod").ZodString>;
        createdAt: import("zod").ZodString;
        reviewedAt: import("zod").ZodString;
    }, import("zod/v4/core").$strip>];
    readonly kaogong_knowledge: readonly ["knowledge", 1, "entries", import("zod").ZodObject<{
        subject: import("zod").ZodString;
        knowledgePoint: import("zod").ZodString;
        title: import("zod").ZodString;
        content: import("zod").ZodString;
        kind: import("zod").ZodEnum<{
            讲义: "讲义";
            笔记: "笔记";
            时政: "时政";
            公式: "公式";
            技巧: "技巧";
            真题解析: "真题解析";
            其他: "其他";
        }>;
        source: import("zod").ZodString;
        tags: import("zod").ZodArray<import("zod").ZodString>;
        createdAt: import("zod").ZodString;
        updatedAt: import("zod").ZodString;
    }, import("zod/v4/core").$strip>];
    readonly kaogong_lessons: readonly ["lessons", 1, "lessons", import("zod").ZodObject<{
        version: import("zod").ZodLiteral<1>;
        instanceId: import("zod").ZodString;
        request: import("zod").ZodObject<{
            lessonId: import("zod").ZodString;
            subject: import("zod").ZodString;
            objective: import("zod").ZodString;
            knowledgePoint: import("zod").ZodOptional<import("zod").ZodString>;
            materialIds: import("zod").ZodArray<import("zod").ZodString>;
            requireReflections: import("zod").ZodBoolean;
            legacyNoteId: import("zod").ZodOptional<import("zod").ZodString>;
        }, import("zod/v4/core").$strict>;
        objectiveId: import("zod").ZodString;
        homeworkId: import("zod").ZodString;
        roleKey: import("zod").ZodObject<{
            appId: import("zod").ZodLiteral<"kaogong">;
            instanceId: import("zod").ZodString;
            roleId: import("zod").ZodLiteral<"teacher">;
            subject: import("zod").ZodString;
        }, import("zod/v4/core").$strip>;
        binding: import("zod").ZodNullable<import("zod").ZodObject<{
            sessionId: import("zod").ZodString;
            presetId: import("zod").ZodString;
        }, import("zod/v4/core").$strip>>;
        materials: import("zod").ZodArray<import("zod").ZodObject<{
            id: import("zod").ZodString;
            title: import("zod").ZodString;
            source: import("zod").ZodString;
            updatedAt: import("zod").ZodString;
        }, import("zod/v4/core").$strip>>;
        legacyNote: import("zod").ZodOptional<import("zod").ZodObject<{
            id: import("zod").ZodString;
            updatedAt: import("zod").ZodString;
        }, import("zod/v4/core").$strip>>;
        roundIds: import("zod").ZodArray<import("zod").ZodString>;
        notes: import("zod").ZodString;
        completion: import("zod").ZodNullable<import("zod").ZodObject<{
            confirmedAt: import("zod").ZodString;
            proofs: import("zod").ZodArray<import("zod").ZodObject<{
                roundId: import("zod").ZodString;
                total: import("zod").ZodNumber;
                correct: import("zod").ZodNumber;
                questionIds: import("zod").ZodArray<import("zod").ZodString>;
                reflectedIds: import("zod").ZodArray<import("zod").ZodString>;
            }, import("zod/v4/core").$strip>>;
        }, import("zod/v4/core").$strip>>;
        createdAt: import("zod").ZodString;
        updatedAt: import("zod").ZodString;
        revision: import("zod").ZodNumber;
    }, import("zod/v4/core").$strip>];
    readonly kaogong_notebook: readonly ["notebook", 1, "questions", import("zod").ZodObject<{
        subject: import("zod").ZodString;
        knowledgePoint: import("zod").ZodString;
        questionType: import("zod").ZodString;
        stem: import("zod").ZodString;
        options: import("zod").ZodArray<import("zod").ZodString>;
        correctAnswer: import("zod").ZodString;
        userAnswer: import("zod").ZodString;
        result: import("zod").ZodEnum<{
            correct: "correct";
            wrong: "wrong";
            skipped: "skipped";
        }>;
        errorReason: import("zod").ZodString;
        notes: import("zod").ZodString;
        source: import("zod").ZodString;
        tags: import("zod").ZodArray<import("zod").ZodString>;
        createdAt: import("zod").ZodString;
        updatedAt: import("zod").ZodString;
        practiceRoundId: import("zod").ZodOptional<import("zod").ZodString>;
        practiceSequence: import("zod").ZodOptional<import("zod").ZodNumber>;
        practiceRevision: import("zod").ZodOptional<import("zod").ZodNumber>;
    }, import("zod/v4/core").$strip>];
    readonly kaogong_practice: readonly ["practice", 1, "rounds", import("zod").ZodObject<{
        version: import("zod").ZodLiteral<1>;
        context: import("zod").ZodObject<{
            subject: import("zod").ZodString;
            title: import("zod").ZodString;
            knowledgePoint: import("zod").ZodOptional<import("zod").ZodString>;
            limit: import("zod").ZodLiteral<10>;
            planIndex: import("zod").ZodOptional<import("zod").ZodNumber>;
        }, import("zod/v4/core").$strip>;
        questions: import("zod").ZodArray<import("zod").ZodObject<{
            subject: import("zod").ZodString;
            knowledgePoint: import("zod").ZodString;
            questionType: import("zod").ZodString;
            stem: import("zod").ZodString;
            options: import("zod").ZodArray<import("zod").ZodString>;
            correctAnswer: import("zod").ZodString;
            explanation: import("zod").ZodString;
            difficulty: import("zod").ZodEnum<{
                easy: "easy";
                medium: "medium";
                hard: "hard";
            }>;
            source: import("zod").ZodString;
            origin: import("zod").ZodEnum<{
                web: "web";
                local: "local";
            }>;
            reviewStatus: import("zod").ZodEnum<{
                pending: "pending";
                approved: "approved";
                rejected: "rejected";
            }>;
            reviewNotes: import("zod").ZodString;
            tags: import("zod").ZodArray<import("zod").ZodString>;
            createdAt: import("zod").ZodString;
            reviewedAt: import("zod").ZodString;
            id: import("zod").ZodString;
        }, import("zod/v4/core").$strip>>;
        seenIds: import("zod").ZodArray<import("zod").ZodString>;
        reason: import("zod").ZodString;
        totalAvailable: import("zod").ZodNumber;
        cycled: import("zod").ZodBoolean;
        createdAt: import("zod").ZodString;
        score: import("zod").ZodOptional<import("zod").ZodObject<{
            answers: import("zod").ZodArray<import("zod").ZodObject<{
                id: import("zod").ZodString;
                answer: import("zod").ZodString;
            }, import("zod/v4/core").$strip>>;
            sequence: import("zod").ZodNumber;
            submittedAt: import("zod").ZodString;
        }, import("zod/v4/core").$strip>>;
        reflections: import("zod").ZodArray<import("zod").ZodObject<{
            id: import("zod").ZodString;
            errorReason: import("zod").ZodString;
            notes: import("zod").ZodOptional<import("zod").ZodString>;
            savedAt: import("zod").ZodOptional<import("zod").ZodString>;
            notesRevision: import("zod").ZodOptional<import("zod").ZodNumber>;
        }, import("zod/v4/core").$strip>>;
        revision: import("zod").ZodNumber;
        projectedRevision: import("zod").ZodNumber;
        changedAt: import("zod").ZodString;
        review: import("zod").ZodEnum<{
            ready: "ready";
            sending: "sending";
            sent: "sent";
        }>;
        reviewClaim: import("zod").ZodOptional<import("zod").ZodObject<{
            taskId: import("zod").ZodString;
            requestId: import("zod").ZodString;
        }, import("zod/v4/core").$strip>>;
    }, import("zod/v4/core").$strip>];
    readonly kaogong_progress: readonly ["progress", 1, "days", import("zod").ZodObject<{
        date: import("zod").ZodString;
        phase: import("zod").ZodEnum<{
            foundation: "foundation";
            reinforce: "reinforce";
            sprint: "sprint";
        }>;
        items: import("zod").ZodArray<import("zod").ZodObject<{
            subject: import("zod").ZodString;
            kind: import("zod").ZodEnum<{
                learn: "learn";
                review: "review";
                practice: "practice";
                mock: "mock";
            }>;
            title: import("zod").ZodString;
            done: import("zod").ZodBoolean;
        }, import("zod/v4/core").$strip>>;
    }, import("zod/v4/core").$strip>];
};
type Domain = typeof specs[keyof typeof specs][0];
export type LegacyInspectionSnapshot = {
    format: string;
    formatVersion: number;
    private: true;
    sourceHome: string;
    sourceRevision: string;
    files: {
        name: string;
        sourcePath: string;
        resolvedPath: string;
        version: number;
        table: string;
        sha256: string;
        bytesBase64: string;
    }[];
};
export type RoleInput = {
    sourceKey: string;
    roleId: string;
    revision: string;
    binding: Record<string, unknown>;
};
type Inspection = Pick<RoleAdoptionPreview, 'status' | 'fingerprint' | 'blockers' | 'source' | 'native'>;
export type LegacyAdoptionPlan = {
    format: 'kaogong-adoption-plan';
    formatVersion: 1;
    private: true;
    id: string;
    status: 'ready' | 'blocked';
    fingerprint: string;
    source: {
        home: string;
        revision: string;
        files: {
            name: string;
            resolvedPath: string;
            sha256: string;
            version: number;
        }[];
    };
    targets: {
        history: {
            instanceId: string;
            viewId: string;
            appId: 'kaogong';
            projectId: null;
        };
        library: {
            instanceId: string;
            viewId: string;
            appId: 'kaogong-library';
            projectId: null;
        };
    };
    records: {
        domain: Domain;
        target: 'history' | 'library';
        key: string;
        value: unknown;
        hash: string;
    }[];
    globals: {
        domain: 'progress' | 'lessons';
        target: 'history';
        value: unknown;
        hash: string;
    }[];
    roles: (RoleInput & {
        inspection: Inspection;
    })[];
    privateKnowledgeIds: string[];
    counts: Record<string, number>;
    readOnlyGrants: {
        resourceId: 'question-bank' | 'materials';
        owner: 'library';
        consumer: 'history';
    }[];
    assetEvidence?: {
        materials?: LegacyMaterialEvidence;
        bank?: LegacyBankImageEvidence;
        private?: LegacyPrivateAssetEvidence;
    };
    blockers: {
        code: string;
        roleId?: string;
    }[];
    rollback: {
        mode: 'journal-only-no-source-or-profile-restore';
        schemaGate: 5;
        sourceWrites: 0;
        nativeMessagesCopied: false;
        newerTargetRows: 'never-overwrite-or-delete';
        legacyAssets: 'preserved-unadopted-until-verified-owner-manifest';
    };
};
/** Pure preparation over a private byte snapshot. No domain, native Session or target is created. */
export declare function legacyRoleInput(sourceRevision: string, id: string, binding: Record<string, unknown>): RoleInput | null;
export declare function prepareLegacyAdoption({ snapshot, inspectRole, materialEvidence }: {
    snapshot: LegacyInspectionSnapshot;
    inspectRole: (input: RoleInput) => Promise<Inspection>;
    materialEvidence?: LegacyMaterialEvidence;
}): Promise<LegacyAdoptionPlan>;
export {};
