import type { KaogongInstanceState } from './instance-state.ts';
import type { AdoptionTarget } from './legacy-adoption-workflow.ts';
/** Domain API only. Parsing is repeated at the write boundary after exact-shape planning. */
export declare function adoptionTarget(state: KaogongInstanceState): AdoptionTarget;
