import type { LegacyAdoptionPlan } from './legacy-adoption-plan.ts';
/** Bounded, read-only hash fence for each import checkpoint; never opens legacy domains. */
export declare function revalidatePlanSource(plan: LegacyAdoptionPlan, sourceHome: string): Promise<void>;
