/** Instance-scoped learning command registrations.
 * The production Host validates the view/native Session and leases owned state
 * before dispatch. This module never opens or repairs a legacy domain.
 */
import type { Context, Volatile } from '@deepseek-ai/cordis';
import { Mineru } from './mineru.ts';
import type { MineruConfig } from './mineru.ts';
import z from '@deepseek-ai/schemastery';
/** Plugin configuration, validated by the schemastery schema below. */
export interface Config {
    /** Read only on explicit adoption preview; mounting never reads or writes this old home. */
    legacySourceHome?: string;
    /** Canonical legacy material collection root, independent from the parser jobs outputDir. */
    legacyMaterialRoot?: string;
    /** Explicit absolute location for new role Sessions; persisted before creation. */
    roleCwd?: string;
    /** Existing image directory, independent of the installed package; no automatic copying. */
    questionImageRoot: Volatile<string | undefined>;
    /** Number of weak knowledge points to surface in summaries. */
    topN?: number;
    mineru: Volatile<MineruConfig | undefined>;
}
/** Schemastery schema for {@link Config}. */
export declare const Config: z<Schemastery.ObjectS<NoInfer<{
    legacySourceHome: z<string, string, "plain">;
    legacyMaterialRoot: z<string, string, "plain">;
    roleCwd: z<string, string, "plain">;
    questionImageRoot: z<string, string, "volatile">;
    topN: z<number, number, "defined">;
    mineru: z<NoInfer<Schemastery.ObjectS<NoInfer<{
        token: z<string, string, "plain">;
        model: z<"vlm" | "pipeline", "vlm" | "pipeline", "defined">;
        outputDir: z<string, string, "plain">;
    }>>>, NoInfer<Schemastery.ObjectT<NoInfer<{
        token: z<string, string, "plain">;
        model: z<"vlm" | "pipeline", "vlm" | "pipeline", "defined">;
        outputDir: z<string, string, "plain">;
    }>>>, "volatile">;
}>>, Schemastery.ObjectT<NoInfer<{
    legacySourceHome: z<string, string, "plain">;
    legacyMaterialRoot: z<string, string, "plain">;
    roleCwd: z<string, string, "plain">;
    questionImageRoot: z<string, string, "volatile">;
    topN: z<number, number, "defined">;
    mineru: z<NoInfer<Schemastery.ObjectS<NoInfer<{
        token: z<string, string, "plain">;
        model: z<"vlm" | "pipeline", "vlm" | "pipeline", "defined">;
        outputDir: z<string, string, "plain">;
    }>>>, NoInfer<Schemastery.ObjectT<NoInfer<{
        token: z<string, string, "plain">;
        model: z<"vlm" | "pipeline", "vlm" | "pipeline", "defined">;
        outputDir: z<string, string, "plain">;
    }>>>, "volatile">;
}>>, "plain">;
/**
 * Open the notebook + progress domains and register every tool.
 * @param ctx - registrant context carrying the tool registry.
 * @param config - deployment configuration.
 */
export type MineruAccess = Pick<Mineru, 'root' | 'start' | 'collect' | 'image'>;
export interface BusinessRegistry {
    webServer: Pick<Context['webServer'], 'register'>;
    tools: Pick<Context['tools'], 'register'>;
    effect(operation: () => (() => void), label?: string): unknown;
}
/** Registers pure business commands over an already leased instance; it never opens legacy domains. */
export declare function registerBusiness(ctx: BusinessRegistry, config: Config, state: import('./instance-state.ts').KaogongInstanceState, mineru: MineruAccess): void;
