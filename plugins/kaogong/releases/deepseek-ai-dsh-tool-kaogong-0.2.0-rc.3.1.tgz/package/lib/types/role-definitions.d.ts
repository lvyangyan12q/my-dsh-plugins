import type { Context } from '@deepseek-ai/cordis';
import type { RoleDefinition, PrivateCapability } from 'dsh-worktable/sdk';
export declare const legacyTeacherPresetId = "personal-workbench.kaogong-teacher.v1";
export declare const teachingSkillProvider = "kaogong-packaged-teaching";
export declare const roleSubjects: string[];
export declare const subjectRoleIds: string[];
/** Application-owned personas and trusted installation Skill root; never loads roles/cordis.yml. */
export declare function kaogongRolePresets(): Promise<{
    id: string;
    name: string;
    description: string;
    plugins: ({
        name: string;
        config: {
            prefix: string;
            complete: boolean;
            includeRuntimeContext: boolean;
            providerName?: undefined;
            includeDefaultRoots?: undefined;
            customSkillDirs?: undefined;
            bundledSkillDir?: undefined;
            watch?: undefined;
        };
    } | {
        name: string;
        config: {
            providerName: string;
            includeDefaultRoots: boolean;
            customSkillDirs: never[];
            bundledSkillDir: string;
            watch: boolean;
            prefix?: undefined;
            complete?: undefined;
            includeRuntimeContext?: undefined;
        };
    } | {
        name: string;
        config: {
            prefix?: undefined;
            complete?: undefined;
            includeRuntimeContext?: undefined;
            providerName?: undefined;
            includeDefaultRoots?: undefined;
            customSkillDirs?: undefined;
            bundledSkillDir?: undefined;
            watch?: undefined;
        };
    })[];
}[]>;
/** Explicit deployment location is captured by each durable intent, not inferred from process cwd. */
export declare function kaogongPrivateCapabilities(): PrivateCapability[];
export declare function kaogongRoleDefinitions(cwd?: string): RoleDefinition[];
/** Registration owns declarations only; no native Session is created or silently adopted. */
export declare function installKaogongRoles(ctx: Context, cwd?: string): Promise<() => Promise<void>>;
