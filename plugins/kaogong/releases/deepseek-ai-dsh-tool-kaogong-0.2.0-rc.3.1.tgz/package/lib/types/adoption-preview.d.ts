import type { LegacyAdoptionPlan } from './legacy-adoption-plan.ts';
export declare function adoptionPreview(plan: LegacyAdoptionPlan, status?: string): {
    id: string;
    fingerprint: string;
    status: string;
    counts: Record<string, number>;
    privateKnowledge: number;
    roles: {
        roleId: string;
        status: "ready" | "blocked" | "applied";
        phase: unknown;
        native: ("current" | "missing")[] | undefined;
        blockers: {
            code: string;
            reason: string;
        }[];
    }[];
    blockers: {
        code: string;
        roleId?: string;
    }[];
    markdown: string;
};
