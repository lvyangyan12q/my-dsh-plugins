import { type LegacyInspectionSnapshot, type LegacyAdoptionPlan } from './legacy-adoption-plan.ts';
/** Explicit configured roots are read only on concrete preparation, never plugin activation. */
export declare function inspectAdoptionEvidence(snapshot: LegacyInspectionSnapshot, roots: {
    materialRoot?: string;
    questionImageRoot?: string;
    mineruRoot?: string;
}): Promise<{
    bank?: import("./legacy-bank-image-evidence.mjs").LegacyBankImageEvidence | undefined;
    private?: import("./legacy-private-assets.mjs").LegacyPrivateAssetEvidence | undefined;
    materials?: import("./legacy-material-evidence.mjs").LegacyMaterialEvidence | undefined;
}>;
export declare function pinAdoptionEvidence(plan: LegacyAdoptionPlan, evidence: NonNullable<LegacyAdoptionPlan['assetEvidence']>): LegacyAdoptionPlan;
/** Full dependency proof at entry/exit; cheap seven-source hashes guard bounded record chunks. */
export declare function revalidateAdoptionEvidence(plan: LegacyAdoptionPlan, snapshot: LegacyInspectionSnapshot): Promise<void>;
