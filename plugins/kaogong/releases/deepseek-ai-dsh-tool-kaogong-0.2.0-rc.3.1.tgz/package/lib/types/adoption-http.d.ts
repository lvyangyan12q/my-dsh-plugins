import type { Context } from '@deepseek-ai/cordis';
import type { createAdoptionOwner } from './legacy-adoption-owner.ts';
/** No arbitrary filesystem path, native identity, target ID, or business record is accepted from a browser. */
export declare function mountAdoptionHttp(ctx: Context, owner: ReturnType<typeof createAdoptionOwner>): () => void;
