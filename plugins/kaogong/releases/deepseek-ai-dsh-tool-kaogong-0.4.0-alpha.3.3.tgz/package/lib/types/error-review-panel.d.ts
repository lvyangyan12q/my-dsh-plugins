export declare function ErrorReviewPanel(props?: {
    onPlan?: () => void;
    occurrenceId?: string;
    resumeTaskId?: string;
    onChanged?(): void;
}): import("react/jsx-runtime").JSX.Element;
export declare function ReviewQueue({ onOpen }: {
    onOpen(): void;
}): import("react/jsx-runtime").JSX.Element;
