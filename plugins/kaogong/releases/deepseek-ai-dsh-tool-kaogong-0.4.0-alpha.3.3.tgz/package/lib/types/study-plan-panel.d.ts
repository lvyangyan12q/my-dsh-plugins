import type { KaogongViewProps } from './kaogong-view.tsx';
export declare function StudyPlanPanel({ onPage, onOpenTeacher, todayOnly, nextOnly }: {
    nextOnly?: boolean;
    todayOnly?: boolean;
    onPage: (page: string) => void;
    onOpenTeacher: KaogongViewProps['onOpenTeacher'];
}): import("react/jsx-runtime").JSX.Element;
