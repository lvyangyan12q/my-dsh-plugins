import type { KaogongViewProps } from './kaogong-view.tsx';
import type { LessonView } from './lesson-schema.ts';
export declare function LessonCloseout({ view, notes, accept, onReturnToday, onOpenTeacher }: {
    view: LessonView;
    notes: string;
    accept(value: LessonView): void;
    onReturnToday?: () => void;
    onOpenTeacher: KaogongViewProps['onOpenTeacher'];
}): import("react/jsx-runtime").JSX.Element;
