import type { BusinessRegistry } from './business.ts';
import type { KaogongInstanceState } from './instance-state.ts';
/** Read projection over the owned archive and currently authorized material overlay. */
export declare function registerLearningRoute(registry: BusinessRegistry, state: KaogongInstanceState): () => void;
