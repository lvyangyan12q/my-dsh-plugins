/**
 * Pure backward (倒排) study-plan scheduling. No runtime dependencies: it
 * turns a plan config + an exam date into a day-by-day schedule from today
 * to the exam, split into foundation / reinforce / sprint phases.
 * @module kaogong/schedule
 */
export type PhaseKind = 'foundation' | 'reinforce' | 'sprint';
export type ItemKind = 'learn' | 'review' | 'practice' | 'mock';
/** One subject with its scheduling weight. */
export interface SubjectPlan {
    name: string;
    weight: number;
}
/** Plan configuration. */
export interface PlanConfig {
    /** 考试日期，YYYY-MM-DD. */
    examDate: string;
    /** 每天学习模块数（一个模块 ≈ 一个知识点/一次练习）. */
    dailyModules: number;
    /** 备考科目与权重. */
    subjects: SubjectPlan[];
}
/** One scheduled item on a day. */
export interface DayItem {
    knowledgePoint?: string;
    subject: string;
    kind: ItemKind;
    title: string;
    done: boolean;
}
/** One scheduled day. */
export interface DayPlan {
    date: string;
    phase: PhaseKind;
    items: DayItem[];
}
/** Phase size summary. */
export interface PhaseInfo {
    phase: PhaseKind;
    days: number;
}
/** The generated plan. */
export interface GeneratedPlan {
    today: string;
    examDate: string;
    totalDays: number;
    phases: PhaseInfo[];
    days: DayPlan[];
}
/** Return whether a value is a real calendar date in YYYY-MM-DD form. */
export declare function isValidIsoDate(iso: string): boolean;
/** Inclusive day count from today through the day before the exam. */
export declare function daysToExam(todayIso: string, examIso: string): number;
/** Add n days to a YYYY-MM-DD date and return the new YYYY-MM-DD. */
export declare function addDays(iso: string, n: number): string;
/**
 * Generate a backward study schedule.
 * @param config - plan configuration.
 * @param today - today's date, YYYY-MM-DD.
 * @returns the generated plan.
 */
export declare function generatePlan(config: PlanConfig, today: string): GeneratedPlan;
