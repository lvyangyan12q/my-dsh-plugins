type Props = {
    initialPointId?: string | null;
    initialOccurrenceId?: string | null;
    onClearTarget?(): void;
};
export declare function ReviewCenter(props: Props): import("react/jsx-runtime").JSX.Element;
export {};
