import type { DomainGlobalSpec } from '@deepseek-ai/dsh-storage-domain';
export { questionRecord, planConfig, dayItem, dayPlan, bankQuestion, knowledgeEntry } from './schemas.ts';
export type { QuestionRecord, PlanConfig, DayPlanRecord, BankQuestionRecord, KnowledgeEntryRecord } from './schemas.ts';
/** The wrong-answer notebook domain: one `questions` table keyed by id. */
export declare const notebookDomainSpec: {
    name: string;
    version: number;
    tables: {
        questions: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, {
            subject: string;
            knowledgePoint: string;
            questionType: string;
            stem: string;
            options: string[];
            correctAnswer: string;
            userAnswer: string;
            result: "correct" | "wrong" | "skipped";
            errorReason: string;
            notes: string;
            source: string;
            tags: string[];
            createdAt: string;
            updatedAt: string;
            practiceRoundId?: string | undefined;
            practiceSequence?: number | undefined;
            practiceRevision?: number | undefined;
        }>;
    };
};
/** Default subjects: every taxonomy module, equal weight. */
export declare function defaultSubjects(): {
    name: string;
    weight: number;
}[];
export declare const progressDomainSpec: {
    name: string;
    version: number;
    global: DomainGlobalSpec<{
        examDate: string;
        dailyModules: number;
        subjects: {
            name: string;
            weight: number;
        }[];
    }>;
    tables: {
        days: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, {
            date: string;
            phase: "foundation" | "reinforce" | "sprint";
            items: {
                subject: string;
                kind: "learn" | "review" | "practice" | "mock";
                title: string;
                done: boolean;
            }[];
        }>;
    };
};
/** The question-bank domain: one `questions` table keyed by id, for targeted practice. */
export declare const bankDomainSpec: {
    name: string;
    version: number;
    tables: {
        questions: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, {
            subject: string;
            knowledgePoint: string;
            questionType: string;
            stem: string;
            options: string[];
            correctAnswer: string;
            explanation: string;
            difficulty: "easy" | "medium" | "hard";
            source: string;
            origin: "web" | "local";
            reviewStatus: "pending" | "approved" | "rejected";
            reviewNotes: string;
            tags: string[];
            createdAt: string;
            reviewedAt: string;
        }>;
    };
};
/** The knowledge-base domain: one `entries` table keyed by id, for study-material retrieval. */
export declare const knowledgeDomainSpec: {
    name: string;
    version: number;
    tables: {
        entries: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, {
            subject: string;
            knowledgePoint: string;
            title: string;
            content: string;
            kind: "讲义" | "笔记" | "时政" | "公式" | "技巧" | "真题解析" | "其他";
            source: string;
            tags: string[];
            createdAt: string;
            updatedAt: string;
        }>;
    };
};
/** Additive default-instance practice history; existing domains keep their versions. */
export declare const practiceDomainSpec: {
    name: string;
    version: number;
    tables: {
        rounds: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, {
            version: 1;
            context: {
                subject: string;
                title: string;
                limit: 10;
                knowledgePointId?: string | undefined;
                knowledgePoint?: string | undefined;
                planIndex?: number | undefined;
                taskId?: string | undefined;
                planRevision?: number | undefined;
            };
            questions: {
                subject: string;
                knowledgePoint: string;
                questionType: string;
                stem: string;
                options: string[];
                correctAnswer: string;
                explanation: string;
                difficulty: "easy" | "medium" | "hard";
                source: string;
                origin: "web" | "local";
                reviewStatus: "pending" | "approved" | "rejected";
                reviewNotes: string;
                tags: string[];
                createdAt: string;
                reviewedAt: string;
                id: string;
            }[];
            seenIds: string[];
            reason: string;
            totalAvailable: number;
            cycled: boolean;
            createdAt: string;
            reflections: {
                id: string;
                errorReason: string;
                notes?: string | undefined;
                savedAt?: string | undefined;
                notesRevision?: number | undefined;
            }[];
            revision: number;
            projectedRevision: number;
            changedAt: string;
            review: "ready" | "sending" | "sent";
            score?: {
                answers: {
                    id: string;
                    answer: string;
                }[];
                sequence: number;
                submittedAt: string;
            } | undefined;
            reviewClaim?: {
                taskId: string;
                requestId: string;
            } | undefined;
        }>;
    };
};
export declare const lessonDomainSpec: {
    name: string;
    version: number;
    global: DomainGlobalSpec<{
        instanceId: string;
        activeLessonId: string | null;
    }>;
    tables: {
        lessons: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, {
            version: 1;
            instanceId: string;
            request: {
                lessonId: string;
                subject: string;
                objective: string;
                materialIds: string[];
                requireReflections: boolean;
                knowledgePointId?: string | undefined;
                knowledgePoint?: string | undefined;
                requirePractice?: boolean | undefined;
                taskId?: string | undefined;
                planRevision?: number | undefined;
                legacyNoteId?: string | undefined;
            };
            objectiveId: string;
            homeworkId: string;
            roleKey: {
                appId: "kaogong";
                instanceId: string;
                roleId: "teacher";
                subject: string;
            };
            binding: {
                sessionId: string;
                presetId: string;
            } | null;
            materials: {
                id: string;
                title: string;
                source: string;
                updatedAt: string;
            }[];
            roundIds: string[];
            notes: string;
            completion: {
                confirmedAt: string;
                proofs: {
                    roundId: string;
                    total: number;
                    correct: number;
                    questionIds: string[];
                    reflectedIds: string[];
                }[];
                summary?: string | undefined;
            } | null;
            createdAt: string;
            updatedAt: string;
            revision: number;
            legacyNote?: {
                id: string;
                updatedAt: string;
            } | undefined;
        }>;
    };
};
/** Legacy names are metadata for explicit adoption; opening them is not a read-only inspection. */
export declare const legacyDomainSpecs: Readonly<{
    notebook: {
        name: string;
        version: number;
        tables: {
            questions: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, {
                subject: string;
                knowledgePoint: string;
                questionType: string;
                stem: string;
                options: string[];
                correctAnswer: string;
                userAnswer: string;
                result: "correct" | "wrong" | "skipped";
                errorReason: string;
                notes: string;
                source: string;
                tags: string[];
                createdAt: string;
                updatedAt: string;
                practiceRoundId?: string | undefined;
                practiceSequence?: number | undefined;
                practiceRevision?: number | undefined;
            }>;
        };
    };
    progress: {
        name: string;
        version: number;
        global: DomainGlobalSpec<{
            examDate: string;
            dailyModules: number;
            subjects: {
                name: string;
                weight: number;
            }[];
        }>;
        tables: {
            days: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, {
                date: string;
                phase: "foundation" | "reinforce" | "sprint";
                items: {
                    subject: string;
                    kind: "learn" | "review" | "practice" | "mock";
                    title: string;
                    done: boolean;
                }[];
            }>;
        };
    };
    bank: {
        name: string;
        version: number;
        tables: {
            questions: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, {
                subject: string;
                knowledgePoint: string;
                questionType: string;
                stem: string;
                options: string[];
                correctAnswer: string;
                explanation: string;
                difficulty: "easy" | "medium" | "hard";
                source: string;
                origin: "web" | "local";
                reviewStatus: "pending" | "approved" | "rejected";
                reviewNotes: string;
                tags: string[];
                createdAt: string;
                reviewedAt: string;
            }>;
        };
    };
    knowledge: {
        name: string;
        version: number;
        tables: {
            entries: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, {
                subject: string;
                knowledgePoint: string;
                title: string;
                content: string;
                kind: "讲义" | "笔记" | "时政" | "公式" | "技巧" | "真题解析" | "其他";
                source: string;
                tags: string[];
                createdAt: string;
                updatedAt: string;
            }>;
        };
    };
    practice: {
        name: string;
        version: number;
        tables: {
            rounds: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, {
                version: 1;
                context: {
                    subject: string;
                    title: string;
                    limit: 10;
                    knowledgePointId?: string | undefined;
                    knowledgePoint?: string | undefined;
                    planIndex?: number | undefined;
                    taskId?: string | undefined;
                    planRevision?: number | undefined;
                };
                questions: {
                    subject: string;
                    knowledgePoint: string;
                    questionType: string;
                    stem: string;
                    options: string[];
                    correctAnswer: string;
                    explanation: string;
                    difficulty: "easy" | "medium" | "hard";
                    source: string;
                    origin: "web" | "local";
                    reviewStatus: "pending" | "approved" | "rejected";
                    reviewNotes: string;
                    tags: string[];
                    createdAt: string;
                    reviewedAt: string;
                    id: string;
                }[];
                seenIds: string[];
                reason: string;
                totalAvailable: number;
                cycled: boolean;
                createdAt: string;
                reflections: {
                    id: string;
                    errorReason: string;
                    notes?: string | undefined;
                    savedAt?: string | undefined;
                    notesRevision?: number | undefined;
                }[];
                revision: number;
                projectedRevision: number;
                changedAt: string;
                review: "ready" | "sending" | "sent";
                score?: {
                    answers: {
                        id: string;
                        answer: string;
                    }[];
                    sequence: number;
                    submittedAt: string;
                } | undefined;
                reviewClaim?: {
                    taskId: string;
                    requestId: string;
                } | undefined;
            }>;
        };
    };
    lessons: {
        name: string;
        version: number;
        global: DomainGlobalSpec<{
            instanceId: string;
            activeLessonId: string | null;
        }>;
        tables: {
            lessons: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, {
                version: 1;
                instanceId: string;
                request: {
                    lessonId: string;
                    subject: string;
                    objective: string;
                    materialIds: string[];
                    requireReflections: boolean;
                    knowledgePointId?: string | undefined;
                    knowledgePoint?: string | undefined;
                    requirePractice?: boolean | undefined;
                    taskId?: string | undefined;
                    planRevision?: number | undefined;
                    legacyNoteId?: string | undefined;
                };
                objectiveId: string;
                homeworkId: string;
                roleKey: {
                    appId: "kaogong";
                    instanceId: string;
                    roleId: "teacher";
                    subject: string;
                };
                binding: {
                    sessionId: string;
                    presetId: string;
                } | null;
                materials: {
                    id: string;
                    title: string;
                    source: string;
                    updatedAt: string;
                }[];
                roundIds: string[];
                notes: string;
                completion: {
                    confirmedAt: string;
                    proofs: {
                        roundId: string;
                        total: number;
                        correct: number;
                        questionIds: string[];
                        reflectedIds: string[];
                    }[];
                    summary?: string | undefined;
                } | null;
                createdAt: string;
                updatedAt: string;
                revision: number;
                legacyNote?: {
                    id: string;
                    updatedAt: string;
                } | undefined;
            }>;
        };
    };
}>;
/** Only explicit platform instance identities enter the new namespace; never alias legacy default. */
export declare function instanceDomainSpecs(instanceId: string): {
    closeouts: {
        name: string;
        version: number;
        tables: {
            operations: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, {
                input: {
                    operationId: string;
                    lessonId: string;
                    notes: string;
                    confirmed: true;
                    joinRecall: boolean;
                    roundId?: string | undefined;
                };
                status: "pending" | "complete";
                lessonSaved: boolean;
                planSaved: boolean;
                recallSaved: boolean;
                error?: string | undefined;
                selectedRoundId?: string | undefined;
            }>;
        };
    };
    plan: {
        name: string;
        version: number;
        tables: {};
        global: {
            schema: import("zod").ZodObject<{
                revision: import("zod").ZodNumber;
                goal: import("zod").ZodNullable<import("zod").ZodObject<{
                    examDate: import("zod").ZodNullable<import("zod").ZodString>;
                    dailyModules: import("zod").ZodNumber;
                    subjects: import("zod").ZodArray<import("zod").ZodObject<{
                        name: import("zod").ZodString;
                        weight: import("zod").ZodNumber;
                    }, import("zod/v4/core").$strip>>;
                }, import("zod/v4/core").$strict>>;
                tasks: import("zod").ZodArray<import("zod").ZodObject<{
                    id: import("zod").ZodString;
                    revision: import("zod").ZodNumber;
                    subject: import("zod").ZodString;
                    title: import("zod").ZodString;
                    kind: import("zod").ZodEnum<{
                        learn: "learn";
                        review: "review";
                        practice: "practice";
                    }>;
                    phase: import("zod").ZodEnum<{
                        foundation: "foundation";
                        reinforce: "reinforce";
                        sprint: "sprint";
                    }>;
                    date: import("zod").ZodNullable<import("zod").ZodString>;
                    status: import("zod").ZodEnum<{
                        pending: "pending";
                        "in-progress": "in-progress";
                        completed: "completed";
                    }>;
                    requirePractice: import("zod").ZodBoolean;
                    requireReflections: import("zod").ZodBoolean;
                    summary: import("zod").ZodString;
                    evidence: import("zod").ZodNullable<import("zod").ZodUnknown>;
                    knowledgePointId: import("zod").ZodOptional<import("zod").ZodString>;
                    knowledgePoint: import("zod").ZodOptional<import("zod").ZodString>;
                    startedFromRevision: import("zod").ZodOptional<import("zod").ZodNumber>;
                    lessonId: import("zod").ZodOptional<import("zod").ZodString>;
                    reviewOccurrence: import("zod").ZodOptional<import("zod").ZodObject<{
                        roundId: import("zod").ZodString;
                        questionId: import("zod").ZodString;
                    }, import("zod/v4/core").$strict>>;
                    reviewCycle: import("zod").ZodOptional<import("zod").ZodString>;
                    recallReference: import("zod").ZodOptional<import("zod").ZodObject<{
                        pointId: import("zod").ZodString;
                        cycleId: import("zod").ZodString;
                    }, import("zod/v4/core").$strip>>;
                    reviewHistoryCount: import("zod").ZodOptional<import("zod").ZodNumber>;
                }, import("zod/v4/core").$strip>>;
                drafts: import("zod").ZodArray<import("zod").ZodObject<{
                    id: import("zod").ZodString;
                    baseRevision: import("zod").ZodNumber;
                    action: import("zod").ZodString;
                    goal: import("zod").ZodNullable<import("zod").ZodObject<{
                        examDate: import("zod").ZodNullable<import("zod").ZodString>;
                        dailyModules: import("zod").ZodNumber;
                        subjects: import("zod").ZodArray<import("zod").ZodObject<{
                            name: import("zod").ZodString;
                            weight: import("zod").ZodNumber;
                        }, import("zod/v4/core").$strip>>;
                    }, import("zod/v4/core").$strict>>;
                    tasks: import("zod").ZodArray<import("zod").ZodObject<{
                        id: import("zod").ZodString;
                        revision: import("zod").ZodNumber;
                        subject: import("zod").ZodString;
                        title: import("zod").ZodString;
                        kind: import("zod").ZodEnum<{
                            learn: "learn";
                            review: "review";
                            practice: "practice";
                        }>;
                        phase: import("zod").ZodEnum<{
                            foundation: "foundation";
                            reinforce: "reinforce";
                            sprint: "sprint";
                        }>;
                        date: import("zod").ZodNullable<import("zod").ZodString>;
                        status: import("zod").ZodEnum<{
                            pending: "pending";
                            "in-progress": "in-progress";
                            completed: "completed";
                        }>;
                        requirePractice: import("zod").ZodBoolean;
                        requireReflections: import("zod").ZodBoolean;
                        summary: import("zod").ZodString;
                        evidence: import("zod").ZodNullable<import("zod").ZodUnknown>;
                        knowledgePointId: import("zod").ZodOptional<import("zod").ZodString>;
                        knowledgePoint: import("zod").ZodOptional<import("zod").ZodString>;
                        startedFromRevision: import("zod").ZodOptional<import("zod").ZodNumber>;
                        lessonId: import("zod").ZodOptional<import("zod").ZodString>;
                        reviewOccurrence: import("zod").ZodOptional<import("zod").ZodObject<{
                            roundId: import("zod").ZodString;
                            questionId: import("zod").ZodString;
                        }, import("zod/v4/core").$strict>>;
                        reviewCycle: import("zod").ZodOptional<import("zod").ZodString>;
                        recallReference: import("zod").ZodOptional<import("zod").ZodObject<{
                            pointId: import("zod").ZodString;
                            cycleId: import("zod").ZodString;
                        }, import("zod/v4/core").$strip>>;
                        reviewHistoryCount: import("zod").ZodOptional<import("zod").ZodNumber>;
                    }, import("zod/v4/core").$strip>>;
                    overflow: import("zod").ZodArray<import("zod").ZodString>;
                    diff: import("zod").ZodArray<import("zod").ZodObject<{
                        id: import("zod").ZodString;
                        before: import("zod").ZodNullable<import("zod").ZodObject<{
                            id: import("zod").ZodString;
                            revision: import("zod").ZodNumber;
                            subject: import("zod").ZodString;
                            title: import("zod").ZodString;
                            kind: import("zod").ZodEnum<{
                                learn: "learn";
                                review: "review";
                                practice: "practice";
                            }>;
                            phase: import("zod").ZodEnum<{
                                foundation: "foundation";
                                reinforce: "reinforce";
                                sprint: "sprint";
                            }>;
                            date: import("zod").ZodNullable<import("zod").ZodString>;
                            status: import("zod").ZodEnum<{
                                pending: "pending";
                                "in-progress": "in-progress";
                                completed: "completed";
                            }>;
                            requirePractice: import("zod").ZodBoolean;
                            requireReflections: import("zod").ZodBoolean;
                            summary: import("zod").ZodString;
                            evidence: import("zod").ZodNullable<import("zod").ZodUnknown>;
                            knowledgePointId: import("zod").ZodOptional<import("zod").ZodString>;
                            knowledgePoint: import("zod").ZodOptional<import("zod").ZodString>;
                            startedFromRevision: import("zod").ZodOptional<import("zod").ZodNumber>;
                            lessonId: import("zod").ZodOptional<import("zod").ZodString>;
                            reviewOccurrence: import("zod").ZodOptional<import("zod").ZodObject<{
                                roundId: import("zod").ZodString;
                                questionId: import("zod").ZodString;
                            }, import("zod/v4/core").$strict>>;
                            reviewCycle: import("zod").ZodOptional<import("zod").ZodString>;
                            recallReference: import("zod").ZodOptional<import("zod").ZodObject<{
                                pointId: import("zod").ZodString;
                                cycleId: import("zod").ZodString;
                            }, import("zod/v4/core").$strip>>;
                            reviewHistoryCount: import("zod").ZodOptional<import("zod").ZodNumber>;
                        }, import("zod/v4/core").$strip>>;
                        after: import("zod").ZodNullable<import("zod").ZodObject<{
                            id: import("zod").ZodString;
                            revision: import("zod").ZodNumber;
                            subject: import("zod").ZodString;
                            title: import("zod").ZodString;
                            kind: import("zod").ZodEnum<{
                                learn: "learn";
                                review: "review";
                                practice: "practice";
                            }>;
                            phase: import("zod").ZodEnum<{
                                foundation: "foundation";
                                reinforce: "reinforce";
                                sprint: "sprint";
                            }>;
                            date: import("zod").ZodNullable<import("zod").ZodString>;
                            status: import("zod").ZodEnum<{
                                pending: "pending";
                                "in-progress": "in-progress";
                                completed: "completed";
                            }>;
                            requirePractice: import("zod").ZodBoolean;
                            requireReflections: import("zod").ZodBoolean;
                            summary: import("zod").ZodString;
                            evidence: import("zod").ZodNullable<import("zod").ZodUnknown>;
                            knowledgePointId: import("zod").ZodOptional<import("zod").ZodString>;
                            knowledgePoint: import("zod").ZodOptional<import("zod").ZodString>;
                            startedFromRevision: import("zod").ZodOptional<import("zod").ZodNumber>;
                            lessonId: import("zod").ZodOptional<import("zod").ZodString>;
                            reviewOccurrence: import("zod").ZodOptional<import("zod").ZodObject<{
                                roundId: import("zod").ZodString;
                                questionId: import("zod").ZodString;
                            }, import("zod/v4/core").$strict>>;
                            reviewCycle: import("zod").ZodOptional<import("zod").ZodString>;
                            recallReference: import("zod").ZodOptional<import("zod").ZodObject<{
                                pointId: import("zod").ZodString;
                                cycleId: import("zod").ZodString;
                            }, import("zod/v4/core").$strip>>;
                            reviewHistoryCount: import("zod").ZodOptional<import("zod").ZodNumber>;
                        }, import("zod/v4/core").$strip>>;
                    }, import("zod/v4/core").$strip>>;
                    createdAt: import("zod").ZodString;
                }, import("zod/v4/core").$strip>>;
                completionProposals: import("zod").ZodDefault<import("zod").ZodArray<import("zod").ZodObject<{
                    id: import("zod").ZodString;
                    taskId: import("zod").ZodString;
                    baseRevision: import("zod").ZodNumber;
                    taskRevision: import("zod").ZodNumber;
                    roundId: import("zod").ZodOptional<import("zod").ZodString>;
                    createdAt: import("zod").ZodString;
                }, import("zod/v4/core").$strip>>>;
                history: import("zod").ZodArray<import("zod").ZodObject<{
                    revision: import("zod").ZodNumber;
                    confirmedAt: import("zod").ZodString;
                    draftId: import("zod").ZodString;
                    action: import("zod").ZodString;
                    diff: import("zod").ZodArray<import("zod").ZodObject<{
                        id: import("zod").ZodString;
                        before: import("zod").ZodNullable<import("zod").ZodObject<{
                            id: import("zod").ZodString;
                            revision: import("zod").ZodNumber;
                            subject: import("zod").ZodString;
                            title: import("zod").ZodString;
                            kind: import("zod").ZodEnum<{
                                learn: "learn";
                                review: "review";
                                practice: "practice";
                            }>;
                            phase: import("zod").ZodEnum<{
                                foundation: "foundation";
                                reinforce: "reinforce";
                                sprint: "sprint";
                            }>;
                            date: import("zod").ZodNullable<import("zod").ZodString>;
                            status: import("zod").ZodEnum<{
                                pending: "pending";
                                "in-progress": "in-progress";
                                completed: "completed";
                            }>;
                            requirePractice: import("zod").ZodBoolean;
                            requireReflections: import("zod").ZodBoolean;
                            summary: import("zod").ZodString;
                            evidence: import("zod").ZodNullable<import("zod").ZodUnknown>;
                            knowledgePointId: import("zod").ZodOptional<import("zod").ZodString>;
                            knowledgePoint: import("zod").ZodOptional<import("zod").ZodString>;
                            startedFromRevision: import("zod").ZodOptional<import("zod").ZodNumber>;
                            lessonId: import("zod").ZodOptional<import("zod").ZodString>;
                            reviewOccurrence: import("zod").ZodOptional<import("zod").ZodObject<{
                                roundId: import("zod").ZodString;
                                questionId: import("zod").ZodString;
                            }, import("zod/v4/core").$strict>>;
                            reviewCycle: import("zod").ZodOptional<import("zod").ZodString>;
                            recallReference: import("zod").ZodOptional<import("zod").ZodObject<{
                                pointId: import("zod").ZodString;
                                cycleId: import("zod").ZodString;
                            }, import("zod/v4/core").$strip>>;
                            reviewHistoryCount: import("zod").ZodOptional<import("zod").ZodNumber>;
                        }, import("zod/v4/core").$strip>>;
                        after: import("zod").ZodNullable<import("zod").ZodObject<{
                            id: import("zod").ZodString;
                            revision: import("zod").ZodNumber;
                            subject: import("zod").ZodString;
                            title: import("zod").ZodString;
                            kind: import("zod").ZodEnum<{
                                learn: "learn";
                                review: "review";
                                practice: "practice";
                            }>;
                            phase: import("zod").ZodEnum<{
                                foundation: "foundation";
                                reinforce: "reinforce";
                                sprint: "sprint";
                            }>;
                            date: import("zod").ZodNullable<import("zod").ZodString>;
                            status: import("zod").ZodEnum<{
                                pending: "pending";
                                "in-progress": "in-progress";
                                completed: "completed";
                            }>;
                            requirePractice: import("zod").ZodBoolean;
                            requireReflections: import("zod").ZodBoolean;
                            summary: import("zod").ZodString;
                            evidence: import("zod").ZodNullable<import("zod").ZodUnknown>;
                            knowledgePointId: import("zod").ZodOptional<import("zod").ZodString>;
                            knowledgePoint: import("zod").ZodOptional<import("zod").ZodString>;
                            startedFromRevision: import("zod").ZodOptional<import("zod").ZodNumber>;
                            lessonId: import("zod").ZodOptional<import("zod").ZodString>;
                            reviewOccurrence: import("zod").ZodOptional<import("zod").ZodObject<{
                                roundId: import("zod").ZodString;
                                questionId: import("zod").ZodString;
                            }, import("zod/v4/core").$strict>>;
                            reviewCycle: import("zod").ZodOptional<import("zod").ZodString>;
                            recallReference: import("zod").ZodOptional<import("zod").ZodObject<{
                                pointId: import("zod").ZodString;
                                cycleId: import("zod").ZodString;
                            }, import("zod/v4/core").$strip>>;
                            reviewHistoryCount: import("zod").ZodOptional<import("zod").ZodNumber>;
                        }, import("zod/v4/core").$strip>>;
                    }, import("zod/v4/core").$strip>>;
                }, import("zod/v4/core").$strip>>;
                externalMocks: import("zod").ZodArray<import("zod").ZodObject<{
                    id: import("zod").ZodString;
                    date: import("zod").ZodString;
                    title: import("zod").ZodString;
                    score: import("zod").ZodNumber;
                    maximum: import("zod").ZodNumber;
                    source: import("zod").ZodLiteral<"learner-self-report">;
                }, import("zod/v4/core").$strip>>;
            }, import("zod/v4/core").$strip>;
            initial: {
                revision: number;
                goal: null;
                tasks: never[];
                drafts: never[];
                completionProposals: never[];
                history: never[];
                externalMocks: never[];
            };
        };
    };
    recalls: {
        name: string;
        version: number;
        tables: {
            recalls: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, {
                version: 1;
                pointId: string;
                cycleId: string;
                enrolledAt: string;
                dueAt: string;
                history: {
                    cycleId: string;
                    recall: string;
                    rating: "forgotten" | "fuzzy" | "remembered";
                    referenceIds: string[];
                    referenceEvidence: {
                        id: string;
                        fingerprint: string;
                    }[];
                    confirmedAt: string;
                }[];
                recall?: string | undefined;
                revealedAt?: string | undefined;
                referenceIds?: string[] | undefined;
                referenceEvidence?: {
                    id: string;
                    fingerprint: string;
                }[] | undefined;
            }>;
        };
    };
    reviews: {
        name: string;
        version: number;
        tables: {
            reviews: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, {
                version: 1;
                stage: number;
                status: "scheduled" | "pending-correction" | "consolidated";
                dueAt: string;
                enrolledAt: string;
                history: {
                    id: string;
                    requestId: string;
                    answer: string;
                    correct: boolean;
                    answeredAt: string;
                    reflection?: string | undefined;
                    confirmedAt?: string | undefined;
                    planTaskId?: string | undefined;
                }[];
            }>;
        };
    };
    notebook: {
        name: string;
        version: number;
        tables: {
            questions: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, {
                subject: string;
                knowledgePoint: string;
                questionType: string;
                stem: string;
                options: string[];
                correctAnswer: string;
                userAnswer: string;
                result: "correct" | "wrong" | "skipped";
                errorReason: string;
                notes: string;
                source: string;
                tags: string[];
                createdAt: string;
                updatedAt: string;
                practiceRoundId?: string | undefined;
                practiceSequence?: number | undefined;
                practiceRevision?: number | undefined;
            }>;
        };
    };
    progress: {
        name: string;
        version: number;
        global: DomainGlobalSpec<{
            examDate: string;
            dailyModules: number;
            subjects: {
                name: string;
                weight: number;
            }[];
        }>;
        tables: {
            days: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, {
                date: string;
                phase: "foundation" | "reinforce" | "sprint";
                items: {
                    subject: string;
                    kind: "learn" | "review" | "practice" | "mock";
                    title: string;
                    done: boolean;
                }[];
            }>;
        };
    };
    bank: {
        name: string;
        version: number;
        tables: {
            questions: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, {
                subject: string;
                knowledgePoint: string;
                questionType: string;
                stem: string;
                options: string[];
                correctAnswer: string;
                explanation: string;
                difficulty: "easy" | "medium" | "hard";
                source: string;
                origin: "web" | "local";
                reviewStatus: "pending" | "approved" | "rejected";
                reviewNotes: string;
                tags: string[];
                createdAt: string;
                reviewedAt: string;
            }>;
        };
    };
    knowledge: {
        name: string;
        version: number;
        tables: {
            entries: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, {
                subject: string;
                knowledgePoint: string;
                title: string;
                content: string;
                kind: "讲义" | "笔记" | "时政" | "公式" | "技巧" | "真题解析" | "其他";
                source: string;
                tags: string[];
                createdAt: string;
                updatedAt: string;
            }>;
        };
    };
    practice: {
        name: string;
        version: number;
        tables: {
            rounds: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, {
                version: 1;
                context: {
                    subject: string;
                    title: string;
                    limit: 10;
                    knowledgePointId?: string | undefined;
                    knowledgePoint?: string | undefined;
                    planIndex?: number | undefined;
                    taskId?: string | undefined;
                    planRevision?: number | undefined;
                };
                questions: {
                    subject: string;
                    knowledgePoint: string;
                    questionType: string;
                    stem: string;
                    options: string[];
                    correctAnswer: string;
                    explanation: string;
                    difficulty: "easy" | "medium" | "hard";
                    source: string;
                    origin: "web" | "local";
                    reviewStatus: "pending" | "approved" | "rejected";
                    reviewNotes: string;
                    tags: string[];
                    createdAt: string;
                    reviewedAt: string;
                    id: string;
                }[];
                seenIds: string[];
                reason: string;
                totalAvailable: number;
                cycled: boolean;
                createdAt: string;
                reflections: {
                    id: string;
                    errorReason: string;
                    notes?: string | undefined;
                    savedAt?: string | undefined;
                    notesRevision?: number | undefined;
                }[];
                revision: number;
                projectedRevision: number;
                changedAt: string;
                review: "ready" | "sending" | "sent";
                score?: {
                    answers: {
                        id: string;
                        answer: string;
                    }[];
                    sequence: number;
                    submittedAt: string;
                } | undefined;
                reviewClaim?: {
                    taskId: string;
                    requestId: string;
                } | undefined;
            }>;
        };
    };
    lessons: {
        name: string;
        global: {
            schema: import("zod").ZodObject<{
                instanceId: import("zod").ZodString;
                activeLessonId: import("zod").ZodNullable<import("zod").ZodString>;
            }, import("zod/v4/core").$strip>;
            initial: {
                instanceId: string;
                activeLessonId: null;
            };
        };
        tables: {
            lessons: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, {
                version: 1;
                instanceId: string;
                request: {
                    lessonId: string;
                    subject: string;
                    objective: string;
                    materialIds: string[];
                    requireReflections: boolean;
                    knowledgePointId?: string | undefined;
                    knowledgePoint?: string | undefined;
                    requirePractice?: boolean | undefined;
                    taskId?: string | undefined;
                    planRevision?: number | undefined;
                    legacyNoteId?: string | undefined;
                };
                objectiveId: string;
                homeworkId: string;
                roleKey: {
                    appId: "kaogong";
                    instanceId: string;
                    roleId: "teacher";
                    subject: string;
                };
                binding: {
                    sessionId: string;
                    presetId: string;
                } | null;
                materials: {
                    id: string;
                    title: string;
                    source: string;
                    updatedAt: string;
                }[];
                roundIds: string[];
                notes: string;
                completion: {
                    confirmedAt: string;
                    proofs: {
                        roundId: string;
                        total: number;
                        correct: number;
                        questionIds: string[];
                        reflectedIds: string[];
                    }[];
                    summary?: string | undefined;
                } | null;
                createdAt: string;
                updatedAt: string;
                revision: number;
                legacyNote?: {
                    id: string;
                    updatedAt: string;
                } | undefined;
            }>;
        };
        version: number;
    };
};
