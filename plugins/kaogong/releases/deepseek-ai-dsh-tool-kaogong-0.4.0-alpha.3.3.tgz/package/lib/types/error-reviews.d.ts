import { z } from 'zod';
import type { KvTable } from '@deepseek-ai/dsh-storage-domain';
import type { PracticeRound } from './schemas.ts';
export declare const reviewRecord: z.ZodObject<{
    version: z.ZodLiteral<1>;
    stage: z.ZodNumber;
    status: z.ZodEnum<{
        scheduled: "scheduled";
        "pending-correction": "pending-correction";
        consolidated: "consolidated";
    }>;
    dueAt: z.ZodString;
    enrolledAt: z.ZodString;
    history: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        requestId: z.ZodString;
        answer: z.ZodString;
        correct: z.ZodBoolean;
        answeredAt: z.ZodString;
        reflection: z.ZodOptional<z.ZodString>;
        confirmedAt: z.ZodOptional<z.ZodString>;
        planTaskId: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
}, z.core.$strip>;
export type ReviewRecord = z.infer<typeof reviewRecord>;
export declare const occurrenceId: (roundId: string, questionId: string) => string;
/** Historical errors come from immutable scored round snapshots, never the latest notebook row. */
export declare class ErrorReviews {
    private rounds;
    private reviews;
    private tail;
    command(body: Record<string, unknown>): Promise<{
        version: 1;
        stage: number;
        status: "scheduled" | "pending-correction" | "consolidated";
        dueAt: string;
        enrolledAt: string;
        history: {
            id: string;
            requestId: string;
            answer: string;
            correct: boolean;
            answeredAt: string;
            reflection?: string | undefined;
            confirmedAt?: string | undefined;
            planTaskId?: string | undefined;
        }[];
    } | {
        id: string;
        requestId: string;
        answer: string;
        correct: boolean;
        answeredAt: string;
        reflection?: string | undefined;
        confirmedAt?: string | undefined;
        planTaskId?: string | undefined;
    } | {
        id: `${string}-${string}-${string}-${string}-${string}`;
        requestId: string;
        answer: string;
        correct: boolean;
        answeredAt: string;
        planTaskId?: string | undefined;
    }>;
    close(): Promise<void>;
    constructor(rounds: KvTable<string, PracticeRound>, reviews: KvTable<string, ReviewRecord>);
    list(filters?: Record<string, string>): {
        occurrences: {
            id: string;
            questionId: string;
            roundId: string;
            userAnswer: string;
            submittedAt: string;
            errorReason: string;
            notes: string;
            review: {
                version: 1;
                stage: number;
                status: "scheduled" | "pending-correction" | "consolidated";
                dueAt: string;
                enrolledAt: string;
                history: {
                    id: string;
                    requestId: string;
                    answer: string;
                    correct: boolean;
                    answeredAt: string;
                    reflection?: string | undefined;
                    confirmedAt?: string | undefined;
                    planTaskId?: string | undefined;
                }[];
            } | null;
            subject: string;
            knowledgePoint: string;
            questionType: string;
            stem: string;
            options: string[];
            correctAnswer: string;
            explanation: string;
            difficulty: "easy" | "medium" | "hard";
            source: string;
            origin: "web" | "local";
            reviewStatus: "pending" | "approved" | "rejected";
            reviewNotes: string;
            tags: string[];
            createdAt: string;
            reviewedAt: string;
        }[];
    };
    readForPlan(id: string): {
        row: {
            id: string;
            questionId: string;
            roundId: string;
            userAnswer: string;
            submittedAt: string;
            errorReason: string;
            notes: string;
            review: {
                version: 1;
                stage: number;
                status: "scheduled" | "pending-correction" | "consolidated";
                dueAt: string;
                enrolledAt: string;
                history: {
                    id: string;
                    requestId: string;
                    answer: string;
                    correct: boolean;
                    answeredAt: string;
                    reflection?: string | undefined;
                    confirmedAt?: string | undefined;
                    planTaskId?: string | undefined;
                }[];
            } | null;
            subject: string;
            knowledgePoint: string;
            questionType: string;
            stem: string;
            options: string[];
            correctAnswer: string;
            explanation: string;
            difficulty: "easy" | "medium" | "hard";
            source: string;
            origin: "web" | "local";
            reviewStatus: "pending" | "approved" | "rejected";
            reviewNotes: string;
            tags: string[];
            createdAt: string;
            reviewedAt: string;
        };
        review: {
            version: 1;
            stage: number;
            status: "scheduled" | "pending-correction" | "consolidated";
            dueAt: string;
            enrolledAt: string;
            history: {
                id: string;
                requestId: string;
                answer: string;
                correct: boolean;
                answeredAt: string;
                reflection?: string | undefined;
                confirmedAt?: string | undefined;
                planTaskId?: string | undefined;
            }[];
        };
    };
    readConfirmed(id: string, after?: string, minimumIndex?: number): {
        occurrenceId: string;
        roundId: string;
        questionId: string;
        subject: string;
        knowledgePoint: string;
        planTaskId: string | undefined;
        attemptId: string;
        confirmedAt: string;
        reflection: string;
    };
    queue(): {
        total: number;
        due: number;
    };
    private occurrence;
    private apply;
}
