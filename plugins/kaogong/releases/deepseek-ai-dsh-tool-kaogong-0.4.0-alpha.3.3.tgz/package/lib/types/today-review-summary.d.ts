export declare function TodayReviewSummary({ onOpen }: {
    onOpen(): void;
}): import("react/jsx-runtime").JSX.Element;
