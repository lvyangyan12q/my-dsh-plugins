import { z } from 'zod';
import type { KvTable } from '@deepseek-ai/dsh-storage-domain';
export declare function recallReferenceEvidence(references: {
    id: string;
    content: string;
}[]): {
    id: string;
    fingerprint: string;
}[];
export declare const recallRecord: z.ZodObject<{
    version: z.ZodLiteral<1>;
    pointId: z.ZodString;
    cycleId: z.ZodString;
    enrolledAt: z.ZodString;
    dueAt: z.ZodString;
    recall: z.ZodOptional<z.ZodString>;
    revealedAt: z.ZodOptional<z.ZodString>;
    referenceIds: z.ZodOptional<z.ZodArray<z.ZodString>>;
    referenceEvidence: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        fingerprint: z.ZodString;
    }, z.core.$strip>>>;
    history: z.ZodDefault<z.ZodArray<z.ZodObject<{
        cycleId: z.ZodString;
        recall: z.ZodString;
        rating: z.ZodEnum<{
            forgotten: "forgotten";
            fuzzy: "fuzzy";
            remembered: "remembered";
        }>;
        referenceIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
        referenceEvidence: z.ZodDefault<z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            fingerprint: z.ZodString;
        }, z.core.$strip>>>;
        confirmedAt: z.ZodString;
    }, z.core.$strip>>>;
}, z.core.$strip>;
export type RecallRecord = z.infer<typeof recallRecord>;
export declare class Recalls {
    private table;
    private tail;
    constructor(table: KvTable<string, RecallRecord>);
    list(): {
        version: 1;
        pointId: string;
        cycleId: string;
        enrolledAt: string;
        dueAt: string;
        history: {
            cycleId: string;
            recall: string;
            rating: "forgotten" | "fuzzy" | "remembered";
            referenceIds: string[];
            referenceEvidence: {
                id: string;
                fingerprint: string;
            }[];
            confirmedAt: string;
        }[];
        recall?: string | undefined;
        revealedAt?: string | undefined;
        referenceIds?: string[] | undefined;
        referenceEvidence?: {
            id: string;
            fingerprint: string;
        }[] | undefined;
    }[];
    enroll(pointId: string, confirmed: boolean): Promise<{
        version: 1;
        pointId: string;
        cycleId: string;
        enrolledAt: string;
        dueAt: string;
        history: {
            cycleId: string;
            recall: string;
            rating: "forgotten" | "fuzzy" | "remembered";
            referenceIds: string[];
            referenceEvidence: {
                id: string;
                fingerprint: string;
            }[];
            confirmedAt: string;
        }[];
        recall?: string | undefined;
        revealedAt?: string | undefined;
        referenceIds?: string[] | undefined;
        referenceEvidence?: {
            id: string;
            fingerprint: string;
        }[] | undefined;
    }>;
    command(body: {
        action: 'answer' | 'reveal' | 'confirm';
        pointId: string;
        cycleId: string;
        recall?: string;
        earlyConfirmed?: boolean;
        confirmed?: boolean;
        rating?: 'forgotten' | 'fuzzy' | 'remembered';
    }, references: () => {
        id: string;
        content: string;
    }[]): Promise<{
        version: 1;
        pointId: string;
        cycleId: string;
        enrolledAt: string;
        dueAt: string;
        history: {
            cycleId: string;
            recall: string;
            rating: "forgotten" | "fuzzy" | "remembered";
            referenceIds: string[];
            referenceEvidence: {
                id: string;
                fingerprint: string;
            }[];
            confirmedAt: string;
        }[];
        recall?: string | undefined;
        revealedAt?: string | undefined;
        referenceIds?: string[] | undefined;
        referenceEvidence?: {
            id: string;
            fingerprint: string;
        }[] | undefined;
    }>;
    close(): Promise<void>;
}
