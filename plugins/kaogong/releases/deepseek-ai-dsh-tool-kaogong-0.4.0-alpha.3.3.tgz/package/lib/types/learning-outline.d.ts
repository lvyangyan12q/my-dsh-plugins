/** Frozen identities: preserve IDs when changing labels or ordering. */
export declare const learningOutline: readonly [{
    readonly subject: "行测-言语理解与表达";
    readonly knowledgePoint: "逻辑填空";
    readonly id: "kg-point-001";
    readonly chapter: "逻辑填空";
}, {
    readonly subject: "行测-言语理解与表达";
    readonly knowledgePoint: "片段阅读-主旨概括";
    readonly id: "kg-point-002";
    readonly chapter: "片段阅读";
}, {
    readonly subject: "行测-言语理解与表达";
    readonly knowledgePoint: "片段阅读-意图判断";
    readonly id: "kg-point-003";
    readonly chapter: "片段阅读";
}, {
    readonly subject: "行测-言语理解与表达";
    readonly knowledgePoint: "片段阅读-细节理解";
    readonly id: "kg-point-004";
    readonly chapter: "片段阅读";
}, {
    readonly subject: "行测-言语理解与表达";
    readonly knowledgePoint: "片段阅读-标题填入";
    readonly id: "kg-point-005";
    readonly chapter: "片段阅读";
}, {
    readonly subject: "行测-言语理解与表达";
    readonly knowledgePoint: "片段阅读-词句理解";
    readonly id: "kg-point-006";
    readonly chapter: "片段阅读";
}, {
    readonly subject: "行测-言语理解与表达";
    readonly knowledgePoint: "片段阅读-态度观点";
    readonly id: "kg-point-007";
    readonly chapter: "片段阅读";
}, {
    readonly subject: "行测-言语理解与表达";
    readonly knowledgePoint: "语句表达-语句排序";
    readonly id: "kg-point-008";
    readonly chapter: "语句表达";
}, {
    readonly subject: "行测-言语理解与表达";
    readonly knowledgePoint: "语句表达-语句衔接";
    readonly id: "kg-point-009";
    readonly chapter: "语句表达";
}, {
    readonly subject: "行测-言语理解与表达";
    readonly knowledgePoint: "语句表达-病句辨析";
    readonly id: "kg-point-010";
    readonly chapter: "语句表达";
}, {
    readonly subject: "行测-言语理解与表达";
    readonly knowledgePoint: "文章阅读";
    readonly id: "kg-point-011";
    readonly chapter: "文章阅读";
}, {
    readonly subject: "行测-数量关系";
    readonly knowledgePoint: "数字推理";
    readonly id: "kg-point-012";
    readonly chapter: "数字推理";
}, {
    readonly subject: "行测-数量关系";
    readonly knowledgePoint: "数学运算-工程问题";
    readonly id: "kg-point-013";
    readonly chapter: "数学运算";
}, {
    readonly subject: "行测-数量关系";
    readonly knowledgePoint: "数学运算-行程问题";
    readonly id: "kg-point-014";
    readonly chapter: "数学运算";
}, {
    readonly subject: "行测-数量关系";
    readonly knowledgePoint: "数学运算-利润问题";
    readonly id: "kg-point-015";
    readonly chapter: "数学运算";
}, {
    readonly subject: "行测-数量关系";
    readonly knowledgePoint: "数学运算-排列组合";
    readonly id: "kg-point-016";
    readonly chapter: "数学运算";
}, {
    readonly subject: "行测-数量关系";
    readonly knowledgePoint: "数学运算-概率问题";
    readonly id: "kg-point-017";
    readonly chapter: "数学运算";
}, {
    readonly subject: "行测-数量关系";
    readonly knowledgePoint: "数学运算-几何问题";
    readonly id: "kg-point-018";
    readonly chapter: "数学运算";
}, {
    readonly subject: "行测-数量关系";
    readonly knowledgePoint: "数学运算-和差倍比";
    readonly id: "kg-point-019";
    readonly chapter: "数学运算";
}, {
    readonly subject: "行测-数量关系";
    readonly knowledgePoint: "数学运算-年龄问题";
    readonly id: "kg-point-020";
    readonly chapter: "数学运算";
}, {
    readonly subject: "行测-数量关系";
    readonly knowledgePoint: "数学运算-容斥问题";
    readonly id: "kg-point-021";
    readonly chapter: "数学运算";
}, {
    readonly subject: "行测-数量关系";
    readonly knowledgePoint: "数学运算-浓度问题";
    readonly id: "kg-point-022";
    readonly chapter: "数学运算";
}, {
    readonly subject: "行测-数量关系";
    readonly knowledgePoint: "数学运算-植树/方阵";
    readonly id: "kg-point-023";
    readonly chapter: "数学运算";
}, {
    readonly subject: "行测-数量关系";
    readonly knowledgePoint: "数学运算-牛吃草";
    readonly id: "kg-point-024";
    readonly chapter: "数学运算";
}, {
    readonly subject: "行测-数量关系";
    readonly knowledgePoint: "数学运算-日期/时钟";
    readonly id: "kg-point-025";
    readonly chapter: "数学运算";
}, {
    readonly subject: "行测-数量关系";
    readonly knowledgePoint: "数学运算-最值/统筹";
    readonly id: "kg-point-026";
    readonly chapter: "数学运算";
}, {
    readonly subject: "行测-判断推理";
    readonly knowledgePoint: "图形推理-位置规律";
    readonly id: "kg-point-027";
    readonly chapter: "图形推理";
}, {
    readonly subject: "行测-判断推理";
    readonly knowledgePoint: "图形推理-样式规律";
    readonly id: "kg-point-028";
    readonly chapter: "图形推理";
}, {
    readonly subject: "行测-判断推理";
    readonly knowledgePoint: "图形推理-属性规律";
    readonly id: "kg-point-029";
    readonly chapter: "图形推理";
}, {
    readonly subject: "行测-判断推理";
    readonly knowledgePoint: "图形推理-数量规律";
    readonly id: "kg-point-030";
    readonly chapter: "图形推理";
}, {
    readonly subject: "行测-判断推理";
    readonly knowledgePoint: "图形推理-空间重构（立体图形）";
    readonly id: "kg-point-031";
    readonly chapter: "图形推理";
}, {
    readonly subject: "行测-判断推理";
    readonly knowledgePoint: "图形推理-特殊规律";
    readonly id: "kg-point-032";
    readonly chapter: "图形推理";
}, {
    readonly subject: "行测-判断推理";
    readonly knowledgePoint: "定义判断";
    readonly id: "kg-point-033";
    readonly chapter: "定义判断";
}, {
    readonly subject: "行测-判断推理";
    readonly knowledgePoint: "类比推理-语义关系";
    readonly id: "kg-point-034";
    readonly chapter: "类比推理";
}, {
    readonly subject: "行测-判断推理";
    readonly knowledgePoint: "类比推理-逻辑关系";
    readonly id: "kg-point-035";
    readonly chapter: "类比推理";
}, {
    readonly subject: "行测-判断推理";
    readonly knowledgePoint: "类比推理-语法关系";
    readonly id: "kg-point-036";
    readonly chapter: "类比推理";
}, {
    readonly subject: "行测-判断推理";
    readonly knowledgePoint: "类比推理-集合关系";
    readonly id: "kg-point-037";
    readonly chapter: "类比推理";
}, {
    readonly subject: "行测-判断推理";
    readonly knowledgePoint: "类比推理-对应关系";
    readonly id: "kg-point-038";
    readonly chapter: "类比推理";
}, {
    readonly subject: "行测-判断推理";
    readonly knowledgePoint: "逻辑判断-翻译推理";
    readonly id: "kg-point-039";
    readonly chapter: "逻辑判断";
}, {
    readonly subject: "行测-判断推理";
    readonly knowledgePoint: "逻辑判断-真假推理";
    readonly id: "kg-point-040";
    readonly chapter: "逻辑判断";
}, {
    readonly subject: "行测-判断推理";
    readonly knowledgePoint: "逻辑判断-分析推理（组合排列）";
    readonly id: "kg-point-041";
    readonly chapter: "逻辑判断";
}, {
    readonly subject: "行测-判断推理";
    readonly knowledgePoint: "逻辑判断-加强/削弱";
    readonly id: "kg-point-042";
    readonly chapter: "逻辑判断";
}, {
    readonly subject: "行测-判断推理";
    readonly knowledgePoint: "逻辑判断-归纳推理";
    readonly id: "kg-point-043";
    readonly chapter: "逻辑判断";
}, {
    readonly subject: "行测-判断推理";
    readonly knowledgePoint: "逻辑判断-日常结论";
    readonly id: "kg-point-044";
    readonly chapter: "逻辑判断";
}, {
    readonly subject: "行测-判断推理";
    readonly knowledgePoint: "逻辑判断-原因解释";
    readonly id: "kg-point-045";
    readonly chapter: "逻辑判断";
}, {
    readonly subject: "行测-判断推理";
    readonly knowledgePoint: "逻辑判断-前提假设";
    readonly id: "kg-point-046";
    readonly chapter: "逻辑判断";
}, {
    readonly subject: "行测-资料分析";
    readonly knowledgePoint: "增长-增长率";
    readonly id: "kg-point-047";
    readonly chapter: "增长";
}, {
    readonly subject: "行测-资料分析";
    readonly knowledgePoint: "增长-增长量";
    readonly id: "kg-point-048";
    readonly chapter: "增长";
}, {
    readonly subject: "行测-资料分析";
    readonly knowledgePoint: "增长-基期量";
    readonly id: "kg-point-049";
    readonly chapter: "增长";
}, {
    readonly subject: "行测-资料分析";
    readonly knowledgePoint: "增长-现期量";
    readonly id: "kg-point-050";
    readonly chapter: "增长";
}, {
    readonly subject: "行测-资料分析";
    readonly knowledgePoint: "增长-隔年增长";
    readonly id: "kg-point-051";
    readonly chapter: "增长";
}, {
    readonly subject: "行测-资料分析";
    readonly knowledgePoint: "增长-年均增长";
    readonly id: "kg-point-052";
    readonly chapter: "增长";
}, {
    readonly subject: "行测-资料分析";
    readonly knowledgePoint: "增长-混合增长";
    readonly id: "kg-point-053";
    readonly chapter: "增长";
}, {
    readonly subject: "行测-资料分析";
    readonly knowledgePoint: "比重-现期比重";
    readonly id: "kg-point-054";
    readonly chapter: "比重";
}, {
    readonly subject: "行测-资料分析";
    readonly knowledgePoint: "比重-基期比重";
    readonly id: "kg-point-055";
    readonly chapter: "比重";
}, {
    readonly subject: "行测-资料分析";
    readonly knowledgePoint: "比重-比重变化";
    readonly id: "kg-point-056";
    readonly chapter: "比重";
}, {
    readonly subject: "行测-资料分析";
    readonly knowledgePoint: "平均数-现期平均数";
    readonly id: "kg-point-057";
    readonly chapter: "平均数";
}, {
    readonly subject: "行测-资料分析";
    readonly knowledgePoint: "平均数-基期平均数";
    readonly id: "kg-point-058";
    readonly chapter: "平均数";
}, {
    readonly subject: "行测-资料分析";
    readonly knowledgePoint: "平均数-平均数变化";
    readonly id: "kg-point-059";
    readonly chapter: "平均数";
}, {
    readonly subject: "行测-资料分析";
    readonly knowledgePoint: "倍数与比值";
    readonly id: "kg-point-060";
    readonly chapter: "倍数与比值";
}, {
    readonly subject: "行测-资料分析";
    readonly knowledgePoint: "计算技巧（截位直除/特殊值）";
    readonly id: "kg-point-061";
    readonly chapter: "计算技巧（截位直除/特殊值）";
}, {
    readonly subject: "行测-常识判断";
    readonly knowledgePoint: "政治";
    readonly id: "kg-point-062";
    readonly chapter: "政治";
}, {
    readonly subject: "行测-常识判断";
    readonly knowledgePoint: "法律";
    readonly id: "kg-point-063";
    readonly chapter: "法律";
}, {
    readonly subject: "行测-常识判断";
    readonly knowledgePoint: "经济";
    readonly id: "kg-point-064";
    readonly chapter: "经济";
}, {
    readonly subject: "行测-常识判断";
    readonly knowledgePoint: "科技";
    readonly id: "kg-point-065";
    readonly chapter: "科技";
}, {
    readonly subject: "行测-常识判断";
    readonly knowledgePoint: "人文历史";
    readonly id: "kg-point-066";
    readonly chapter: "人文历史";
}, {
    readonly subject: "行测-常识判断";
    readonly knowledgePoint: "管理公文";
    readonly id: "kg-point-067";
    readonly chapter: "管理公文";
}, {
    readonly subject: "申论";
    readonly knowledgePoint: "归纳概括题";
    readonly id: "kg-point-068";
    readonly chapter: "归纳概括题";
}, {
    readonly subject: "申论";
    readonly knowledgePoint: "综合分析题";
    readonly id: "kg-point-069";
    readonly chapter: "综合分析题";
}, {
    readonly subject: "申论";
    readonly knowledgePoint: "提出对策题";
    readonly id: "kg-point-070";
    readonly chapter: "提出对策题";
}, {
    readonly subject: "申论";
    readonly knowledgePoint: "贯彻执行题（公文写作）";
    readonly id: "kg-point-071";
    readonly chapter: "贯彻执行题（公文写作）";
}, {
    readonly subject: "申论";
    readonly knowledgePoint: "文章写作（大作文）";
    readonly id: "kg-point-072";
    readonly chapter: "文章写作（大作文）";
}, {
    readonly subject: "申论";
    readonly knowledgePoint: "材料理解";
    readonly id: "kg-point-073";
    readonly chapter: "材料理解";
}];
