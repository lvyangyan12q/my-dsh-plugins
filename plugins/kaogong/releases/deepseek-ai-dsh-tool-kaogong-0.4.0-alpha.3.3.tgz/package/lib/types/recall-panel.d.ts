export declare function RecallPanel({ pointId, onChanged }?: {
    pointId?: string;
    onChanged?(): void;
}): import("react/jsx-runtime").JSX.Element;
