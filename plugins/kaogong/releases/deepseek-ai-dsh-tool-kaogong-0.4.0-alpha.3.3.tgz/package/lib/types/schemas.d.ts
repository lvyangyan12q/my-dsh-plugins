/**
 * Pure zod record schemas for the kaogong domains. No DSH runtime deps —
 * only zod — so they can be unit-tested standalone. `domain.ts` derives the
 * storageDomain specs from these; the zod type is the single source of truth.
 * @module kaogong/schemas
 */
import { z } from 'zod';
/** One stored question record (the question id is the table key, not a field). */
export declare const questionRecord: z.ZodObject<{
    subject: z.ZodString;
    knowledgePoint: z.ZodString;
    questionType: z.ZodString;
    stem: z.ZodString;
    options: z.ZodArray<z.ZodString>;
    correctAnswer: z.ZodString;
    userAnswer: z.ZodString;
    result: z.ZodEnum<{
        correct: "correct";
        wrong: "wrong";
        skipped: "skipped";
    }>;
    errorReason: z.ZodString;
    notes: z.ZodString;
    source: z.ZodString;
    tags: z.ZodArray<z.ZodString>;
    createdAt: z.ZodString;
    updatedAt: z.ZodString;
    practiceRoundId: z.ZodOptional<z.ZodString>;
    practiceSequence: z.ZodOptional<z.ZodNumber>;
    practiceRevision: z.ZodOptional<z.ZodNumber>;
}, z.core.$strip>;
/** One stored question record, inferred from {@link questionRecord}. */
export type QuestionRecord = z.infer<typeof questionRecord>;
/** Plan configuration stored as the progress domain's global singleton. */
export declare const planConfig: z.ZodObject<{
    examDate: z.ZodString;
    dailyModules: z.ZodNumber;
    subjects: z.ZodArray<z.ZodObject<{
        name: z.ZodString;
        weight: z.ZodNumber;
    }, z.core.$strip>>;
}, z.core.$strip>;
/** One plan configuration, inferred from {@link planConfig}. */
export type PlanConfig = z.infer<typeof planConfig>;
/** One scheduled item on a day. */
export declare const dayItem: z.ZodObject<{
    subject: z.ZodString;
    kind: z.ZodEnum<{
        learn: "learn";
        review: "review";
        practice: "practice";
        mock: "mock";
    }>;
    title: z.ZodString;
    done: z.ZodBoolean;
}, z.core.$strip>;
/** One scheduled day. */
export declare const dayPlan: z.ZodObject<{
    date: z.ZodString;
    phase: z.ZodEnum<{
        foundation: "foundation";
        reinforce: "reinforce";
        sprint: "sprint";
    }>;
    items: z.ZodArray<z.ZodObject<{
        subject: z.ZodString;
        kind: z.ZodEnum<{
            learn: "learn";
            review: "review";
            practice: "practice";
            mock: "mock";
        }>;
        title: z.ZodString;
        done: z.ZodBoolean;
    }, z.core.$strip>>;
}, z.core.$strip>;
/** One scheduled day, inferred from {@link dayPlan}. */
export type DayPlanRecord = z.infer<typeof dayPlan>;
/** One stored bank question record (the id is the table key, not a field). */
export declare const bankQuestion: z.ZodObject<{
    subject: z.ZodString;
    knowledgePoint: z.ZodString;
    questionType: z.ZodString;
    stem: z.ZodString;
    options: z.ZodArray<z.ZodString>;
    correctAnswer: z.ZodString;
    explanation: z.ZodString;
    difficulty: z.ZodEnum<{
        easy: "easy";
        medium: "medium";
        hard: "hard";
    }>;
    source: z.ZodString;
    origin: z.ZodEnum<{
        web: "web";
        local: "local";
    }>;
    reviewStatus: z.ZodEnum<{
        pending: "pending";
        approved: "approved";
        rejected: "rejected";
    }>;
    reviewNotes: z.ZodString;
    tags: z.ZodArray<z.ZodString>;
    createdAt: z.ZodString;
    reviewedAt: z.ZodString;
}, z.core.$strip>;
/** One stored bank question record, inferred from {@link bankQuestion}. */
export type BankQuestionRecord = z.infer<typeof bankQuestion>;
/** One stored knowledge entry record (the id is the table key, not a field). */
export declare const knowledgeEntry: z.ZodObject<{
    subject: z.ZodString;
    knowledgePoint: z.ZodString;
    title: z.ZodString;
    content: z.ZodString;
    kind: z.ZodEnum<{
        讲义: "讲义";
        笔记: "笔记";
        时政: "时政";
        公式: "公式";
        技巧: "技巧";
        真题解析: "真题解析";
        其他: "其他";
    }>;
    source: z.ZodString;
    tags: z.ZodArray<z.ZodString>;
    createdAt: z.ZodString;
    updatedAt: z.ZodString;
}, z.core.$strip>;
/** One stored knowledge entry record, inferred from {@link knowledgeEntry}. */
export type KnowledgeEntryRecord = z.infer<typeof knowledgeEntry>;
/** Issued snapshots and immutable scores stay in one durable record. */
export declare const practiceRound: z.ZodObject<{
    version: z.ZodLiteral<1>;
    context: z.ZodObject<{
        subject: z.ZodString;
        title: z.ZodString;
        knowledgePointId: z.ZodOptional<z.ZodString>;
        knowledgePoint: z.ZodOptional<z.ZodString>;
        limit: z.ZodLiteral<10>;
        planIndex: z.ZodOptional<z.ZodNumber>;
        taskId: z.ZodOptional<z.ZodString>;
        planRevision: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strip>;
    questions: z.ZodArray<z.ZodObject<{
        subject: z.ZodString;
        knowledgePoint: z.ZodString;
        questionType: z.ZodString;
        stem: z.ZodString;
        options: z.ZodArray<z.ZodString>;
        correctAnswer: z.ZodString;
        explanation: z.ZodString;
        difficulty: z.ZodEnum<{
            easy: "easy";
            medium: "medium";
            hard: "hard";
        }>;
        source: z.ZodString;
        origin: z.ZodEnum<{
            web: "web";
            local: "local";
        }>;
        reviewStatus: z.ZodEnum<{
            pending: "pending";
            approved: "approved";
            rejected: "rejected";
        }>;
        reviewNotes: z.ZodString;
        tags: z.ZodArray<z.ZodString>;
        createdAt: z.ZodString;
        reviewedAt: z.ZodString;
        id: z.ZodString;
    }, z.core.$strip>>;
    seenIds: z.ZodArray<z.ZodString>;
    reason: z.ZodString;
    totalAvailable: z.ZodNumber;
    cycled: z.ZodBoolean;
    createdAt: z.ZodString;
    score: z.ZodOptional<z.ZodObject<{
        answers: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            answer: z.ZodString;
        }, z.core.$strip>>;
        sequence: z.ZodNumber;
        submittedAt: z.ZodString;
    }, z.core.$strip>>;
    reflections: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        errorReason: z.ZodString;
        notes: z.ZodOptional<z.ZodString>;
        savedAt: z.ZodOptional<z.ZodString>;
        notesRevision: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strip>>;
    revision: z.ZodNumber;
    projectedRevision: z.ZodNumber;
    changedAt: z.ZodString;
    review: z.ZodEnum<{
        ready: "ready";
        sending: "sending";
        sent: "sent";
    }>;
    reviewClaim: z.ZodOptional<z.ZodObject<{
        taskId: z.ZodString;
        requestId: z.ZodString;
    }, z.core.$strip>>;
}, z.core.$strip>;
/** Version-one durable round. */
export type PracticeRound = z.infer<typeof practiceRound>;
