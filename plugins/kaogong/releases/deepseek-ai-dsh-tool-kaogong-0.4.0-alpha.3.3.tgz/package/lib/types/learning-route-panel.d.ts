import type { ReactNode } from 'react';
export type RoutePoint = {
    id: string;
    subject: string;
    chapter: string;
    knowledgePoint: string;
    materials: {
        id: string;
        title: string;
    }[];
    status: string;
    taskId?: string;
    reviewDueAt?: string | null;
    recallPointId?: string | null;
    reviewOccurrenceIds?: string[];
};
export declare function LearningRoutePanel({ onChoose, onContinue, previewFor, preview }: {
    previewFor?: string | null;
    preview?: ReactNode;
    onChoose(point: RoutePoint): void;
    onContinue(id: string): void;
}): import("react/jsx-runtime").JSX.Element;
