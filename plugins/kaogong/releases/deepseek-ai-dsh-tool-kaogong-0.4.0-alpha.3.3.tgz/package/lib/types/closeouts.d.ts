import { z } from 'zod';
import type { KvTable } from '@deepseek-ai/dsh-storage-domain';
import type { KaogongInstanceState } from './instance-state.ts';
export declare const closeoutInput: z.ZodObject<{
    operationId: z.ZodString;
    lessonId: z.ZodString;
    notes: z.ZodString;
    confirmed: z.ZodLiteral<true>;
    joinRecall: z.ZodBoolean;
    roundId: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export declare const closeoutRecord: z.ZodObject<{
    input: z.ZodObject<{
        operationId: z.ZodString;
        lessonId: z.ZodString;
        notes: z.ZodString;
        confirmed: z.ZodLiteral<true>;
        joinRecall: z.ZodBoolean;
        roundId: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>;
    status: z.ZodEnum<{
        pending: "pending";
        complete: "complete";
    }>;
    lessonSaved: z.ZodBoolean;
    planSaved: z.ZodBoolean;
    recallSaved: z.ZodBoolean;
    error: z.ZodOptional<z.ZodString>;
    selectedRoundId: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
export type CloseoutRecord = z.infer<typeof closeoutRecord>;
type State = Omit<KaogongInstanceState, 'closeouts'>;
/** One owner serializes consent receipts; real domain effects remain independently durable. */
export declare class Closeouts {
    private table;
    private tail;
    constructor(table: KvTable<string, CloseoutRecord>);
    preview(state: State, lessonId: string): Promise<{
        candidates: {
            answered: number;
            unanswered: number;
            missingReflections: number;
            roundId: string;
            title: string;
            submittedAt: string;
        }[];
        operation: {
            input: {
                operationId: string;
                lessonId: string;
                notes: string;
                confirmed: true;
                joinRecall: boolean;
                roundId?: string | undefined;
            };
            status: "pending" | "complete";
            lessonSaved: boolean;
            planSaved: boolean;
            recallSaved: boolean;
            error?: string | undefined;
            selectedRoundId?: string | undefined;
        } | null;
        lesson: import("./lesson-schema.ts").Lesson;
        evidence: import("./lesson-schema.ts").LessonEvidence[];
        canConfirm: boolean;
        summary: string;
    }>;
    execute(state: State, raw: unknown): Promise<{
        operation: {
            input: {
                operationId: string;
                lessonId: string;
                notes: string;
                confirmed: true;
                joinRecall: boolean;
                roundId?: string | undefined;
            };
            status: "pending" | "complete";
            lessonSaved: boolean;
            planSaved: boolean;
            recallSaved: boolean;
            error?: string | undefined;
            selectedRoundId?: string | undefined;
        };
        lesson: import("./lesson-schema.ts").Lesson;
        evidence: import("./lesson-schema.ts").LessonEvidence[];
        canConfirm: boolean;
        summary: string;
    }>;
    close(): Promise<void>;
}
export {};
