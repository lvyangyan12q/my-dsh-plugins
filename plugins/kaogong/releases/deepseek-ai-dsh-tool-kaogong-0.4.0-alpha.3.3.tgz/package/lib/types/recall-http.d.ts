import type { BusinessRegistry } from './business.ts';
import type { KaogongInstanceState } from './instance-state.ts';
export declare function registerRecalls(registry: BusinessRegistry, state: KaogongInstanceState): () => void;
