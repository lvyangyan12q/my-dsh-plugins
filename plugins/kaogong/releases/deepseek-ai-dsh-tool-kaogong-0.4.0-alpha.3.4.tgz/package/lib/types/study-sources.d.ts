import type { StudyWorkspace } from './study-workspace.ts';
import type { StudySourceReader, StudySourceOwner, SourceRows } from './study-contracts.ts';
/** A fixed study source boundary: libraries can grant only bank/material reads.
 * Private teaching context is never catalogued or shared. */
export declare class StudySourceRevoked extends Error {
}
export declare class StudySources implements StudySourceReader {
    private workspace;
    private owners;
    private pending;
    constructor(workspace: StudyWorkspace);
    withGrantLease<T>(operation: () => Promise<T>): Promise<T>;
    register<T extends SourceRows>(owner: StudySourceOwner<T>): () => void;
    call<T extends SourceRows = SourceRows>(input: {
        viewId: string;
        resourceId: string;
        action: 'read';
    }): Promise<{
        value: T;
        connection: {
            [x: string]: unknown;
            id: string;
            ownerInstanceId: string;
            consumerInstanceId: string;
            resourceId: "materials" | "question-bank";
            status: "active" | "revoked";
            revision: number;
        } | null;
        committed: false;
    }>;
    share(input: {
        ownerViewId: string;
        consumerInstanceId: string;
        resourceId: string;
    }): Promise<{
        [x: string]: unknown;
        id: string;
        ownerInstanceId: string;
        consumerInstanceId: string;
        resourceId: "materials" | "question-bank";
        status: "active" | "revoked";
        revision: number;
    } | {
        id: `${string}-${string}-${string}-${string}-${string}`;
        ownerInstanceId: string;
        consumerInstanceId: string;
        resourceId: "question-bank" | "materials";
        status: "active";
        revision: number;
    }>;
    revoke(id: string, revision: number): Promise<{
        status: "revoked";
        revision: number;
        id: string;
        ownerInstanceId: string;
        consumerInstanceId: string;
        resourceId: "materials" | "question-bank";
    }>;
    capture(viewId: string, references: {
        resourceId: string;
        selection?: unknown;
    }[]): Promise<{
        reference: {
            resourceId: string;
            selection?: unknown;
        };
        fingerprint: string;
        title: string;
        text: string;
        id: `${string}-${string}-${string}-${string}-${string}`;
    }[]>;
}
