import type { KvTable } from '@deepseek-ai/dsh-storage-domain';
import type { BankQuestion } from './types.ts';
import type { BankQuestionRecord, QuestionRecord, PracticeRound } from './schemas.ts';
export declare class PracticeError extends Error {
    readonly status: number;
    constructor(message: string, status?: number);
}
/** Fail closed on answer-key material rather than editing the original bank text. */
export declare function safePracticeQuestion(question: BankQuestion, verifiedFigure?: boolean): boolean;
/** One application command queue, drained before domains close. No cross-domain transaction is assumed. */
export declare class PracticeRounds {
    private rounds;
    private bank;
    private notebook;
    private materialStem;
    private materialOptions;
    private assertRoundAccess;
    private tail;
    private closing;
    constructor(rounds: KvTable<string, PracticeRound>, bank: KvTable<string, BankQuestionRecord>, notebook: KvTable<string, QuestionRecord>, materialStem?: (id: string, stem: string) => string, materialOptions?: (id: string, stem: string, options: string[]) => string[], assertRoundAccess?: (id: string) => void);
    private displayQuestion;
    private drawable;
    drain(): Promise<unknown>;
    /** Reject new commands, then drain the existing queue before its domains close. */
    close(): Promise<unknown>;
    notebookCommand<T>(command: () => Promise<T>): Promise<T>;
    private run;
    private round;
    /** Host-issued task identity makes a lost start response safe to retry. */
    startForTask(context: PracticeRound['context'] & {
        planRevision?: number;
    }, taskId: string): Promise<{
        roundId: string;
        context: {
            subject: string;
            title: string;
            limit: 10;
            knowledgePointId?: string | undefined;
            knowledgePoint?: string | undefined;
            planIndex?: number | undefined;
            taskId?: string | undefined;
            planRevision?: number | undefined;
        };
        reason: string;
        totalAvailable: number;
        returned: number;
        cycled: boolean;
        questions: {
            id: string;
            subject: string;
            knowledgePoint: string;
            stem: string;
            options: string[];
            difficulty: "easy" | "medium" | "hard";
            source: string;
        }[];
        result: {
            roundId: string;
            totalCount: number;
            submittedCount: number;
            answeredCount: number;
            unansweredCount: number;
            incorrectCount: number;
            uniqueQuestionCount: number;
            correctCount: number;
            accuracyRate: number;
            results: {
                id: string;
                subject: string;
                knowledgePoint: string;
                stem: string;
                options: string[];
                source: string;
                userAnswer: string;
                correct: boolean;
                correctAnswer: string;
                explanation: string;
            }[];
            projection: "pending" | "complete";
            review: "ready" | "sending" | "sent";
        } | null;
        reflections: {
            id: string;
            errorReason: string;
            notes?: string | undefined;
            savedAt?: string | undefined;
            notesRevision?: number | undefined;
        }[];
    }>;
    /** Issue ten distinct questions, filling the end of a cycle before repeating seen questions. */
    start(context: PracticeRound['context'], previousRoundId?: string, weak?: boolean, difficulty?: 'easy' | 'medium' | 'hard'): Promise<{
        roundId: string;
        context: {
            subject: string;
            title: string;
            limit: 10;
            knowledgePointId?: string | undefined;
            knowledgePoint?: string | undefined;
            planIndex?: number | undefined;
            taskId?: string | undefined;
            planRevision?: number | undefined;
        };
        reason: string;
        totalAvailable: number;
        returned: number;
        cycled: boolean;
        questions: {
            id: string;
            subject: string;
            knowledgePoint: string;
            stem: string;
            options: string[];
            difficulty: "easy" | "medium" | "hard";
            source: string;
        }[];
        result: {
            roundId: string;
            totalCount: number;
            submittedCount: number;
            answeredCount: number;
            unansweredCount: number;
            incorrectCount: number;
            uniqueQuestionCount: number;
            correctCount: number;
            accuracyRate: number;
            results: {
                id: string;
                subject: string;
                knowledgePoint: string;
                stem: string;
                options: string[];
                source: string;
                userAnswer: string;
                correct: boolean;
                correctAnswer: string;
                explanation: string;
            }[];
            projection: "pending" | "complete";
            review: "ready" | "sending" | "sent";
        } | null;
        reflections: {
            id: string;
            errorReason: string;
            notes?: string | undefined;
            savedAt?: string | undefined;
            notesRevision?: number | undefined;
        }[];
    }>;
    private result;
    private view;
    /** Only the stored snapshot is scored; all membership checks precede the first write. */
    submit(id: string, answers: {
        id: string;
        answer: string;
    }[]): Promise<{
        roundId: string;
        totalCount: number;
        submittedCount: number;
        answeredCount: number;
        unansweredCount: number;
        incorrectCount: number;
        uniqueQuestionCount: number;
        correctCount: number;
        accuracyRate: number;
        results: {
            id: string;
            subject: string;
            knowledgePoint: string;
            stem: string;
            options: string[];
            source: string;
            userAnswer: string;
            correct: boolean;
            correctAnswer: string;
            explanation: string;
        }[];
        projection: "pending" | "complete";
        review: "ready" | "sending" | "sent";
    }>;
    /** Replaying a projection cannot erase another attempt or later manual reflections. */
    private project;
    read(id: string): Promise<{
        roundId: string;
        context: {
            subject: string;
            title: string;
            limit: 10;
            knowledgePointId?: string | undefined;
            knowledgePoint?: string | undefined;
            planIndex?: number | undefined;
            taskId?: string | undefined;
            planRevision?: number | undefined;
        };
        reason: string;
        totalAvailable: number;
        returned: number;
        cycled: boolean;
        questions: {
            id: string;
            subject: string;
            knowledgePoint: string;
            stem: string;
            options: string[];
            difficulty: "easy" | "medium" | "hard";
            source: string;
        }[];
        result: {
            roundId: string;
            totalCount: number;
            submittedCount: number;
            answeredCount: number;
            unansweredCount: number;
            incorrectCount: number;
            uniqueQuestionCount: number;
            correctCount: number;
            accuracyRate: number;
            results: {
                id: string;
                subject: string;
                knowledgePoint: string;
                stem: string;
                options: string[];
                source: string;
                userAnswer: string;
                correct: boolean;
                correctAnswer: string;
                explanation: string;
            }[];
            projection: "pending" | "complete";
            review: "ready" | "sending" | "sent";
        } | null;
        reflections: {
            id: string;
            errorReason: string;
            notes?: string | undefined;
            savedAt?: string | undefined;
            notesRevision?: number | undefined;
        }[];
    }>;
    /** Read completed score snapshots without projecting notebook writes or mutating any domain. */
    readCompleted(id?: string, subject?: string): Promise<{
        submittedAt: string;
        round: {
            roundId: string;
            context: {
                subject: string;
                title: string;
                limit: 10;
                knowledgePointId?: string | undefined;
                knowledgePoint?: string | undefined;
                planIndex?: number | undefined;
                taskId?: string | undefined;
                planRevision?: number | undefined;
            };
            reason: string;
            totalAvailable: number;
            returned: number;
            cycled: boolean;
            questions: {
                id: string;
                subject: string;
                knowledgePoint: string;
                stem: string;
                options: string[];
                difficulty: "easy" | "medium" | "hard";
                source: string;
            }[];
            result: {
                roundId: string;
                totalCount: number;
                submittedCount: number;
                answeredCount: number;
                unansweredCount: number;
                incorrectCount: number;
                uniqueQuestionCount: number;
                correctCount: number;
                accuracyRate: number;
                results: {
                    id: string;
                    subject: string;
                    knowledgePoint: string;
                    stem: string;
                    options: string[];
                    source: string;
                    userAnswer: string;
                    correct: boolean;
                    correctAnswer: string;
                    explanation: string;
                }[];
                projection: "pending" | "complete";
                review: "ready" | "sending" | "sent";
            } | null;
            reflections: {
                id: string;
                errorReason: string;
                notes?: string | undefined;
                savedAt?: string | undefined;
                notesRevision?: number | undefined;
            }[];
        };
    } | null>;
    /** Uncapped, read-only scored ledger; never derive grades from notebook projections. */
    statistics(subject?: string): {
        denominator: "submitted-question-slots";
        bySubject: {
            submittedRoundCount: number;
            submittedCount: number;
            answeredCount: number;
            unansweredCount: number;
            uniqueQuestionCount: number;
            correctCount: number;
            incorrectCount: number;
            accuracyRate: number;
            subject: string;
        }[];
        byKnowledgePoint: import("./analyze.ts").KnowledgePointStat[];
        errorReasons: import("./analyze.ts").ErrorReasonStat[];
        submittedRoundCount: number;
        submittedCount: number;
        answeredCount: number;
        unansweredCount: number;
        uniqueQuestionCount: number;
        correctCount: number;
        incorrectCount: number;
        accuracyRate: number;
    };
    summary(subject: string, topN: number): {
        accuracyRate: number;
        narrative: string;
        submittedRoundCount: number;
        submittedCount: number;
        answeredCount: number;
        unansweredCount: number;
        uniqueQuestionCount: number;
        correctCount: number;
        incorrectCount: number;
        totalQuestions: number;
        totalCorrect: number;
        totalWrong: number;
        totalSkipped: number;
        weakPoints: import("./analyze.ts").WeakPoint[];
        errorReasonBreakdown: import("./analyze.ts").ErrorReasonStat[];
        suggestions: string[];
    };
    /** History lists issued IDs without exposing open-round answers. */
    history(): {
        roundId: string;
        context: {
            subject: string;
            title: string;
            limit: 10;
            knowledgePointId?: string | undefined;
            knowledgePoint?: string | undefined;
            planIndex?: number | undefined;
            taskId?: string | undefined;
            planRevision?: number | undefined;
        };
        createdAt: string;
        submitted: boolean;
    }[];
    recover(): Promise<void>;
    reflect(id: string, entries: {
        id: string;
        errorReason: string;
        notes?: string;
    }[]): Promise<{
        roundId: string;
        totalCount: number;
        submittedCount: number;
        answeredCount: number;
        unansweredCount: number;
        incorrectCount: number;
        uniqueQuestionCount: number;
        correctCount: number;
        accuracyRate: number;
        results: {
            id: string;
            subject: string;
            knowledgePoint: string;
            stem: string;
            options: string[];
            source: string;
            userAnswer: string;
            correct: boolean;
            correctAnswer: string;
            explanation: string;
        }[];
        projection: "pending" | "complete";
        review: "ready" | "sending" | "sent";
    }>;
    /** Reserve an explicit native handoff; uncertain delivery stays sending across restart. */
    review(id: string, action: 'claim' | 'complete' | 'release', claim?: {
        taskId: string;
        requestId: string;
    }): Promise<{
        roundId: string;
        context: {
            subject: string;
            title: string;
            limit: 10;
            knowledgePointId?: string | undefined;
            knowledgePoint?: string | undefined;
            planIndex?: number | undefined;
            taskId?: string | undefined;
            planRevision?: number | undefined;
        };
        reason: string;
        totalAvailable: number;
        returned: number;
        cycled: boolean;
        questions: {
            id: string;
            subject: string;
            knowledgePoint: string;
            stem: string;
            options: string[];
            difficulty: "easy" | "medium" | "hard";
            source: string;
        }[];
        result: {
            roundId: string;
            totalCount: number;
            submittedCount: number;
            answeredCount: number;
            unansweredCount: number;
            incorrectCount: number;
            uniqueQuestionCount: number;
            correctCount: number;
            accuracyRate: number;
            results: {
                id: string;
                subject: string;
                knowledgePoint: string;
                stem: string;
                options: string[];
                source: string;
                userAnswer: string;
                correct: boolean;
                correctAnswer: string;
                explanation: string;
            }[];
            projection: "pending" | "complete";
            review: "ready" | "sending" | "sent";
        } | null;
        reflections: {
            id: string;
            errorReason: string;
            notes?: string | undefined;
            savedAt?: string | undefined;
            notesRevision?: number | undefined;
        }[];
    }>;
}
