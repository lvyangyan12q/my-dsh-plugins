import type { KaogongTeachingRequest } from './kaogong-view.tsx';
import type { Entry } from './knowledge-reader.tsx';
import type { StudyViewProps } from './study-client-contracts.ts';
import type { LearningRoleKey } from './client-runtime.ts';
export declare const learningPages: {
    id: string;
    title: string;
}[];
/** Prepare evidence before navigation unmounts main. Only the later send gesture admits a Native prompt. */
export declare function prepareLearningTask(services: {
    roles: StudyViewProps['roles'];
    tasks: StudyViewProps['tasks'];
    instanceId: string;
}, request: KaogongTeachingRequest, material: Entry | null, isCurrent?: () => boolean, onOpened?: (key: LearningRoleKey) => void): Promise<import("./study-client-contracts.ts").StudyTask>;
/** Learning content only; Native owns the Conversation and its composer. */
export declare function SdkClassroom(props: StudyViewProps): import("react/jsx-runtime").JSX.Element;
export declare const sdkLearningStyles = "\n.kg-study-dashboard{height:100%;min-height:0;display:flex;flex-direction:column;overflow:hidden}\n.kg-study-dashboard>.kg-sdk-classroom{flex:1;min-height:0;height:auto}\n.kg-sdk-classroom{display:flex;flex-direction:column;min-width:0;min-height:0;height:100%;color:inherit;font:inherit;background:var(--dsh-background,#f8f8f5)}\n.kg-sdk-classroom>header,.kg-sdk-classroom>nav{display:flex;flex-wrap:wrap;align-items:center;gap:8px;padding:10px 14px;border-bottom:1px solid #dfe3dd}.kg-sdk-classroom small{font-size:12px;color:#667062}.kg-sdk-content{min-height:0;min-width:0;flex:1;overflow:auto}.kg-overview,.kg-sdk-content>section[aria-label=\"\u5F85\u53D1\u9001\u6559\u5B66\u4EFB\u52A1\"]{padding:18px 22px}\n.kg-sdk-classroom button{min-height:34px;padding:6px 10px;border:1px solid #cad2c7;border-radius:6px;background:#fff;color:#283b2a;font:inherit;cursor:pointer}.kg-sdk-classroom button[aria-pressed=true]{background:#2f6248;color:#fff;border-color:#2f6248}.kg-sdk-classroom button:disabled{opacity:.5;cursor:not-allowed}.kg-sdk-classroom :is(button,input,select,textarea):focus-visible{outline:2px solid #2f6248;outline-offset:2px}\n.kg-sdk-classroom :is(input:not([type=checkbox]):not([type=radio]),select,textarea){max-width:100%;min-width:0;box-sizing:border-box;border:1px solid #cbd2c7;border-radius:6px;background:#fff;color:inherit;font:inherit;padding:7px}.kg-sdk-classroom label{display:inline-flex;align-items:center;gap:6px;flex-wrap:wrap}.kg-sdk-classroom>p[role=alert]{color:#b42318;padding:0 14px}.kg-metrics,.kg-actions{display:flex;gap:12px;flex-wrap:wrap}.kg-metrics p{min-width:120px;padding:14px;border:1px solid #dfe3dd;background:#fff;border-radius:8px}.kg-metrics strong{display:block;font-size:24px}.kg-task-draft{margin:12px 0;padding:14px;border:1px solid #dfe3dd;background:#fff;border-radius:8px}.kg-task-draft label{display:block;margin:10px 0}.kg-task-draft textarea{display:block;width:100%;min-height:95px}\n";
