import type { StudyTask } from './study-plan.ts';
/** Local recency hint only; the Host remains the owner of task and classroom records. */
export declare function recentTaskKey(instanceId: string): string;
export declare function readRecentTaskIds(instanceId: string): string[];
export declare function rememberRecentTask(instanceId: string, taskId: string): void;
/** A classroom belongs to a started learning task; practice and review tasks restore their own content. */
export declare function pickCurrentLearningTask(tasks: readonly StudyTask[], recentIds: readonly string[]): StudyTask | undefined;
/** The exact identity the Host uses to return the same classroom on a retry. */
export declare function taskStartRevision(task: StudyTask, planRevision: number): number;
