export declare function MaterialPointPanel(): import("react").JSX.Element;
