type Props = {
    onReview?: (target: {
        pointId?: string;
        occurrenceId?: string;
    }) => void;
};
export declare function LearningProgressPanel(props: Props): import("react").JSX.Element;
export {};
