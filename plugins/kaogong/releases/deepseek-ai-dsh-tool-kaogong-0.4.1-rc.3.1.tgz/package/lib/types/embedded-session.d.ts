import type { ISessions } from '@deepseek-ai/dsh-api-session-controller/client';
import type { PropsRenderFactories, PropsRenderSlots, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { ConversationViewsProps } from '@deepseek-ai/dsh-client-ui-conversation/client';
declare module '@deepseek-ai/dsh-api-session-controller/client' {
    interface SessionReferenceSourceMap {
        /** 考公课堂的答疑区，与原生主视图、右侧栏都相互独立地持有一个引用。 */
        kaogongClassroom: unknown;
    }
}
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface SlotMap {
        /** 根作用域里的一个真实老师会话；自己建立会话作用域，因此课堂外壳不需要会话绑定。 */
        'kaogong.teacher.session': {
            kind: 'single';
            scope: 'root';
            owner: {
                sessionId: string;
            };
        };
        /** 会话作用域内的原生对话内容；只在本 slot 渲染，课堂之外不会出现第二个输入框。 */
        'kaogong.teacher.body': {
            kind: 'single';
            scope: 'session';
        };
    }
}
/** 会话引用来源标签；退出课堂时按引用计数释放，不改变导航。 */
export declare const teacherSessionSource = "kaogongClassroom";
export type TeacherSessionHostProps = PropsRuntime<'kaogong.teacher.session'> & PropsRenderSlots<'kaogong.teacher.body'> & {
    /** 公开会话保留能力（`ctx.sessions` 的 retain 面）。 */
    sessions: Pick<ISessions, 'retain'>;
};
/** 保留指定原生会话并把它包进公开会话作用域；任何失败都如实显示，不伪造对话。 */
export declare function TeacherSessionHost({ sessionId, sessions, SessionProvider, renderSlot }: TeacherSessionHostProps): import("react").JSX.Element;
export type TeacherSessionBodyProps = PropsRuntime<'kaogong.teacher.body'> & PropsRenderFactories;
/** 原生 Conversation Factory 的嵌入式出现：内容、流式、工具、审批、提问、Stop 与输入都归原生所有。 */
export declare function TeacherSessionBody({ renderFactorySlot }: TeacherSessionBodyProps): import("react").JSX.Element;
/** 固定原生 chat 视图，其它原生视图不进入课堂（完整对话仍由显式入口打开）。 */
export declare function FixedChatConversationView({ renderSlot }: ConversationViewsProps): import("react").JSX.Element;
