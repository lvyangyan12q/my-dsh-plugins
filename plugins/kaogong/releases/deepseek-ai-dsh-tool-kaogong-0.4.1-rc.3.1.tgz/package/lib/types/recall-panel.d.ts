export declare function RecallPanel({ pointId, onChanged }?: {
    pointId?: string;
    onChanged?(): void;
}): import("react").JSX.Element;
