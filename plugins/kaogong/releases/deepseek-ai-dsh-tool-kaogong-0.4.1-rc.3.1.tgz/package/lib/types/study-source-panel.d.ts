export declare function SourceConnections({ viewId }: {
    viewId: string;
}): import("react").JSX.Element;
