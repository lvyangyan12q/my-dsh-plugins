import type { Handout } from './lesson-handout.tsx';
import type { QuizQuestion } from './lesson-quiz.tsx';
/** 一课的全部内容：讲义、检测与来源说明。渲染器只消费它，不认具体是哪一课。 */
export type LessonContent = {
    id: string;
    /** 一段课堂文字（学习目标或限定考点）是否属于这一课。 */
    match: (text: string) => boolean;
    handout: Handout;
    quiz: readonly QuizQuestion[];
    /** 这套检测是自编还是真题：随内容走，不冒充真题。 */
    quizProvenance: string;
};
/** 内容注册表：加一课只在这里加一项，面板与渲染器不动。顺序即匹配优先级。 */
export declare const LESSON_CONTENTS: readonly LessonContent[];
/** 本课目标或限定考点命中哪一课；都不命中就是没有讲义、也没有检测。 */
export declare function resolveLessonContent(request: {
    knowledgePoint?: string;
    objective?: string;
} | null | undefined): LessonContent | null;
