/**
 * 讲义与检测题共用的可复算数据。
 *
 * 内容里手写的题干、选项和解析容易和算术脱节；这里把「按什么加权、排除了哪些选项」
 * 变成数据，由纯函数核对，测试就能断言不变量而不是某句文案。
 */
export type MixedPart = {
    base: number;
    rate: number;
};
export type IntervalCheck = {
    kind: 'interval';
    /** 各部分的基期量与增长率；整体增长率按基期量加权。 */
    parts: readonly MixedPart[];
    /** 用区间理由排除的选项下标：必须严格落在两个部分率之外。 */
    cut: readonly number[];
    /** 答案是否为区间内唯一选项（只靠区间就能定案）。 */
    uniqueInside?: boolean;
};
export type CrossCheck = {
    kind: 'cross';
    /** 两部分增长率与整体增长率。 */
    aRate: number;
    bRate: number;
    overallRate: number;
    /** 两部分基期量之比 A∶B；必须与十字交叉结果一致。 */
    ratio: number;
};
export type AnswerCheck = IntervalCheck | CrossCheck;
/** 基期量加权平均。 */
export declare function mixedRate(parts: readonly MixedPart[]): number;
/** 已知现期量与增长率时，先还原基期量再加权：现期比例不能直接当权重。 */
export declare function mixedRateFromCurrent(parts: readonly {
    current: number;
    rate: number;
}[]): number;
/** 十字交叉：两部分基期量之比 A∶B = |b − r| ∶ |r − a|。 */
export declare function crossRatio(aRate: number, bRate: number, overallRate: number): number;
/** 增长量 = 现期量 × 增长率 ÷ (1 + 增长率)。 */
export declare function growthAmount(current: number, rate: number): number;
/** 严格读取百分数选项；格式不对就抛错，避免静默按 0 处理。 */
export declare function optionPercent(option: string): number;
/** 严格读取 a∶b 形式的比例选项。 */
export declare function optionRatio(option: string): number;
/** 核对答案下标、选项集合与排除理由；返回空数组表示这题可复算。 */
export declare function auditAnswer(options: readonly string[], answer: number, check: AnswerCheck): string[];
