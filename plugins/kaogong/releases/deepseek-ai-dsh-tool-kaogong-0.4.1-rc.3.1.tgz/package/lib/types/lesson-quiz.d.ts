/** 当堂检测的题目数据：判分与解析都在客户端完成，不写错题本、不计入正确率。 */
export type QuizQuestion = {
    id: string;
    prompt: string;
    options: readonly string[];
    /** 正确选项下标。 */
    answer: number;
    /** 解析：说明错在哪一步，而不只是答案。 */
    why: string;
    /** 目标小节锚点：答错时「回对应小节」落到讲义的那一节。 */
    anchorId: string;
};
export type QuizAnswer = number | null;
export type QuizItemGrade = {
    id: string;
    chosen: QuizAnswer;
    answer: number;
    correct: boolean;
    explanation: string;
    anchorId: string;
};
export type QuizGrade = {
    total: number;
    answered: number;
    correct: number;
    allAnswered: boolean;
    items: QuizItemGrade[];
    /** 已作答且答错的题：错题计数只从这里取，避免各处再按不同条件过滤。 */
    wrongItems: QuizItemGrade[];
    /** 全部答完时的一句话小结；未答完为空。 */
    summary: string;
};
export type QuizAdvice = {
    kind: 'practice';
    text: string;
    action: string;
} | {
    kind: 'jump';
    text: string;
    action: string;
    anchorId: string;
};
/** 清空一组题的作答：初始渲染、重做检测、换课都走这里，避免三处各写一遍。 */
export declare function emptyQuizAnswers(questions: readonly QuizQuestion[]): QuizAnswer[];
/** 纯判分：给题与选择，逐题返回对错与解析，并给出计数与（答完后的）小结。 */
export declare function gradeQuiz(questions: readonly QuizQuestion[], answers: readonly QuizAnswer[]): QuizGrade;
/** 答完后的下一步建议：全对去专项；只错一题回错的那一节；其余先重读快速思路。 */
export declare function quizAdvice(grade: QuizGrade): QuizAdvice | null;
/** 与 MIXED_GROWTH_HANDOUT 同一口径：自编、非真题。 */
export declare const MIXED_GROWTH_QUIZ_PROVENANCE = "\u81EA\u7F16\u68C0\u6D4B\u9898\uFF1A\u6559\u5B66\u8BBE\u8BA1\u7528\uFF0C\u975E\u771F\u9898\uFF1B\u771F\u9898\u5728\u7EC3\u4E60\u8F6E\u6B21\u91CC\u3002";
export declare const MIXED_GROWTH_QUIZ: readonly QuizQuestion[];
/** 与 GROWTH_COMPARISON_HANDOUT 同一口径：自编、非真题。 */
export declare const GROWTH_COMPARISON_QUIZ_PROVENANCE = "\u81EA\u7F16\u68C0\u6D4B\u9898\uFF1A\u6559\u5B66\u8BBE\u8BA1\u7528\uFF0C\u975E\u771F\u9898\uFF1B\u771F\u9898\u5728\u7EC3\u4E60\u8F6E\u6B21\u91CC\u3002";
/** 第 2 课的检测题：锚点指向第 2 课的讲义小节，回跳机制与第 1 课一致。 */
export declare const GROWTH_COMPARISON_QUIZ: readonly QuizQuestion[];
/** 当堂检测页：3 道选择题，选完立即判分并锁定该题；答错可回跳，答完给小结与下一步。作答由课堂面板持有，切页签不丢。 */
export declare function QuizPanel({ questions, answers, onAnswer, onJump, onPractice, onExplain, provenance }: {
    questions?: readonly QuizQuestion[];
    /** 已作答：`null` 表示未答，作答后不可改选。 */
    answers: readonly QuizAnswer[];
    /** 记录一题的作答；已答的题由课堂面板忽略重复点击。 */
    onAnswer: (index: number, option: number) => void;
    /** 回跳：由课堂面板切到讲义页签、滚动并高亮目标小节。 */
    onJump?: (anchorId: string) => void;
    /** 全对后的专项练习入口：由课堂面板透传。 */
    onPractice?: () => void;
    /** 答错后针对该步请老师补讲：复用本任务的课堂答疑与任务会话。 */
    onExplain?: (question: QuizQuestion, chosen: number) => void;
    /** 这套题是自编还是真题：由课堂面板随题给，不冒充真题。 */
    provenance?: string;
}): import("react").JSX.Element;
