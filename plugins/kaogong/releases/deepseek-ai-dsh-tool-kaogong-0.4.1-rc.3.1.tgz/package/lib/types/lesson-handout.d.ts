import type { AnswerCheck } from './lesson-content-check.ts';
/** 讲义是数据：渲染器只认结构，不认某一课的文字。 */
export type HandoutStep = {
    label: string;
    text: string;
};
export type LabValues = {
    aBase: number;
    bBase: number;
    aRate: number;
    bRate: number;
};
export type LabPreset = LabValues & {
    label: string;
};
/** 实验台同样只认结构：两部分的名字、取值范围、初值与预设都由数据给。 */
export type LabBlock = {
    kind: 'lab';
    title: string;
    hint: string;
    labels: {
        a: string;
        b: string;
    };
    baseLimit: {
        min: number;
        max: number;
        step: number;
    };
    rateLimit: {
        min: number;
        max: number;
        step: number;
    };
    initial: LabValues;
    presets: LabPreset[];
};
/**
 * 例题：`effort` 只写相对步骤量，不写虚构秒数；`check` 把加权依据与排除项交给测试复算。
 */
export type ExampleBlock = {
    kind: 'example';
    no: string;
    tag: string;
    effort: string;
    question: string;
    options: string[];
    answer: number;
    steps: HandoutStep[];
    check: AnswerCheck;
    slow?: string;
};
export type HandoutBlock = {
    kind: 'p';
    text: string;
} | {
    kind: 'bullets';
    items: string[];
} | {
    kind: 'formula';
    text: string;
} | {
    kind: 'callout';
    label: string;
    text: string;
} | LabBlock | ExampleBlock;
/** 小节编号可为空：独立小节（如「动手试一试」）不编号，渲染成「＋ 标题」。 */
export type HandoutSection = {
    id: string;
    no?: string;
    title: string;
    blocks: HandoutBlock[];
};
export type Handout = {
    id: string;
    subject: string;
    title: string;
    goal: string;
    /** 内容来源说明：自编还是真题。自编必须写明，不冒充真题。 */
    provenance: string;
    sections: HandoutSection[];
};
export type LabCalculation = {
    /** 以基期量为权重算出的整体增长率。 */
    overallRate: number;
    /** 若错把现期量当权重，会算出的整体增长率。 */
    currentWeightRate: number;
    /** 现期权重结果 − 基期权重结果（百分点）。 */
    weightGap: number;
    lower: number;
    upper: number;
    lean: 'a' | 'b' | 'equal' | 'same-rate';
    distanceToA: number;
    distanceToB: number;
};
/** 纯计算：整体增长率、偏向判定、现期权重对照。 */
export declare function labCalculation(values: LabValues): LabCalculation;
/** 例题审计：除选项与排除项外，再核对题干确实写明了 check 里用的数字。 */
export declare function auditExample(example: ExampleBlock): string[];
export declare const MIXED_GROWTH_HANDOUT: Handout;
/** 第 2 课：同样只提供数据；渲染、目录、回跳都用上面那套结构。 */
export declare const GROWTH_COMPARISON_HANDOUT: Handout;
export declare function HandoutView({ handout }: {
    handout: Handout;
}): import("react").JSX.Element;
