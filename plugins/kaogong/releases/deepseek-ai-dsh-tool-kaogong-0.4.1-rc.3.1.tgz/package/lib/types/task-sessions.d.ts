import type { StudyWorkspace } from './study-workspace.ts';
/** One active learning task and the classroom that represents it. */
export type ClassroomTask = {
    taskId: string;
    lessonId: string;
    subject: string;
    roleId: string;
};
export type TaskSession = {
    taskId: string;
    lessonId: string;
    roleId: string;
    sessionId: string;
    revision: number;
};
/** Host-owned task/lesson facts; this owner never guesses from the current global Session. */
export interface ClassroomTaskDirectory {
    task(instanceId: string, taskId: string): Promise<ClassroomTask | null>;
    /** Null for a legacy/manual classroom that has no task identity. */
    lesson(instanceId: string, lessonId: string): Promise<ClassroomTask | null>;
}
/** Native Session creation stays with {@link StudyRoles}; this owner decides which task may use it. */
export interface TaskSessionRoleOwner {
    ensureTask(input: {
        instanceId: string;
        roleId: string;
        taskId: string;
        lessonId: string;
        viewId?: string;
    }): Promise<{
        sessionId: string;
        revision: number;
    }>;
    openTask(input: {
        instanceId: string;
        roleId: string;
        taskId: string;
        lessonId: string;
        sessionId: string;
        revision: number;
    }): Promise<{
        sessionId: string;
    }>;
}
/**
 * A study task owns one native teacher Session. The binding is durable (role
 * bindings table, `kind:'task'`, keyed by instance+role+task), so refreshes,
 * two open views or a retried entry resolve the same Session instead of
 * falling back to the role-level one. Legacy classrooms without a task return
 * null and the caller keeps the previous role-session behavior.
 */
export declare class StudyTaskSessions {
    private workspace;
    private roles;
    private directory;
    constructor(workspace: StudyWorkspace, roles: TaskSessionRoleOwner, directory: ClassroomTaskDirectory);
    private learnerView;
    ensure(viewId: string, taskId: string): Promise<TaskSession>;
    /** Task-level Session for teaching prepared from a saved classroom, or null for a legacy classroom. */
    forLesson(viewId: string, lessonId: string, roleId: string): Promise<TaskSession | null>;
    open(instanceId: string, roleId: string, session: TaskSession): Promise<{
        sessionId: string;
    }>;
}
