import type { KaogongViewProps } from './kaogong-view.tsx';
import type { LessonView } from './lesson-schema.ts';
/** One closeout for the whole lesson: the learner writes the summary and confirms in the same place. */
export declare function LessonCloseout({ view, notes, onNotesChange, accept, onReturnToday, onOpenTeacher, onOpenPractice, onPractice }: {
    view: LessonView;
    notes: string;
    onNotesChange(value: string): void;
    accept(value: LessonView): void;
    onReturnToday?: () => void;
    onOpenTeacher: KaogongViewProps['onOpenTeacher'];
    onOpenPractice?: () => void;
    onPractice?: () => void;
}): import("react").JSX.Element;
