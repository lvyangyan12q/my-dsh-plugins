import type { QuizAnswer, QuizQuestion } from './lesson-quiz.tsx';
import type { LessonView } from './lesson-schema.ts';
import type { KaogongViewProps, PracticeContext } from './kaogong-view.tsx';
/** Only Host responses supply lesson state; browser draft fields never supply scores. */
export declare function lessonRequest<T>(action: string, body: unknown, send?: (input: string, init?: RequestInit) => Promise<Response>): Promise<T>;
/** Restore saved in-class answers by stable question ID; a record without quiz stays all-unanswered. */
export declare function lessonQuizAnswers(value: LessonView | null, questions: readonly QuizQuestion[]): QuizAnswer[];
/** Shared instance-owned lesson UI; practice starts through the existing request/draft owner. */
export declare function LessonPanel({ active, onPractice, onOpenTeacher, onClassroomTask, onReturnToday, onOpenPractice, taskCentered }: {
    onReturnToday?: () => void;
    active: boolean;
    onPractice: (context: PracticeContext) => Promise<void>;
    onOpenTeacher: KaogongViewProps['onOpenTeacher'];
    onClassroomTask?: KaogongViewProps['onClassroomTask'];
    onOpenPractice?: () => void;
    taskCentered?: boolean;
}): import("react").JSX.Element;
