type Target = {
    pointId?: string;
    occurrenceId?: string;
};
export declare function TodayReviewSummary({ onOpen }: {
    onOpen: (target?: Target) => void;
}): import("react").JSX.Element;
export {};
