export declare function CurrentStudyPanel({ onApplied }: {
    onApplied(): Promise<void>;
}): import("react").JSX.Element;
