import type { Context } from '@deepseek-ai/cordis';
import type { StudyWorkspace } from './study-workspace.ts';
type RoleBinding = {
    instanceId: string;
    roleId: string;
    sessionId: string;
    presetId: string;
    phase: 'intent' | 'ready';
    revision: number;
    creation: {
        cwd: string;
    };
    previousSessionIds: string[];
    creationAttempt?: string; /** A task classroom owns its own native Session; a role binding has no taskId. */
    kind?: 'task';
    taskId?: string;
    lessonId?: string;
    viewId?: string;
    [key: string]: unknown;
};
/** Owns only Kaogong standard Native Sessions. A durable intent precedes creation;
 * uncertain results never create a replacement identity or resend a prompt. */
export declare class StudyRoles {
    private ctx;
    private workspace;
    private cwd?;
    private owner?;
    private operations;
    private catalogOperations;
    private live;
    private removers;
    private stopped;
    constructor(ctx: Context, workspace: StudyWorkspace, cwd?: string | undefined);
    install(): Promise<() => Promise<void>>;
    private rows;
    /** Role-level reads ignore task classrooms: one role may own many task Sessions. */
    private roleRows;
    private profile;
    private definition;
    private registered;
    private catalog;
    private serial;
    private validateSkill;
    private validateRole;
    private validateStored;
    read(instanceId: string, roleId: string): Promise<{
        binding: RoleBinding | null;
    }>;
    /** One durable owner for both role and task bindings: the intent precedes
     * native creation, and an uncertain creation never replaces its identity. */
    private ensureScoped;
    ensure(instanceId: string, roleId: string, viewId?: string): Promise<RoleBinding>;
    /** A task classroom's own teacher Session, persisted under the task identity. */
    ensureTask(input: {
        instanceId: string;
        roleId: string;
        taskId: string;
        lessonId: string;
        viewId?: string;
    }): Promise<RoleBinding>;
    openTask(input: {
        instanceId: string;
        roleId: string;
        taskId: string;
        lessonId: string;
        sessionId: string;
        revision: number;
    }): Promise<{
        sessionId: string;
    }>;
    open(instanceId: string, roleId: string, sessionId: string, revision: number): Promise<{
        sessionId: string;
    }>;
    sessionContext(instanceId: string, sessionId: string): Promise<{
        roleId: string;
    }>;
    restoredSessionContext(sessionId: string): Promise<{
        roleId: string;
        profile: {
            [x: string]: unknown;
            id: string;
            kind: "learner" | "library";
            title: string;
            revision: number;
            projectId?: string | null | undefined;
        };
        view: {
            id: string;
            profileId: string;
        };
    }>;
    private bound;
    private nativeIdentity;
    private mountNative;
    private assertNative;
    resolveSession(_appId: string, sessionId: string, _options?: {
        access: 'read' | 'write';
    }): Promise<{
        appId: string;
        instanceId: string;
        roleId: string;
        sessionId: string;
    }>;
    /** Native may already display a retained blank Session before the learner
     * confirms metadata transfer. Compose only that exact idle, proven Agent. */
    activateRetainedSessions(): Promise<void>;
    close(): Promise<void>;
}
export {};
