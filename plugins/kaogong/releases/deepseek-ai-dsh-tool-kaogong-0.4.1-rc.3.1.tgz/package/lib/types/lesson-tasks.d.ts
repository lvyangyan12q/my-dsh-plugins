import type { QuizAnswer, QuizGrade, QuizQuestion } from './lesson-quiz.tsx';
/** 课后任务的四步：读 / 测 / 练 / 回炉。状态全部由已发生的作答推导，不需要学员手动勾选。 */
export type LessonTaskKey = 'read' | 'quiz' | 'practice' | 'reheat';
export type LessonTaskState = 'done' | 'current' | 'ready' | 'pending';
export type LessonTask = {
    key: LessonTaskKey;
    label: string;
    title: string;
    state: LessonTaskState;
    detail: string;
};
export type LessonTaskInput = {
    questions: readonly QuizQuestion[];
    answers: readonly QuizAnswer[];
    /** 讲义已实际渲染（不是点过「当堂检测」）。 */
    readDone: boolean;
    /** 已有一轮真实提交的专项练习（或已关联到本课）即视为「练」完成。 */
    practiceDone: boolean;
};
/** 由检测作答与练习证据推导四步状态：同一时刻最多一个当前步。判分只在这里算一次。 */
export declare function deriveLessonTasks({ questions, answers, readDone, practiceDone }: LessonTaskInput): {
    tasks: LessonTask[];
    grade: QuizGrade;
};
/** 课后任务面板：四步状态 + 当前步的入口；有错题时给出回炉卡（回小节重读 / 重做检测 / 请老师补讲）。 */
export declare function LessonTasks({ questions, answers, readDone, practiceDone, onJump, onPractice, onExplain, onRetake }: LessonTaskInput & {
    /** 回讲义对应小节重读。 */
    onJump: (anchorId: string) => void;
    /** 进入专项练习：复用课堂面板已有的练习入口。 */
    onPractice: () => void;
    /** 针对某一步请老师补讲：复用课堂答疑与任务会话。 */
    onExplain?: (question: QuizQuestion, chosen: number) => void;
    /** 重做检测：清空作答并回到检测页签。 */
    onRetake: () => void;
}): import("react").JSX.Element;
