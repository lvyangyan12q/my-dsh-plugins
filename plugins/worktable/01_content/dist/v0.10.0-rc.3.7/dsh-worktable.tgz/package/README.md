# 本地派生 Worktable 平台

## 当前 rc.3 候选与后续版本规则

本轮工作台候选声明目标为官方 `0.2.1-rc.3`，使用准确 `engines.dsh` 门禁，未知版本在正式环境中拒绝加载。包版本或声明检查通过不表示完整兼容验收通过；只有公开契约、新版归档干净安装、SDK 消费者及真实应用闭环都有相应版本证据，才可标记已验。旧 alpha.2 仅保留旧冻结包供回退，不由本轮新包继续支持。

维护者打包需在 `npm run pack` 前设置 `WORKTABLE_NATIVE_RC3_ROOT`（或 `DSH_SOURCE`）为固定官方 rc.3 已构建检出；门禁使用其公开工具链、实际 Config 与兼容检查，并包含路由生命周期回归。打包不修改原生仓库，不变更 profile，不自动试用或部署。

### 未验收版本的独立显式试用

试用是未验证行为，不可在正式 home/profile 授予版本豁免。以下命令由用户在选定的新 Harness 检出中执行：先选一个全新的绝对 `DSH_HOME`，不复制会话、资料或存储，再使用官方精确版本命令。每个应用包都须单独授权，不能写通配范围；原生权限与应用能力检查继续有效。

```powershell
# 将下面占位值替换为实际新目录、目标宿主版本、精确候选版本和归档绝对路径。
$env:DSH_HOME = '<全新隔离home绝对路径>'
pnpm dsh plugin --profile web allow-version 'dsh-worktable@<候选版本>' --dsh-version '<目标宿主精确版本>' --accept-risk
pnpm dsh plugin --profile web add '<已核对哈希的候选tgz绝对路径>'
pnpm dsh web --no-open --host 127.0.0.1 --port <独立空闲端口>
# 撤销本次试用许可：仍在相同隔离 home 执行，不切换正式进程。
pnpm dsh plugin --profile web revoke-version 'dsh-worktable@<候选版本>' --dsh-version '<目标宿主精确版本>'
```

`allow-version` 是用户对一个精确包/宿主组合的官方风险确认，不等于兼容证明。插件不自动执行该命令，不自动复制模型凭据、迁移正式业务库或切换 3080。发现缺失公开能力即停止对应功能并保留记录。回退包、配置回退和业务迁移恢复分开处理；不得用旧整库覆盖升级后的新记录。


## 历史 0.6.0 协议记录

0.6.0首次导出 `dsh-worktable/sdk`：无副作用的协议/feature检查及公开类型，包精确9文件（新增lib/sdk.js、lib/sdk.d.ts）。接入协议仍为1；Notes要求产品>=0.6.0并验证实际feature。09的0.5.0没有该子路径，不能混装。生命周期和历史交接继承09；第二应用真实安装验收仍属10候选，不改变原生或正式profile。

本地候选新增应用停用/启用和独立原生会话交接。停用保留原生任务、记录与身份，阻止新实例及新任务；卸载前从“原生会话交接 / 卸载准备”打开原生对话处理问题、审批和运行任务。原生插件管理不提供业务卸载否决 hook，直接卸载后需从 DSH 原生会话列表继续。

停用策略保存时平台应用状态为 schema2；旧版08不理解，必须拒绝写入并保留数据。只有显式启用全部策略后才恢复 schema1，允许兼容产品降版。没有业务数据迁移、整 profile 回灌或隐式取消。此版本尚未发布到上游；下文保留上游使用说明，不表示候选资产已上传。

# dsh-worktable（工作台）

## 本地派生框架增量（工单03，待真实安装验收）

以受保护基线提交8f614b3为来源；当前源码含合法派生改动，不再声称与原始快照逐文件相同。原始来源及MIT许可见上级UPSTREAM-SNAPSHOT.json和README。以下旧版验收说明保留其原版本范围，不代表本次框架已通过。

- 工作台标题行“应用”入口可先使用未归属实例；已有项目的空模块也可选“应用”，沿用现有布局和标签。应用注册是按需展开的小表单。
- 同项目继续最近实例；新建独立实例、添加同实例视图是不同操作。未归属实例可显式关联一个项目，保留实例身份，不创建会话或移动资料。
- 应用定义、实例与视图引用由当前profile的公开profileContext.dir下worktable-platform/applications.v1.json保存；浏览器仍只保存既有布局和展示偏好。不复制业务数据。
- 新接入普通网页采用无allow-same-origin的sandbox，不接原生桥，不允许DSH同源地址、凭据或token查询入口；只保证入口和布局，不承诺网页内部状态共享。网页拒嵌/失效可外部打开；iframe加载事件不证明业务可用。
- 应用管理与既有文件/终端等敏感插件路由使用公开connection.admit认证；缺少当前profile或公开认证能力时明确不可用，不回退全局数据或无认证访问。此增量契约针对独立的官方0.2.0-rc.2验收实例；未重验旧版和桌面。
- 公共Host服务worktableApplications提供register/catalog/latest/createInstance/resume/attach/createView/resolveView/unregister/snapshot。协议版本当前为1；注册撤销保留实例和视图引用，缺应用会明确报错。此为首阶段接缝，最终冻结在工单10进行。
- 本次9条公开契约行为测试及1条实际React组件延迟回归是辅助证据；pack包括原回归和新增测试、最终包结构与独立安装检查。真实页面操作、普通网页权限、重启恢复由独立Host继续验收，工单03不因构建/测试成功关闭。深度共享、数据授权和原生AI属于后续工单。

持久化分工和边界记录于源码目录 plugins/worktable/02_process/PRD.md。

> DeepSeek Harness 侧边栏的 agent 级项目容器（应用抽屉）。纯增量插件，不替换、不禁用任何官方插件。

## 是什么

- **侧边栏「工作台」区块**：收纳用户自建项目与入驻插件项目，支持改名/图标/排序/显示隐藏、项目 × 对话绑定、项目文件夹。
- **分栏工作区引擎（自研）**：声明式布局预设（左栏/顶行/主行 + 右侧对话窗），窗格可拖拽分割、标签页模型；内置 资源管理器 / 终端 / 浏览器 / 动画 / 自定义窗口。
- **控制室**：默认自带项目（固定首位、不可删除），项目卡片网格镜像可见绑定项目的宿主状态（工作中/待你决定/已完成）；状态订阅不调用模型，计时与预览另有刷新机制。
- **项目独立挂载**：窗口任务使用项目 ID、窗格 ID 与绑定 ID 对应的专属结果文件；同一文件夹里的新项目仍从空白窗口开始，不自动读取其他项目的旧结果。
- **平台**：Windows 是本轮验证平台，范围见下方兼容说明；macOS 为实验性支持（核心文件路径代码已做跨平台适配，尚未真机端到端验证）。

## 技术底座

- Cordis 插件协议（客户端 bundle + 服务端路由 /api/worktable/*、终端 WebSocket）。
- 界面经 slot 座位协议注入侧边栏与 shell.overlay；对话窗复用宿主会话服务（新版 uiWorkspace.openSession，旧版 sessions.open）。
- 状态监控为宿主会话运行时快照的事件订阅镜像；视图/项目/绑定状态存 localStorage。
- 客户端：TypeScript + React（host externals）+ 原生 CSS；服务端：Node。

## v0.4.0：兼容与验证范围

- DSH 网页端兼容声明仅列 **0.1.1-rc.2 / 0.1.2-rc.1 / 0.2.0-rc.2**，不是对任意新旧版本的保证。
- Windows + 0.2.0-rc.2 网页端已有冷启动、工作台/控制室、新建绑定与短文本回复、关闭回切等验收基础；桌面主要页面与交互已点测，共目录串挂修复获用户确认。最终包经过 98 项源码回归、独立安装与客户端加载门禁；这些检查不等于完整桌面端业务验收。旧版沿用此前页面验收并补定向代码回归，未重跑整套旧版 GUI。
- 实际审批、子代理、自动挂载全链路尚未完成业务验收；macOS 未真机验证。升级后请完整重启 DSH 并刷新页面，仍加载失败需保留完整错误。

## v0.4.0 改动

- 针对 Windows 官方 Desktop 0.2.0-rc.2 补上终端连接：从宿主注入的 streamBaseUrl 取得实际 Host 地址，不把 dsh-app://app 当作 WebSocket 主机。普通 HTTP/HTTPS 网页连接保留。
- 更新指令区分 web/desktop profile；桌面安装必须使用该应用自带的 CLI，安装前完整退出，之后由用户手动重新打开。不要把网页端 CLI 当作桌面管理入口。
- 自定义窗口新建对话明确选择「未分组」时，保留项目工作目录但不自动加入宿主工作区；异步默认分组不覆盖用户选择。不移动已经创建的对话。
- 控制室创建的是空对话：新版 DSH 的未分组空对话无法使用原生输入框，因此在这一选择下提示并禁用创建，须由用户选择分组或加入可用的现有对话；不自动改组、不发送激活消息。现有分组未选具体项时也不允许创建。旧宿主未分组分支保留。
- 自动挂载只接收经「自定义」任务登记的项目/窗口结果，握手文件位于项目目录的 `.dsh-worktable/project-<项目 ID>/` 下。换目录、重绑项目、修改布局或手动关闭/替换窗口内容后，旧关联不再自动补挂。
- 同一项目的不同会话只得到和更新各自关联的窗口；同会话追改同名作品可以重新加载。补挂读取失败保留待办，下次打开可重试，成功后才清除。
- 已保存的旧窗口与产物文件保留；根目录旧 `widget-result.json` 不再自动导入。旧对话若需继续自动挂载，请从目标窗口的「自定义 → 发送到会话」发一次任务以建立新关联，随后可在同一对话直接继续修改。不自动清除此前误挂的标签；多个项目主动改写同一实际文件时，文件内容仍可能互相影响。
- 两端共享同一 DSH_HOME 时不必复制会话；项目/布局/媒体和外观设置按浏览器来源保存，不会自动从网页来源同步到桌面来源。不要复制整个浏览器配置或登录状态。

## 权限与外部服务（如实披露）

- **文件访问**：服务端读写工作区与用户指定的目录——文件窗目录列表、MD 编辑保存、项目文件夹 mkdir、站点静态托管、widget 产物读取。除用户当次操作外，插件在加载时、项目状态变化时、已登记窗口任务完成时会自动读取当前关联的 `.dsh-worktable/` 结果文件及其指定产物，并读取宿主提供的工作区数据（workspaces 路由）。不扫描根目录旧 `widget-result.json`；产物路径可来自任务结果，这不是文件系统沙箱。失败返回错误或降级。
- **网络**：① 更新检查向 api.github.com 发只读 GET（无凭据，请求仅含公开仓库名，不携带会话内容）；② 插件与宿主的通信走宿主自身的 API / WebSocket 通道（由宿主管理）；③ 「浏览器」「动画」等网页窗加载用户指定的页面，页面自身可能发起任意网络请求——等同于用户在自己的浏览器中打开这些页面。
- **命令执行**：① 「源代码管理」窗运行 git 只读状态命令；② 「终端」窗经 node-pty 启动交互式 Shell（Windows 下为 PowerShell）——这是用户主动使用的完整终端：终端内执行的任何命令都可能读写文件、联网，行为等同用户本人操作。
- **凭据与环境**：插件代码不专门提取、存储或上传任何 API Key / Token / Cookie；但终端窗把宿主进程的完整环境变量传给子 Shell（其中可能包含敏感信息），终端内命令的行为不受插件约束。插件对 process.env 的读取用于运行参数（数据目录 DSH_HOME、终端默认 Shell SHELL 等），不将其外发。以上声明均有对应源码可查；本说明不是安全保证，高权限能力如实列出，使用风险由用户在自身环境评估。
- **外部依赖与边界**：无生产依赖；终端窗依赖宿主的 ws / node-pty（缺失时该窗降级提示，不影响其余功能）。不替换、不禁用任何官方插件。本插件不声称解决宿主自身的全部启动问题。

## 安装

### 网页端

方式 A（推荐，无需 Git）——直接安装 GitHub Release 的最新安装包：

    dsh plugin --profile web add "https://github.com/Aisland-SJL/dsh-worktable/releases/latest/download/dsh-worktable.tgz"

方式 B（想改源码用）——克隆仓库后用本地路径注册（`link:` 只接受本地路径，不要带空格）：

    git clone https://github.com/Aisland-SJL/dsh-worktable.git
    dsh plugin --profile web add "link:<克隆出来的 dsh-worktable 仓库目录的绝对路径>/01_content"

两种方式 `add` 都会把 `dsh-worktable` 注册进 profile 的 bundle 列表（写入 `~/.dsh`），装完重启 dsh web、刷新界面生效。

### Windows 官方桌面端

先保存任务，从应用菜单/托盘完整退出（只关窗口不够）；将占位路径替换为实际桌面端安装目录，在 PowerShell 执行，再手动重新打开应用：

    & "<桌面端安装目录>\resources\runtime\cli\bin\dsh.cmd" plugin --profile desktop add "https://github.com/Aisland-SJL/dsh-worktable/releases/download/v0.4.0/dsh-worktable-0.4.0.tgz"

不要以不固定版本的 npx 或网页端 CLI 代替桌面端自带 CLI；保留实际 DSH_HOME，勿把测试数据目录覆盖正式数据。新建控制室管理对话时，DSH 0.2 用户请选择分组，或直接绑定可用的现有对话。

## 从源码构建

    cd 01_content
    npm install
    npm run build   # lib/index.js + lib/client.js
    node --check lib/index.js

## 构建注意事项

- **必须在 01_content 目录下构建**：误在仓库根跑会把 lib 写到仓库根，宿主仍加载 01_content/lib 旧 bundle（「改完不生效」假象）。
- 客户端 bundle 保持 window.__ModuleLoader__.load 握手，react/@deepseek-ai/* 全部 external。

## 相关文档

- 项目规则：https://github.com/Aisland-SJL/dsh-worktable/blob/main/AGENTS.md
- 需求与协议：https://github.com/Aisland-SJL/dsh-worktable/blob/main/02_process/PRD.md
- 工作日志：https://github.com/Aisland-SJL/dsh-worktable/tree/main/02_process/worklogs

## License

MIT


### 0.7 原生面板与基本标注兼容

原生Plugins等全局面板导航会释放分栏，并保留用户选中的原生面板；不会因分栏自动关闭而跳回旧对话。项目、控制室和未归属应用入口通过原生公开导航显示已有会话，再等原生视图就绪；没有已有目标时显示提示，不自动新建会话。后续原生导航、另一个项目或释放会取消旧等待。Esc及退出按钮仍保留显式回到打开前会话的意图。

基本文本标注在开始时固定项目、窗格、标签及内容身份，应用目标还包含appId/instanceId/viewId。确认前再次校验；移动标签仍按ID定位，内容替换、目标移除或项目切换则保留要求草稿并提示。成功仅把含稳定目标的文本追加到原生草稿，不发送模型，不应用生成结果。完整生成、追改及图片草稿恢复仍沿原阶段边界。

回归包含公开导航取消/错误契约、稳定标注目标契约，以及独立安装包客户端factory/真实React项目按钮和标注回调门禁；它们辅助真实DSH验收，不代表桌面或窄屏全流程已经通过。


### 0.7.1 窄屏单视图

会话可用区域不足760px时，顶部选择框可切换每个模块与“原生对话”，当前模块使用完整可用宽高，其他模块保活且hidden/inert。查看应用时暂时隐藏并禁用原生视图区交互；切回原生对话、回宽屏或退出时恢复原visibility/inert及保留的原生焦点，草稿、会话和实例身份不变。桌面分栏尺寸偏好不由窄屏切换改写。该兼容发生在Worktable布局适配层，不修改原生DSH，也不另建composer。


0.7.2补充焦点归属：原生区域隐藏期间若用户已进入模块、选择框或按钮，放弃旧原生焦点恢复；即使新控件随后失焦，resize也不把焦点抢回旧composer。仅未发生新焦点选择且当前焦点仍中立时恢复隐藏前焦点，visibility/inert始终独立恢复。


### 应用私有的原生会话角色

Host 消费方须检查 `native-role-session-scope-v1`。应用可将私有 Agent 声明为
`{kind:"agent", presetId:"standard", sessionScoped:true, ...}`，再通过
`worktableCapabilities.contributeSessionScopes(appId, owner)` 提供可信安装器。
这不会向原生创作模式菜单注册角色。

`owner.prepare` 创建独立、可释放且继承基础 preset 的校验作用域；平台在其中校验
角色声明的真实 Skill provider 与模型调用权限。`owner.mount` 只接收已由持久角色绑定
核实的原生 Agent Context，在 `agent/created` 完成前安装系统 persona、Skill 和工具。
`agent/pre-step` 重新核实实例、目录、角色、所有者与实际 Skill；停用或撤销后拒绝继续执行，
不会降级成通用 Agent。安装器必须返回精确且幂等的释放函数，不得写入全局 Context。
这些 Host 接口不暴露给浏览器或模型参数。

此接口不迁移旧会话或替换旧 preset。考公全新部署用新的学习实例；旧会话与资料原址保留。
普通通用会话不能仅凭相同目录获得应用角色。
